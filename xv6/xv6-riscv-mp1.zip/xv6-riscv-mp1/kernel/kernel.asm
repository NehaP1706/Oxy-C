
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	ad010113          	addi	sp,sp,-1328 # 80007ad0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	stimecmp,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd627>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	dbc78793          	addi	a5,a5,-580 # 80000e3c <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7119                	addi	sp,sp,-128
    800000d2:	fc86                	sd	ra,120(sp)
    800000d4:	f8a2                	sd	s0,112(sp)
    800000d6:	f4a6                	sd	s1,104(sp)
    800000d8:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000da:	06c05a63          	blez	a2,8000014e <consolewrite+0x7e>
    800000de:	f0ca                	sd	s2,96(sp)
    800000e0:	ecce                	sd	s3,88(sp)
    800000e2:	e8d2                	sd	s4,80(sp)
    800000e4:	e4d6                	sd	s5,72(sp)
    800000e6:	e0da                	sd	s6,64(sp)
    800000e8:	fc5e                	sd	s7,56(sp)
    800000ea:	f862                	sd	s8,48(sp)
    800000ec:	f466                	sd	s9,40(sp)
    800000ee:	8aaa                	mv	s5,a0
    800000f0:	8b2e                	mv	s6,a1
    800000f2:	8a32                	mv	s4,a2
  int i = 0;
    800000f4:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f6:	02000c13          	li	s8,32
    800000fa:	02000c93          	li	s9,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000fe:	5bfd                	li	s7,-1
    80000100:	a035                	j	8000012c <consolewrite+0x5c>
    if(nn > n - i)
    80000102:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000106:	86ce                	mv	a3,s3
    80000108:	01648633          	add	a2,s1,s6
    8000010c:	85d6                	mv	a1,s5
    8000010e:	f8040513          	addi	a0,s0,-128
    80000112:	3c6020ef          	jal	800024d8 <either_copyin>
    80000116:	03750e63          	beq	a0,s7,80000152 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011a:	85ce                	mv	a1,s3
    8000011c:	f8040513          	addi	a0,s0,-128
    80000120:	778000ef          	jal	80000898 <uartwrite>
    i += nn;
    80000124:	009904bb          	addw	s1,s2,s1
  while(i < n){
    80000128:	0144da63          	bge	s1,s4,8000013c <consolewrite+0x6c>
    if(nn > n - i)
    8000012c:	409a093b          	subw	s2,s4,s1
    80000130:	0009079b          	sext.w	a5,s2
    80000134:	fcfc57e3          	bge	s8,a5,80000102 <consolewrite+0x32>
    80000138:	8966                	mv	s2,s9
    8000013a:	b7e1                	j	80000102 <consolewrite+0x32>
    8000013c:	7906                	ld	s2,96(sp)
    8000013e:	69e6                	ld	s3,88(sp)
    80000140:	6a46                	ld	s4,80(sp)
    80000142:	6aa6                	ld	s5,72(sp)
    80000144:	6b06                	ld	s6,64(sp)
    80000146:	7be2                	ld	s7,56(sp)
    80000148:	7c42                	ld	s8,48(sp)
    8000014a:	7ca2                	ld	s9,40(sp)
    8000014c:	a819                	j	80000162 <consolewrite+0x92>
  int i = 0;
    8000014e:	4481                	li	s1,0
    80000150:	a809                	j	80000162 <consolewrite+0x92>
    80000152:	7906                	ld	s2,96(sp)
    80000154:	69e6                	ld	s3,88(sp)
    80000156:	6a46                	ld	s4,80(sp)
    80000158:	6aa6                	ld	s5,72(sp)
    8000015a:	6b06                	ld	s6,64(sp)
    8000015c:	7be2                	ld	s7,56(sp)
    8000015e:	7c42                	ld	s8,48(sp)
    80000160:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000162:	8526                	mv	a0,s1
    80000164:	70e6                	ld	ra,120(sp)
    80000166:	7446                	ld	s0,112(sp)
    80000168:	74a6                	ld	s1,104(sp)
    8000016a:	6109                	addi	sp,sp,128
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	00010517          	auipc	a0,0x10
    80000190:	94450513          	addi	a0,a0,-1724 # 8000fad0 <cons>
    80000194:	23b000ef          	jal	80000bce <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000198:	00010497          	auipc	s1,0x10
    8000019c:	93848493          	addi	s1,s1,-1736 # 8000fad0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a0:	00010917          	auipc	s2,0x10
    800001a4:	9c890913          	addi	s2,s2,-1592 # 8000fb68 <cons+0x98>
  while(n > 0){
    800001a8:	0b305d63          	blez	s3,80000262 <consoleread+0xf4>
    while(cons.r == cons.w){
    800001ac:	0984a783          	lw	a5,152(s1)
    800001b0:	09c4a703          	lw	a4,156(s1)
    800001b4:	0af71263          	bne	a4,a5,80000258 <consoleread+0xea>
      if(killed(myproc())){
    800001b8:	77a010ef          	jal	80001932 <myproc>
    800001bc:	02a020ef          	jal	800021e6 <killed>
    800001c0:	e12d                	bnez	a0,80000222 <consoleread+0xb4>
      sleep(&cons.r, &cons.lock);
    800001c2:	85a6                	mv	a1,s1
    800001c4:	854a                	mv	a0,s2
    800001c6:	5d1010ef          	jal	80001f96 <sleep>
    while(cons.r == cons.w){
    800001ca:	0984a783          	lw	a5,152(s1)
    800001ce:	09c4a703          	lw	a4,156(s1)
    800001d2:	fef703e3          	beq	a4,a5,800001b8 <consoleread+0x4a>
    800001d6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001d8:	00010717          	auipc	a4,0x10
    800001dc:	8f870713          	addi	a4,a4,-1800 # 8000fad0 <cons>
    800001e0:	0017869b          	addiw	a3,a5,1
    800001e4:	08d72c23          	sw	a3,152(a4)
    800001e8:	07f7f693          	andi	a3,a5,127
    800001ec:	9736                	add	a4,a4,a3
    800001ee:	01874703          	lbu	a4,24(a4)
    800001f2:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    800001f6:	4691                	li	a3,4
    800001f8:	04db8663          	beq	s7,a3,80000244 <consoleread+0xd6>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001fc:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000200:	4685                	li	a3,1
    80000202:	faf40613          	addi	a2,s0,-81
    80000206:	85d2                	mv	a1,s4
    80000208:	8556                	mv	a0,s5
    8000020a:	284020ef          	jal	8000248e <either_copyout>
    8000020e:	57fd                	li	a5,-1
    80000210:	04f50863          	beq	a0,a5,80000260 <consoleread+0xf2>
      break;

    dst++;
    80000214:	0a05                	addi	s4,s4,1
    --n;
    80000216:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80000218:	47a9                	li	a5,10
    8000021a:	04fb8d63          	beq	s7,a5,80000274 <consoleread+0x106>
    8000021e:	6be2                	ld	s7,24(sp)
    80000220:	b761                	j	800001a8 <consoleread+0x3a>
        release(&cons.lock);
    80000222:	00010517          	auipc	a0,0x10
    80000226:	8ae50513          	addi	a0,a0,-1874 # 8000fad0 <cons>
    8000022a:	23d000ef          	jal	80000c66 <release>
        return -1;
    8000022e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000230:	60e6                	ld	ra,88(sp)
    80000232:	6446                	ld	s0,80(sp)
    80000234:	64a6                	ld	s1,72(sp)
    80000236:	6906                	ld	s2,64(sp)
    80000238:	79e2                	ld	s3,56(sp)
    8000023a:	7a42                	ld	s4,48(sp)
    8000023c:	7aa2                	ld	s5,40(sp)
    8000023e:	7b02                	ld	s6,32(sp)
    80000240:	6125                	addi	sp,sp,96
    80000242:	8082                	ret
      if(n < target){
    80000244:	0009871b          	sext.w	a4,s3
    80000248:	01677a63          	bgeu	a4,s6,8000025c <consoleread+0xee>
        cons.r--;
    8000024c:	00010717          	auipc	a4,0x10
    80000250:	90f72e23          	sw	a5,-1764(a4) # 8000fb68 <cons+0x98>
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	a031                	j	80000262 <consoleread+0xf4>
    80000258:	ec5e                	sd	s7,24(sp)
    8000025a:	bfbd                	j	800001d8 <consoleread+0x6a>
    8000025c:	6be2                	ld	s7,24(sp)
    8000025e:	a011                	j	80000262 <consoleread+0xf4>
    80000260:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000262:	00010517          	auipc	a0,0x10
    80000266:	86e50513          	addi	a0,a0,-1938 # 8000fad0 <cons>
    8000026a:	1fd000ef          	jal	80000c66 <release>
  return target - n;
    8000026e:	413b053b          	subw	a0,s6,s3
    80000272:	bf7d                	j	80000230 <consoleread+0xc2>
    80000274:	6be2                	ld	s7,24(sp)
    80000276:	b7f5                	j	80000262 <consoleread+0xf4>

0000000080000278 <consputc>:
{
    80000278:	1141                	addi	sp,sp,-16
    8000027a:	e406                	sd	ra,8(sp)
    8000027c:	e022                	sd	s0,0(sp)
    8000027e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000280:	10000793          	li	a5,256
    80000284:	00f50863          	beq	a0,a5,80000294 <consputc+0x1c>
    uartputc_sync(c);
    80000288:	6a4000ef          	jal	8000092c <uartputc_sync>
}
    8000028c:	60a2                	ld	ra,8(sp)
    8000028e:	6402                	ld	s0,0(sp)
    80000290:	0141                	addi	sp,sp,16
    80000292:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000294:	4521                	li	a0,8
    80000296:	696000ef          	jal	8000092c <uartputc_sync>
    8000029a:	02000513          	li	a0,32
    8000029e:	68e000ef          	jal	8000092c <uartputc_sync>
    800002a2:	4521                	li	a0,8
    800002a4:	688000ef          	jal	8000092c <uartputc_sync>
    800002a8:	b7d5                	j	8000028c <consputc+0x14>

00000000800002aa <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002aa:	1101                	addi	sp,sp,-32
    800002ac:	ec06                	sd	ra,24(sp)
    800002ae:	e822                	sd	s0,16(sp)
    800002b0:	e426                	sd	s1,8(sp)
    800002b2:	1000                	addi	s0,sp,32
    800002b4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b6:	00010517          	auipc	a0,0x10
    800002ba:	81a50513          	addi	a0,a0,-2022 # 8000fad0 <cons>
    800002be:	111000ef          	jal	80000bce <acquire>

  switch(c){
    800002c2:	47d5                	li	a5,21
    800002c4:	08f48f63          	beq	s1,a5,80000362 <consoleintr+0xb8>
    800002c8:	0297c563          	blt	a5,s1,800002f2 <consoleintr+0x48>
    800002cc:	47a1                	li	a5,8
    800002ce:	0ef48463          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    800002d2:	47c1                	li	a5,16
    800002d4:	10f49563          	bne	s1,a5,800003de <consoleintr+0x134>
  case C('P'):  // Print process list.
    procdump();
    800002d8:	24a020ef          	jal	80002522 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002dc:	0000f517          	auipc	a0,0xf
    800002e0:	7f450513          	addi	a0,a0,2036 # 8000fad0 <cons>
    800002e4:	183000ef          	jal	80000c66 <release>
}
    800002e8:	60e2                	ld	ra,24(sp)
    800002ea:	6442                	ld	s0,16(sp)
    800002ec:	64a2                	ld	s1,8(sp)
    800002ee:	6105                	addi	sp,sp,32
    800002f0:	8082                	ret
  switch(c){
    800002f2:	07f00793          	li	a5,127
    800002f6:	0cf48063          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fa:	0000f717          	auipc	a4,0xf
    800002fe:	7d670713          	addi	a4,a4,2006 # 8000fad0 <cons>
    80000302:	0a072783          	lw	a5,160(a4)
    80000306:	09872703          	lw	a4,152(a4)
    8000030a:	9f99                	subw	a5,a5,a4
    8000030c:	07f00713          	li	a4,127
    80000310:	fcf766e3          	bltu	a4,a5,800002dc <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000314:	47b5                	li	a5,13
    80000316:	0cf48763          	beq	s1,a5,800003e4 <consoleintr+0x13a>
      consputc(c);
    8000031a:	8526                	mv	a0,s1
    8000031c:	f5dff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000320:	0000f797          	auipc	a5,0xf
    80000324:	7b078793          	addi	a5,a5,1968 # 8000fad0 <cons>
    80000328:	0a07a683          	lw	a3,160(a5)
    8000032c:	0016871b          	addiw	a4,a3,1
    80000330:	0007061b          	sext.w	a2,a4
    80000334:	0ae7a023          	sw	a4,160(a5)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	97b6                	add	a5,a5,a3
    8000033e:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	47a9                	li	a5,10
    80000344:	0cf48563          	beq	s1,a5,8000040e <consoleintr+0x164>
    80000348:	4791                	li	a5,4
    8000034a:	0cf48263          	beq	s1,a5,8000040e <consoleintr+0x164>
    8000034e:	00010797          	auipc	a5,0x10
    80000352:	81a7a783          	lw	a5,-2022(a5) # 8000fb68 <cons+0x98>
    80000356:	9f1d                	subw	a4,a4,a5
    80000358:	08000793          	li	a5,128
    8000035c:	f8f710e3          	bne	a4,a5,800002dc <consoleintr+0x32>
    80000360:	a07d                	j	8000040e <consoleintr+0x164>
    80000362:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000364:	0000f717          	auipc	a4,0xf
    80000368:	76c70713          	addi	a4,a4,1900 # 8000fad0 <cons>
    8000036c:	0a072783          	lw	a5,160(a4)
    80000370:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000374:	0000f497          	auipc	s1,0xf
    80000378:	75c48493          	addi	s1,s1,1884 # 8000fad0 <cons>
    while(cons.e != cons.w &&
    8000037c:	4929                	li	s2,10
    8000037e:	02f70863          	beq	a4,a5,800003ae <consoleintr+0x104>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000382:	37fd                	addiw	a5,a5,-1
    80000384:	07f7f713          	andi	a4,a5,127
    80000388:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000038a:	01874703          	lbu	a4,24(a4)
    8000038e:	03270263          	beq	a4,s2,800003b2 <consoleintr+0x108>
      cons.e--;
    80000392:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000396:	10000513          	li	a0,256
    8000039a:	edfff0ef          	jal	80000278 <consputc>
    while(cons.e != cons.w &&
    8000039e:	0a04a783          	lw	a5,160(s1)
    800003a2:	09c4a703          	lw	a4,156(s1)
    800003a6:	fcf71ee3          	bne	a4,a5,80000382 <consoleintr+0xd8>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	bf05                	j	800002dc <consoleintr+0x32>
    800003ae:	6902                	ld	s2,0(sp)
    800003b0:	b735                	j	800002dc <consoleintr+0x32>
    800003b2:	6902                	ld	s2,0(sp)
    800003b4:	b725                	j	800002dc <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b6:	0000f717          	auipc	a4,0xf
    800003ba:	71a70713          	addi	a4,a4,1818 # 8000fad0 <cons>
    800003be:	0a072783          	lw	a5,160(a4)
    800003c2:	09c72703          	lw	a4,156(a4)
    800003c6:	f0f70be3          	beq	a4,a5,800002dc <consoleintr+0x32>
      cons.e--;
    800003ca:	37fd                	addiw	a5,a5,-1
    800003cc:	0000f717          	auipc	a4,0xf
    800003d0:	7af72223          	sw	a5,1956(a4) # 8000fb70 <cons+0xa0>
      consputc(BACKSPACE);
    800003d4:	10000513          	li	a0,256
    800003d8:	ea1ff0ef          	jal	80000278 <consputc>
    800003dc:	b701                	j	800002dc <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003de:	ee048fe3          	beqz	s1,800002dc <consoleintr+0x32>
    800003e2:	bf21                	j	800002fa <consoleintr+0x50>
      consputc(c);
    800003e4:	4529                	li	a0,10
    800003e6:	e93ff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003ea:	0000f797          	auipc	a5,0xf
    800003ee:	6e678793          	addi	a5,a5,1766 # 8000fad0 <cons>
    800003f2:	0a07a703          	lw	a4,160(a5)
    800003f6:	0017069b          	addiw	a3,a4,1
    800003fa:	0006861b          	sext.w	a2,a3
    800003fe:	0ad7a023          	sw	a3,160(a5)
    80000402:	07f77713          	andi	a4,a4,127
    80000406:	97ba                	add	a5,a5,a4
    80000408:	4729                	li	a4,10
    8000040a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040e:	0000f797          	auipc	a5,0xf
    80000412:	74c7af23          	sw	a2,1886(a5) # 8000fb6c <cons+0x9c>
        wakeup(&cons.r);
    80000416:	0000f517          	auipc	a0,0xf
    8000041a:	75250513          	addi	a0,a0,1874 # 8000fb68 <cons+0x98>
    8000041e:	3c5010ef          	jal	80001fe2 <wakeup>
    80000422:	bd6d                	j	800002dc <consoleintr+0x32>

0000000080000424 <consoleinit>:

void
consoleinit(void)
{
    80000424:	1141                	addi	sp,sp,-16
    80000426:	e406                	sd	ra,8(sp)
    80000428:	e022                	sd	s0,0(sp)
    8000042a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000042c:	00007597          	auipc	a1,0x7
    80000430:	bd458593          	addi	a1,a1,-1068 # 80007000 <etext>
    80000434:	0000f517          	auipc	a0,0xf
    80000438:	69c50513          	addi	a0,a0,1692 # 8000fad0 <cons>
    8000043c:	712000ef          	jal	80000b4e <initlock>

  uartinit();
    80000440:	400000ef          	jal	80000840 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000444:	00020797          	auipc	a5,0x20
    80000448:	bfc78793          	addi	a5,a5,-1028 # 80020040 <devsw>
    8000044c:	00000717          	auipc	a4,0x0
    80000450:	d2270713          	addi	a4,a4,-734 # 8000016e <consoleread>
    80000454:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000456:	00000717          	auipc	a4,0x0
    8000045a:	c7a70713          	addi	a4,a4,-902 # 800000d0 <consolewrite>
    8000045e:	ef98                	sd	a4,24(a5)
}
    80000460:	60a2                	ld	ra,8(sp)
    80000462:	6402                	ld	s0,0(sp)
    80000464:	0141                	addi	sp,sp,16
    80000466:	8082                	ret

0000000080000468 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000468:	7139                	addi	sp,sp,-64
    8000046a:	fc06                	sd	ra,56(sp)
    8000046c:	f822                	sd	s0,48(sp)
    8000046e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000470:	c219                	beqz	a2,80000476 <printint+0xe>
    80000472:	08054063          	bltz	a0,800004f2 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000476:	4881                	li	a7,0
    80000478:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000047c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007617          	auipc	a2,0x7
    80000482:	38a60613          	addi	a2,a2,906 # 80007808 <digits>
    80000486:	883e                	mv	a6,a5
    80000488:	2785                	addiw	a5,a5,1
    8000048a:	02b57733          	remu	a4,a0,a1
    8000048e:	9732                	add	a4,a4,a2
    80000490:	00074703          	lbu	a4,0(a4)
    80000494:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000498:	872a                	mv	a4,a0
    8000049a:	02b55533          	divu	a0,a0,a1
    8000049e:	0685                	addi	a3,a3,1
    800004a0:	feb773e3          	bgeu	a4,a1,80000486 <printint+0x1e>

  if(sign)
    800004a4:	00088a63          	beqz	a7,800004b8 <printint+0x50>
    buf[i++] = '-';
    800004a8:	1781                	addi	a5,a5,-32
    800004aa:	97a2                	add	a5,a5,s0
    800004ac:	02d00713          	li	a4,45
    800004b0:	fee78423          	sb	a4,-24(a5)
    800004b4:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    800004b8:	02f05963          	blez	a5,800004ea <printint+0x82>
    800004bc:	f426                	sd	s1,40(sp)
    800004be:	f04a                	sd	s2,32(sp)
    800004c0:	fc840713          	addi	a4,s0,-56
    800004c4:	00f704b3          	add	s1,a4,a5
    800004c8:	fff70913          	addi	s2,a4,-1
    800004cc:	993e                	add	s2,s2,a5
    800004ce:	37fd                	addiw	a5,a5,-1
    800004d0:	1782                	slli	a5,a5,0x20
    800004d2:	9381                	srli	a5,a5,0x20
    800004d4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004d8:	fff4c503          	lbu	a0,-1(s1)
    800004dc:	d9dff0ef          	jal	80000278 <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x70>
    800004e6:	74a2                	ld	s1,40(sp)
    800004e8:	7902                	ld	s2,32(sp)
}
    800004ea:	70e2                	ld	ra,56(sp)
    800004ec:	7442                	ld	s0,48(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4885                	li	a7,1
    x = -xx;
    800004f8:	b741                	j	80000478 <printint+0x10>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	e8d2                	sd	s4,80(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	8a2a                	mv	s4,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	57c7a783          	lw	a5,1404(a5) # 80007a94 <panicking>
    80000520:	c3a1                	beqz	a5,80000560 <printf+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	000a4503          	lbu	a0,0(s4)
    8000052e:	28050763          	beqz	a0,800007bc <printf+0x2c2>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	f0ca                	sd	s2,96(sp)
    80000536:	ecce                	sd	s3,88(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	f862                	sd	s8,48(sp)
    8000053e:	f466                	sd	s9,40(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4981                	li	s3,0
    if(cx != '%'){
    80000546:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    8000054a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000054e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000552:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000556:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    8000055a:	07000d93          	li	s11,112
    8000055e:	a01d                	j	80000584 <printf+0x8a>
    acquire(&pr.lock);
    80000560:	0000f517          	auipc	a0,0xf
    80000564:	61850513          	addi	a0,a0,1560 # 8000fb78 <pr>
    80000568:	666000ef          	jal	80000bce <acquire>
    8000056c:	bf5d                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056e:	d0bff0ef          	jal	80000278 <consputc>
      continue;
    80000572:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000574:	0014899b          	addiw	s3,s1,1
    80000578:	013a07b3          	add	a5,s4,s3
    8000057c:	0007c503          	lbu	a0,0(a5)
    80000580:	20050b63          	beqz	a0,80000796 <printf+0x29c>
    if(cx != '%'){
    80000584:	ff5515e3          	bne	a0,s5,8000056e <printf+0x74>
    i++;
    80000588:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000058c:	009a07b3          	add	a5,s4,s1
    80000590:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000594:	20090b63          	beqz	s2,800007aa <printf+0x2b0>
    80000598:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000059c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059e:	c789                	beqz	a5,800005a8 <printf+0xae>
    800005a0:	009a0733          	add	a4,s4,s1
    800005a4:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    800005a8:	03690963          	beq	s2,s6,800005da <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    800005ac:	05890363          	beq	s2,s8,800005f2 <printf+0xf8>
    } else if(c0 == 'u'){
    800005b0:	0d990663          	beq	s2,s9,8000067c <printf+0x182>
    } else if(c0 == 'x'){
    800005b4:	11a90d63          	beq	s2,s10,800006ce <printf+0x1d4>
    } else if(c0 == 'p'){
    800005b8:	15b90663          	beq	s2,s11,80000704 <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    800005bc:	06300793          	li	a5,99
    800005c0:	18f90563          	beq	s2,a5,8000074a <printf+0x250>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    800005c4:	07300793          	li	a5,115
    800005c8:	18f90b63          	beq	s2,a5,8000075e <printf+0x264>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    800005cc:	03591b63          	bne	s2,s5,80000602 <printf+0x108>
      consputc('%');
    800005d0:	02500513          	li	a0,37
    800005d4:	ca5ff0ef          	jal	80000278 <consputc>
    800005d8:	bf71                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005da:	f8843783          	ld	a5,-120(s0)
    800005de:	00878713          	addi	a4,a5,8
    800005e2:	f8e43423          	sd	a4,-120(s0)
    800005e6:	4605                	li	a2,1
    800005e8:	45a9                	li	a1,10
    800005ea:	4388                	lw	a0,0(a5)
    800005ec:	e7dff0ef          	jal	80000468 <printint>
    800005f0:	b751                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'd'){
    800005f2:	01678f63          	beq	a5,s6,80000610 <printf+0x116>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005f6:	03878b63          	beq	a5,s8,8000062c <printf+0x132>
    } else if(c0 == 'l' && c1 == 'u'){
    800005fa:	09978e63          	beq	a5,s9,80000696 <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'x'){
    800005fe:	0fa78563          	beq	a5,s10,800006e8 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000602:	8556                	mv	a0,s5
    80000604:	c75ff0ef          	jal	80000278 <consputc>
      consputc(c0);
    80000608:	854a                	mv	a0,s2
    8000060a:	c6fff0ef          	jal	80000278 <consputc>
    8000060e:	b79d                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000610:	f8843783          	ld	a5,-120(s0)
    80000614:	00878713          	addi	a4,a5,8
    80000618:	f8e43423          	sd	a4,-120(s0)
    8000061c:	4605                	li	a2,1
    8000061e:	45a9                	li	a1,10
    80000620:	6388                	ld	a0,0(a5)
    80000622:	e47ff0ef          	jal	80000468 <printint>
      i += 1;
    80000626:	0029849b          	addiw	s1,s3,2
    8000062a:	b7a9                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000062c:	06400793          	li	a5,100
    80000630:	02f68863          	beq	a3,a5,80000660 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000634:	07500793          	li	a5,117
    80000638:	06f68d63          	beq	a3,a5,800006b2 <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000063c:	07800793          	li	a5,120
    80000640:	fcf691e3          	bne	a3,a5,80000602 <printf+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4601                	li	a2,0
    80000652:	45c1                	li	a1,16
    80000654:	6388                	ld	a0,0(a5)
    80000656:	e13ff0ef          	jal	80000468 <printint>
      i += 2;
    8000065a:	0039849b          	addiw	s1,s3,3
    8000065e:	bf19                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000660:	f8843783          	ld	a5,-120(s0)
    80000664:	00878713          	addi	a4,a5,8
    80000668:	f8e43423          	sd	a4,-120(s0)
    8000066c:	4605                	li	a2,1
    8000066e:	45a9                	li	a1,10
    80000670:	6388                	ld	a0,0(a5)
    80000672:	df7ff0ef          	jal	80000468 <printint>
      i += 2;
    80000676:	0039849b          	addiw	s1,s3,3
    8000067a:	bded                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4601                	li	a2,0
    8000068a:	45a9                	li	a1,10
    8000068c:	0007e503          	lwu	a0,0(a5)
    80000690:	dd9ff0ef          	jal	80000468 <printint>
    80000694:	b5c5                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    80000696:	f8843783          	ld	a5,-120(s0)
    8000069a:	00878713          	addi	a4,a5,8
    8000069e:	f8e43423          	sd	a4,-120(s0)
    800006a2:	4601                	li	a2,0
    800006a4:	45a9                	li	a1,10
    800006a6:	6388                	ld	a0,0(a5)
    800006a8:	dc1ff0ef          	jal	80000468 <printint>
      i += 1;
    800006ac:	0029849b          	addiw	s1,s3,2
    800006b0:	b5d1                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006b2:	f8843783          	ld	a5,-120(s0)
    800006b6:	00878713          	addi	a4,a5,8
    800006ba:	f8e43423          	sd	a4,-120(s0)
    800006be:	4601                	li	a2,0
    800006c0:	45a9                	li	a1,10
    800006c2:	6388                	ld	a0,0(a5)
    800006c4:	da5ff0ef          	jal	80000468 <printint>
      i += 2;
    800006c8:	0039849b          	addiw	s1,s3,3
    800006cc:	b565                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	4601                	li	a2,0
    800006dc:	45c1                	li	a1,16
    800006de:	0007e503          	lwu	a0,0(a5)
    800006e2:	d87ff0ef          	jal	80000468 <printint>
    800006e6:	b579                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006e8:	f8843783          	ld	a5,-120(s0)
    800006ec:	00878713          	addi	a4,a5,8
    800006f0:	f8e43423          	sd	a4,-120(s0)
    800006f4:	4601                	li	a2,0
    800006f6:	45c1                	li	a1,16
    800006f8:	6388                	ld	a0,0(a5)
    800006fa:	d6fff0ef          	jal	80000468 <printint>
      i += 1;
    800006fe:	0029849b          	addiw	s1,s3,2
    80000702:	bd8d                	j	80000574 <printf+0x7a>
    80000704:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000706:	f8843783          	ld	a5,-120(s0)
    8000070a:	00878713          	addi	a4,a5,8
    8000070e:	f8e43423          	sd	a4,-120(s0)
    80000712:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000716:	03000513          	li	a0,48
    8000071a:	b5fff0ef          	jal	80000278 <consputc>
  consputc('x');
    8000071e:	07800513          	li	a0,120
    80000722:	b57ff0ef          	jal	80000278 <consputc>
    80000726:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000728:	00007b97          	auipc	s7,0x7
    8000072c:	0e0b8b93          	addi	s7,s7,224 # 80007808 <digits>
    80000730:	03c9d793          	srli	a5,s3,0x3c
    80000734:	97de                	add	a5,a5,s7
    80000736:	0007c503          	lbu	a0,0(a5)
    8000073a:	b3fff0ef          	jal	80000278 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000073e:	0992                	slli	s3,s3,0x4
    80000740:	397d                	addiw	s2,s2,-1
    80000742:	fe0917e3          	bnez	s2,80000730 <printf+0x236>
    80000746:	7be2                	ld	s7,56(sp)
    80000748:	b535                	j	80000574 <printf+0x7a>
      consputc(va_arg(ap, uint));
    8000074a:	f8843783          	ld	a5,-120(s0)
    8000074e:	00878713          	addi	a4,a5,8
    80000752:	f8e43423          	sd	a4,-120(s0)
    80000756:	4388                	lw	a0,0(a5)
    80000758:	b21ff0ef          	jal	80000278 <consputc>
    8000075c:	bd21                	j	80000574 <printf+0x7a>
      if((s = va_arg(ap, char*)) == 0)
    8000075e:	f8843783          	ld	a5,-120(s0)
    80000762:	00878713          	addi	a4,a5,8
    80000766:	f8e43423          	sd	a4,-120(s0)
    8000076a:	0007b903          	ld	s2,0(a5)
    8000076e:	00090d63          	beqz	s2,80000788 <printf+0x28e>
      for(; *s; s++)
    80000772:	00094503          	lbu	a0,0(s2)
    80000776:	de050fe3          	beqz	a0,80000574 <printf+0x7a>
        consputc(*s);
    8000077a:	affff0ef          	jal	80000278 <consputc>
      for(; *s; s++)
    8000077e:	0905                	addi	s2,s2,1
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	f97d                	bnez	a0,8000077a <printf+0x280>
    80000786:	b3fd                	j	80000574 <printf+0x7a>
        s = "(null)";
    80000788:	00007917          	auipc	s2,0x7
    8000078c:	88090913          	addi	s2,s2,-1920 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000790:	02800513          	li	a0,40
    80000794:	b7dd                	j	8000077a <printf+0x280>
    80000796:	74a6                	ld	s1,104(sp)
    80000798:	7906                	ld	s2,96(sp)
    8000079a:	69e6                	ld	s3,88(sp)
    8000079c:	6aa6                	ld	s5,72(sp)
    8000079e:	6b06                	ld	s6,64(sp)
    800007a0:	7c42                	ld	s8,48(sp)
    800007a2:	7ca2                	ld	s9,40(sp)
    800007a4:	7d02                	ld	s10,32(sp)
    800007a6:	6de2                	ld	s11,24(sp)
    800007a8:	a811                	j	800007bc <printf+0x2c2>
    800007aa:	74a6                	ld	s1,104(sp)
    800007ac:	7906                	ld	s2,96(sp)
    800007ae:	69e6                	ld	s3,88(sp)
    800007b0:	6aa6                	ld	s5,72(sp)
    800007b2:	6b06                	ld	s6,64(sp)
    800007b4:	7c42                	ld	s8,48(sp)
    800007b6:	7ca2                	ld	s9,40(sp)
    800007b8:	7d02                	ld	s10,32(sp)
    800007ba:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    800007bc:	00007797          	auipc	a5,0x7
    800007c0:	2d87a783          	lw	a5,728(a5) # 80007a94 <panicking>
    800007c4:	c799                	beqz	a5,800007d2 <printf+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007c6:	4501                	li	a0,0
    800007c8:	70e6                	ld	ra,120(sp)
    800007ca:	7446                	ld	s0,112(sp)
    800007cc:	6a46                	ld	s4,80(sp)
    800007ce:	6129                	addi	sp,sp,192
    800007d0:	8082                	ret
    release(&pr.lock);
    800007d2:	0000f517          	auipc	a0,0xf
    800007d6:	3a650513          	addi	a0,a0,934 # 8000fb78 <pr>
    800007da:	48c000ef          	jal	80000c66 <release>
  return 0;
    800007de:	b7e5                	j	800007c6 <printf+0x2cc>

00000000800007e0 <panic>:

void
panic(char *s)
{
    800007e0:	1101                	addi	sp,sp,-32
    800007e2:	ec06                	sd	ra,24(sp)
    800007e4:	e822                	sd	s0,16(sp)
    800007e6:	e426                	sd	s1,8(sp)
    800007e8:	e04a                	sd	s2,0(sp)
    800007ea:	1000                	addi	s0,sp,32
    800007ec:	84aa                	mv	s1,a0
  panicking = 1;
    800007ee:	4905                	li	s2,1
    800007f0:	00007797          	auipc	a5,0x7
    800007f4:	2b27a223          	sw	s2,676(a5) # 80007a94 <panicking>
  printf("panic: ");
    800007f8:	00007517          	auipc	a0,0x7
    800007fc:	82050513          	addi	a0,a0,-2016 # 80007018 <etext+0x18>
    80000800:	cfbff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000804:	85a6                	mv	a1,s1
    80000806:	00007517          	auipc	a0,0x7
    8000080a:	81a50513          	addi	a0,a0,-2022 # 80007020 <etext+0x20>
    8000080e:	cedff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000812:	00007797          	auipc	a5,0x7
    80000816:	2727af23          	sw	s2,638(a5) # 80007a90 <panicked>
  for(;;)
    8000081a:	a001                	j	8000081a <panic+0x3a>

000000008000081c <printfinit>:
    ;
}

void
printfinit(void)
{
    8000081c:	1141                	addi	sp,sp,-16
    8000081e:	e406                	sd	ra,8(sp)
    80000820:	e022                	sd	s0,0(sp)
    80000822:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000824:	00007597          	auipc	a1,0x7
    80000828:	80458593          	addi	a1,a1,-2044 # 80007028 <etext+0x28>
    8000082c:	0000f517          	auipc	a0,0xf
    80000830:	34c50513          	addi	a0,a0,844 # 8000fb78 <pr>
    80000834:	31a000ef          	jal	80000b4e <initlock>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret

0000000080000840 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000840:	1141                	addi	sp,sp,-16
    80000842:	e406                	sd	ra,8(sp)
    80000844:	e022                	sd	s0,0(sp)
    80000846:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000848:	100007b7          	lui	a5,0x10000
    8000084c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000850:	10000737          	lui	a4,0x10000
    80000854:	f8000693          	li	a3,-128
    80000858:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000085c:	468d                	li	a3,3
    8000085e:	10000637          	lui	a2,0x10000
    80000862:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000866:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000086a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000086e:	10000737          	lui	a4,0x10000
    80000872:	461d                	li	a2,7
    80000874:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000878:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000087c:	00006597          	auipc	a1,0x6
    80000880:	7b458593          	addi	a1,a1,1972 # 80007030 <etext+0x30>
    80000884:	0000f517          	auipc	a0,0xf
    80000888:	30c50513          	addi	a0,a0,780 # 8000fb90 <tx_lock>
    8000088c:	2c2000ef          	jal	80000b4e <initlock>
}
    80000890:	60a2                	ld	ra,8(sp)
    80000892:	6402                	ld	s0,0(sp)
    80000894:	0141                	addi	sp,sp,16
    80000896:	8082                	ret

0000000080000898 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    80000898:	715d                	addi	sp,sp,-80
    8000089a:	e486                	sd	ra,72(sp)
    8000089c:	e0a2                	sd	s0,64(sp)
    8000089e:	fc26                	sd	s1,56(sp)
    800008a0:	ec56                	sd	s5,24(sp)
    800008a2:	0880                	addi	s0,sp,80
    800008a4:	8aaa                	mv	s5,a0
    800008a6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008a8:	0000f517          	auipc	a0,0xf
    800008ac:	2e850513          	addi	a0,a0,744 # 8000fb90 <tx_lock>
    800008b0:	31e000ef          	jal	80000bce <acquire>

  int i = 0;
  while(i < n){ 
    800008b4:	06905063          	blez	s1,80000914 <uartwrite+0x7c>
    800008b8:	f84a                	sd	s2,48(sp)
    800008ba:	f44e                	sd	s3,40(sp)
    800008bc:	f052                	sd	s4,32(sp)
    800008be:	e85a                	sd	s6,16(sp)
    800008c0:	e45e                	sd	s7,8(sp)
    800008c2:	8a56                	mv	s4,s5
    800008c4:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    800008c6:	00007497          	auipc	s1,0x7
    800008ca:	1d648493          	addi	s1,s1,470 # 80007a9c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    800008ce:	0000f997          	auipc	s3,0xf
    800008d2:	2c298993          	addi	s3,s3,706 # 8000fb90 <tx_lock>
    800008d6:	00007917          	auipc	s2,0x7
    800008da:	1c290913          	addi	s2,s2,450 # 80007a98 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    800008de:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008e2:	4b05                	li	s6,1
    800008e4:	a005                	j	80000904 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    800008e6:	85ce                	mv	a1,s3
    800008e8:	854a                	mv	a0,s2
    800008ea:	6ac010ef          	jal	80001f96 <sleep>
    while(tx_busy != 0){
    800008ee:	409c                	lw	a5,0(s1)
    800008f0:	fbfd                	bnez	a5,800008e6 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    800008f2:	000a4783          	lbu	a5,0(s4)
    800008f6:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008fa:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008fe:	0a05                	addi	s4,s4,1
    80000900:	015a0563          	beq	s4,s5,8000090a <uartwrite+0x72>
    while(tx_busy != 0){
    80000904:	409c                	lw	a5,0(s1)
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x4e>
    80000908:	b7ed                	j	800008f2 <uartwrite+0x5a>
    8000090a:	7942                	ld	s2,48(sp)
    8000090c:	79a2                	ld	s3,40(sp)
    8000090e:	7a02                	ld	s4,32(sp)
    80000910:	6b42                	ld	s6,16(sp)
    80000912:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000914:	0000f517          	auipc	a0,0xf
    80000918:	27c50513          	addi	a0,a0,636 # 8000fb90 <tx_lock>
    8000091c:	34a000ef          	jal	80000c66 <release>
}
    80000920:	60a6                	ld	ra,72(sp)
    80000922:	6406                	ld	s0,64(sp)
    80000924:	74e2                	ld	s1,56(sp)
    80000926:	6ae2                	ld	s5,24(sp)
    80000928:	6161                	addi	sp,sp,80
    8000092a:	8082                	ret

000000008000092c <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092c:	1101                	addi	sp,sp,-32
    8000092e:	ec06                	sd	ra,24(sp)
    80000930:	e822                	sd	s0,16(sp)
    80000932:	e426                	sd	s1,8(sp)
    80000934:	1000                	addi	s0,sp,32
    80000936:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000938:	00007797          	auipc	a5,0x7
    8000093c:	15c7a783          	lw	a5,348(a5) # 80007a94 <panicking>
    80000940:	cf95                	beqz	a5,8000097c <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000942:	00007797          	auipc	a5,0x7
    80000946:	14e7a783          	lw	a5,334(a5) # 80007a90 <panicked>
    8000094a:	ef85                	bnez	a5,80000982 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094c:	10000737          	lui	a4,0x10000
    80000950:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000952:	00074783          	lbu	a5,0(a4)
    80000956:	0207f793          	andi	a5,a5,32
    8000095a:	dfe5                	beqz	a5,80000952 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095c:	0ff4f513          	zext.b	a0,s1
    80000960:	100007b7          	lui	a5,0x10000
    80000964:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000968:	00007797          	auipc	a5,0x7
    8000096c:	12c7a783          	lw	a5,300(a5) # 80007a94 <panicking>
    80000970:	cb91                	beqz	a5,80000984 <uartputc_sync+0x58>
    pop_off();
}
    80000972:	60e2                	ld	ra,24(sp)
    80000974:	6442                	ld	s0,16(sp)
    80000976:	64a2                	ld	s1,8(sp)
    80000978:	6105                	addi	sp,sp,32
    8000097a:	8082                	ret
    push_off();
    8000097c:	212000ef          	jal	80000b8e <push_off>
    80000980:	b7c9                	j	80000942 <uartputc_sync+0x16>
    for(;;)
    80000982:	a001                	j	80000982 <uartputc_sync+0x56>
    pop_off();
    80000984:	28e000ef          	jal	80000c12 <pop_off>
}
    80000988:	b7ed                	j	80000972 <uartputc_sync+0x46>

000000008000098a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000098a:	1141                	addi	sp,sp,-16
    8000098c:	e422                	sd	s0,8(sp)
    8000098e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000990:	100007b7          	lui	a5,0x10000
    80000994:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	0007c783          	lbu	a5,0(a5)
    8000099a:	8b85                	andi	a5,a5,1
    8000099c:	cb81                	beqz	a5,800009ac <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    8000099e:	100007b7          	lui	a5,0x10000
    800009a2:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009a6:	6422                	ld	s0,8(sp)
    800009a8:	0141                	addi	sp,sp,16
    800009aa:	8082                	ret
    return -1;
    800009ac:	557d                	li	a0,-1
    800009ae:	bfe5                	j	800009a6 <uartgetc+0x1c>

00000000800009b0 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009b0:	1101                	addi	sp,sp,-32
    800009b2:	ec06                	sd	ra,24(sp)
    800009b4:	e822                	sd	s0,16(sp)
    800009b6:	e426                	sd	s1,8(sp)
    800009b8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ba:	100007b7          	lui	a5,0x10000
    800009be:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009c0:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009c4:	0000f517          	auipc	a0,0xf
    800009c8:	1cc50513          	addi	a0,a0,460 # 8000fb90 <tx_lock>
    800009cc:	202000ef          	jal	80000bce <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    800009d0:	100007b7          	lui	a5,0x10000
    800009d4:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009d6:	0007c783          	lbu	a5,0(a5)
    800009da:	0207f793          	andi	a5,a5,32
    800009de:	eb89                	bnez	a5,800009f0 <uartintr+0x40>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009e0:	0000f517          	auipc	a0,0xf
    800009e4:	1b050513          	addi	a0,a0,432 # 8000fb90 <tx_lock>
    800009e8:	27e000ef          	jal	80000c66 <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009ec:	54fd                	li	s1,-1
    800009ee:	a831                	j	80000a0a <uartintr+0x5a>
    tx_busy = 0;
    800009f0:	00007797          	auipc	a5,0x7
    800009f4:	0a07a623          	sw	zero,172(a5) # 80007a9c <tx_busy>
    wakeup(&tx_chan);
    800009f8:	00007517          	auipc	a0,0x7
    800009fc:	0a050513          	addi	a0,a0,160 # 80007a98 <tx_chan>
    80000a00:	5e2010ef          	jal	80001fe2 <wakeup>
    80000a04:	bff1                	j	800009e0 <uartintr+0x30>
      break;
    consoleintr(c);
    80000a06:	8a5ff0ef          	jal	800002aa <consoleintr>
    int c = uartgetc();
    80000a0a:	f81ff0ef          	jal	8000098a <uartgetc>
    if(c == -1)
    80000a0e:	fe951ce3          	bne	a0,s1,80000a06 <uartintr+0x56>
  }
}
    80000a12:	60e2                	ld	ra,24(sp)
    80000a14:	6442                	ld	s0,16(sp)
    80000a16:	64a2                	ld	s1,8(sp)
    80000a18:	6105                	addi	sp,sp,32
    80000a1a:	8082                	ret

0000000080000a1c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a1c:	1101                	addi	sp,sp,-32
    80000a1e:	ec06                	sd	ra,24(sp)
    80000a20:	e822                	sd	s0,16(sp)
    80000a22:	e426                	sd	s1,8(sp)
    80000a24:	e04a                	sd	s2,0(sp)
    80000a26:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a28:	03451793          	slli	a5,a0,0x34
    80000a2c:	e7a9                	bnez	a5,80000a76 <kfree+0x5a>
    80000a2e:	84aa                	mv	s1,a0
    80000a30:	00020797          	auipc	a5,0x20
    80000a34:	7a878793          	addi	a5,a5,1960 # 800211d8 <end>
    80000a38:	02f56f63          	bltu	a0,a5,80000a76 <kfree+0x5a>
    80000a3c:	47c5                	li	a5,17
    80000a3e:	07ee                	slli	a5,a5,0x1b
    80000a40:	02f57b63          	bgeu	a0,a5,80000a76 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a44:	6605                	lui	a2,0x1
    80000a46:	4585                	li	a1,1
    80000a48:	25a000ef          	jal	80000ca2 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a4c:	0000f917          	auipc	s2,0xf
    80000a50:	15c90913          	addi	s2,s2,348 # 8000fba8 <kmem>
    80000a54:	854a                	mv	a0,s2
    80000a56:	178000ef          	jal	80000bce <acquire>
  r->next = kmem.freelist;
    80000a5a:	01893783          	ld	a5,24(s2)
    80000a5e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a60:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a64:	854a                	mv	a0,s2
    80000a66:	200000ef          	jal	80000c66 <release>
}
    80000a6a:	60e2                	ld	ra,24(sp)
    80000a6c:	6442                	ld	s0,16(sp)
    80000a6e:	64a2                	ld	s1,8(sp)
    80000a70:	6902                	ld	s2,0(sp)
    80000a72:	6105                	addi	sp,sp,32
    80000a74:	8082                	ret
    panic("kfree");
    80000a76:	00006517          	auipc	a0,0x6
    80000a7a:	5c250513          	addi	a0,a0,1474 # 80007038 <etext+0x38>
    80000a7e:	d63ff0ef          	jal	800007e0 <panic>

0000000080000a82 <freerange>:
{
    80000a82:	7179                	addi	sp,sp,-48
    80000a84:	f406                	sd	ra,40(sp)
    80000a86:	f022                	sd	s0,32(sp)
    80000a88:	ec26                	sd	s1,24(sp)
    80000a8a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a8c:	6785                	lui	a5,0x1
    80000a8e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a92:	00e504b3          	add	s1,a0,a4
    80000a96:	777d                	lui	a4,0xfffff
    80000a98:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a9a:	94be                	add	s1,s1,a5
    80000a9c:	0295e263          	bltu	a1,s1,80000ac0 <freerange+0x3e>
    80000aa0:	e84a                	sd	s2,16(sp)
    80000aa2:	e44e                	sd	s3,8(sp)
    80000aa4:	e052                	sd	s4,0(sp)
    80000aa6:	892e                	mv	s2,a1
    kfree(p);
    80000aa8:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000aaa:	6985                	lui	s3,0x1
    kfree(p);
    80000aac:	01448533          	add	a0,s1,s4
    80000ab0:	f6dff0ef          	jal	80000a1c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ab4:	94ce                	add	s1,s1,s3
    80000ab6:	fe997be3          	bgeu	s2,s1,80000aac <freerange+0x2a>
    80000aba:	6942                	ld	s2,16(sp)
    80000abc:	69a2                	ld	s3,8(sp)
    80000abe:	6a02                	ld	s4,0(sp)
}
    80000ac0:	70a2                	ld	ra,40(sp)
    80000ac2:	7402                	ld	s0,32(sp)
    80000ac4:	64e2                	ld	s1,24(sp)
    80000ac6:	6145                	addi	sp,sp,48
    80000ac8:	8082                	ret

0000000080000aca <kinit>:
{
    80000aca:	1141                	addi	sp,sp,-16
    80000acc:	e406                	sd	ra,8(sp)
    80000ace:	e022                	sd	s0,0(sp)
    80000ad0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ad2:	00006597          	auipc	a1,0x6
    80000ad6:	56e58593          	addi	a1,a1,1390 # 80007040 <etext+0x40>
    80000ada:	0000f517          	auipc	a0,0xf
    80000ade:	0ce50513          	addi	a0,a0,206 # 8000fba8 <kmem>
    80000ae2:	06c000ef          	jal	80000b4e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000ae6:	45c5                	li	a1,17
    80000ae8:	05ee                	slli	a1,a1,0x1b
    80000aea:	00020517          	auipc	a0,0x20
    80000aee:	6ee50513          	addi	a0,a0,1774 # 800211d8 <end>
    80000af2:	f91ff0ef          	jal	80000a82 <freerange>
}
    80000af6:	60a2                	ld	ra,8(sp)
    80000af8:	6402                	ld	s0,0(sp)
    80000afa:	0141                	addi	sp,sp,16
    80000afc:	8082                	ret

0000000080000afe <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000afe:	1101                	addi	sp,sp,-32
    80000b00:	ec06                	sd	ra,24(sp)
    80000b02:	e822                	sd	s0,16(sp)
    80000b04:	e426                	sd	s1,8(sp)
    80000b06:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b08:	0000f497          	auipc	s1,0xf
    80000b0c:	0a048493          	addi	s1,s1,160 # 8000fba8 <kmem>
    80000b10:	8526                	mv	a0,s1
    80000b12:	0bc000ef          	jal	80000bce <acquire>
  r = kmem.freelist;
    80000b16:	6c84                	ld	s1,24(s1)
  if(r)
    80000b18:	c485                	beqz	s1,80000b40 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b1a:	609c                	ld	a5,0(s1)
    80000b1c:	0000f517          	auipc	a0,0xf
    80000b20:	08c50513          	addi	a0,a0,140 # 8000fba8 <kmem>
    80000b24:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b26:	140000ef          	jal	80000c66 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b2a:	6605                	lui	a2,0x1
    80000b2c:	4595                	li	a1,5
    80000b2e:	8526                	mv	a0,s1
    80000b30:	172000ef          	jal	80000ca2 <memset>
  return (void*)r;
}
    80000b34:	8526                	mv	a0,s1
    80000b36:	60e2                	ld	ra,24(sp)
    80000b38:	6442                	ld	s0,16(sp)
    80000b3a:	64a2                	ld	s1,8(sp)
    80000b3c:	6105                	addi	sp,sp,32
    80000b3e:	8082                	ret
  release(&kmem.lock);
    80000b40:	0000f517          	auipc	a0,0xf
    80000b44:	06850513          	addi	a0,a0,104 # 8000fba8 <kmem>
    80000b48:	11e000ef          	jal	80000c66 <release>
  if(r)
    80000b4c:	b7e5                	j	80000b34 <kalloc+0x36>

0000000080000b4e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b4e:	1141                	addi	sp,sp,-16
    80000b50:	e422                	sd	s0,8(sp)
    80000b52:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b54:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b56:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b5a:	00053823          	sd	zero,16(a0)
}
    80000b5e:	6422                	ld	s0,8(sp)
    80000b60:	0141                	addi	sp,sp,16
    80000b62:	8082                	ret

0000000080000b64 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b64:	411c                	lw	a5,0(a0)
    80000b66:	e399                	bnez	a5,80000b6c <holding+0x8>
    80000b68:	4501                	li	a0,0
  return r;
}
    80000b6a:	8082                	ret
{
    80000b6c:	1101                	addi	sp,sp,-32
    80000b6e:	ec06                	sd	ra,24(sp)
    80000b70:	e822                	sd	s0,16(sp)
    80000b72:	e426                	sd	s1,8(sp)
    80000b74:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b76:	6904                	ld	s1,16(a0)
    80000b78:	59f000ef          	jal	80001916 <mycpu>
    80000b7c:	40a48533          	sub	a0,s1,a0
    80000b80:	00153513          	seqz	a0,a0
}
    80000b84:	60e2                	ld	ra,24(sp)
    80000b86:	6442                	ld	s0,16(sp)
    80000b88:	64a2                	ld	s1,8(sp)
    80000b8a:	6105                	addi	sp,sp,32
    80000b8c:	8082                	ret

0000000080000b8e <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b8e:	1101                	addi	sp,sp,-32
    80000b90:	ec06                	sd	ra,24(sp)
    80000b92:	e822                	sd	s0,16(sp)
    80000b94:	e426                	sd	s1,8(sp)
    80000b96:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b98:	100024f3          	csrr	s1,sstatus
    80000b9c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000ba0:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000ba2:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000ba6:	571000ef          	jal	80001916 <mycpu>
    80000baa:	5d3c                	lw	a5,120(a0)
    80000bac:	cb99                	beqz	a5,80000bc2 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bae:	569000ef          	jal	80001916 <mycpu>
    80000bb2:	5d3c                	lw	a5,120(a0)
    80000bb4:	2785                	addiw	a5,a5,1
    80000bb6:	dd3c                	sw	a5,120(a0)
}
    80000bb8:	60e2                	ld	ra,24(sp)
    80000bba:	6442                	ld	s0,16(sp)
    80000bbc:	64a2                	ld	s1,8(sp)
    80000bbe:	6105                	addi	sp,sp,32
    80000bc0:	8082                	ret
    mycpu()->intena = old;
    80000bc2:	555000ef          	jal	80001916 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bc6:	8085                	srli	s1,s1,0x1
    80000bc8:	8885                	andi	s1,s1,1
    80000bca:	dd64                	sw	s1,124(a0)
    80000bcc:	b7cd                	j	80000bae <push_off+0x20>

0000000080000bce <acquire>:
{
    80000bce:	1101                	addi	sp,sp,-32
    80000bd0:	ec06                	sd	ra,24(sp)
    80000bd2:	e822                	sd	s0,16(sp)
    80000bd4:	e426                	sd	s1,8(sp)
    80000bd6:	1000                	addi	s0,sp,32
    80000bd8:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bda:	fb5ff0ef          	jal	80000b8e <push_off>
  if(holding(lk))
    80000bde:	8526                	mv	a0,s1
    80000be0:	f85ff0ef          	jal	80000b64 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000be4:	4705                	li	a4,1
  if(holding(lk))
    80000be6:	e105                	bnez	a0,80000c06 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000be8:	87ba                	mv	a5,a4
    80000bea:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bee:	2781                	sext.w	a5,a5
    80000bf0:	ffe5                	bnez	a5,80000be8 <acquire+0x1a>
  __sync_synchronize();
    80000bf2:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000bf6:	521000ef          	jal	80001916 <mycpu>
    80000bfa:	e888                	sd	a0,16(s1)
}
    80000bfc:	60e2                	ld	ra,24(sp)
    80000bfe:	6442                	ld	s0,16(sp)
    80000c00:	64a2                	ld	s1,8(sp)
    80000c02:	6105                	addi	sp,sp,32
    80000c04:	8082                	ret
    panic("acquire");
    80000c06:	00006517          	auipc	a0,0x6
    80000c0a:	44250513          	addi	a0,a0,1090 # 80007048 <etext+0x48>
    80000c0e:	bd3ff0ef          	jal	800007e0 <panic>

0000000080000c12 <pop_off>:

void
pop_off(void)
{
    80000c12:	1141                	addi	sp,sp,-16
    80000c14:	e406                	sd	ra,8(sp)
    80000c16:	e022                	sd	s0,0(sp)
    80000c18:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c1a:	4fd000ef          	jal	80001916 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c1e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c22:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c24:	e78d                	bnez	a5,80000c4e <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c26:	5d3c                	lw	a5,120(a0)
    80000c28:	02f05963          	blez	a5,80000c5a <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c2c:	37fd                	addiw	a5,a5,-1
    80000c2e:	0007871b          	sext.w	a4,a5
    80000c32:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c34:	eb09                	bnez	a4,80000c46 <pop_off+0x34>
    80000c36:	5d7c                	lw	a5,124(a0)
    80000c38:	c799                	beqz	a5,80000c46 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c3a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c3e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c42:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c46:	60a2                	ld	ra,8(sp)
    80000c48:	6402                	ld	s0,0(sp)
    80000c4a:	0141                	addi	sp,sp,16
    80000c4c:	8082                	ret
    panic("pop_off - interruptible");
    80000c4e:	00006517          	auipc	a0,0x6
    80000c52:	40250513          	addi	a0,a0,1026 # 80007050 <etext+0x50>
    80000c56:	b8bff0ef          	jal	800007e0 <panic>
    panic("pop_off");
    80000c5a:	00006517          	auipc	a0,0x6
    80000c5e:	40e50513          	addi	a0,a0,1038 # 80007068 <etext+0x68>
    80000c62:	b7fff0ef          	jal	800007e0 <panic>

0000000080000c66 <release>:
{
    80000c66:	1101                	addi	sp,sp,-32
    80000c68:	ec06                	sd	ra,24(sp)
    80000c6a:	e822                	sd	s0,16(sp)
    80000c6c:	e426                	sd	s1,8(sp)
    80000c6e:	1000                	addi	s0,sp,32
    80000c70:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c72:	ef3ff0ef          	jal	80000b64 <holding>
    80000c76:	c105                	beqz	a0,80000c96 <release+0x30>
  lk->cpu = 0;
    80000c78:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000c7c:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000c80:	0f50000f          	fence	iorw,ow
    80000c84:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000c88:	f8bff0ef          	jal	80000c12 <pop_off>
}
    80000c8c:	60e2                	ld	ra,24(sp)
    80000c8e:	6442                	ld	s0,16(sp)
    80000c90:	64a2                	ld	s1,8(sp)
    80000c92:	6105                	addi	sp,sp,32
    80000c94:	8082                	ret
    panic("release");
    80000c96:	00006517          	auipc	a0,0x6
    80000c9a:	3da50513          	addi	a0,a0,986 # 80007070 <etext+0x70>
    80000c9e:	b43ff0ef          	jal	800007e0 <panic>

0000000080000ca2 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000ca2:	1141                	addi	sp,sp,-16
    80000ca4:	e422                	sd	s0,8(sp)
    80000ca6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000ca8:	ca19                	beqz	a2,80000cbe <memset+0x1c>
    80000caa:	87aa                	mv	a5,a0
    80000cac:	1602                	slli	a2,a2,0x20
    80000cae:	9201                	srli	a2,a2,0x20
    80000cb0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cb4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000cb8:	0785                	addi	a5,a5,1
    80000cba:	fee79de3          	bne	a5,a4,80000cb4 <memset+0x12>
  }
  return dst;
}
    80000cbe:	6422                	ld	s0,8(sp)
    80000cc0:	0141                	addi	sp,sp,16
    80000cc2:	8082                	ret

0000000080000cc4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cc4:	1141                	addi	sp,sp,-16
    80000cc6:	e422                	sd	s0,8(sp)
    80000cc8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cca:	ca05                	beqz	a2,80000cfa <memcmp+0x36>
    80000ccc:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000cd0:	1682                	slli	a3,a3,0x20
    80000cd2:	9281                	srli	a3,a3,0x20
    80000cd4:	0685                	addi	a3,a3,1
    80000cd6:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000cd8:	00054783          	lbu	a5,0(a0)
    80000cdc:	0005c703          	lbu	a4,0(a1)
    80000ce0:	00e79863          	bne	a5,a4,80000cf0 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000ce4:	0505                	addi	a0,a0,1
    80000ce6:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000ce8:	fed518e3          	bne	a0,a3,80000cd8 <memcmp+0x14>
  }

  return 0;
    80000cec:	4501                	li	a0,0
    80000cee:	a019                	j	80000cf4 <memcmp+0x30>
      return *s1 - *s2;
    80000cf0:	40e7853b          	subw	a0,a5,a4
}
    80000cf4:	6422                	ld	s0,8(sp)
    80000cf6:	0141                	addi	sp,sp,16
    80000cf8:	8082                	ret
  return 0;
    80000cfa:	4501                	li	a0,0
    80000cfc:	bfe5                	j	80000cf4 <memcmp+0x30>

0000000080000cfe <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000cfe:	1141                	addi	sp,sp,-16
    80000d00:	e422                	sd	s0,8(sp)
    80000d02:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d04:	c205                	beqz	a2,80000d24 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d06:	02a5e263          	bltu	a1,a0,80000d2a <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d0a:	1602                	slli	a2,a2,0x20
    80000d0c:	9201                	srli	a2,a2,0x20
    80000d0e:	00c587b3          	add	a5,a1,a2
{
    80000d12:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d14:	0585                	addi	a1,a1,1
    80000d16:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdde29>
    80000d18:	fff5c683          	lbu	a3,-1(a1)
    80000d1c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d20:	feb79ae3          	bne	a5,a1,80000d14 <memmove+0x16>

  return dst;
}
    80000d24:	6422                	ld	s0,8(sp)
    80000d26:	0141                	addi	sp,sp,16
    80000d28:	8082                	ret
  if(s < d && s + n > d){
    80000d2a:	02061693          	slli	a3,a2,0x20
    80000d2e:	9281                	srli	a3,a3,0x20
    80000d30:	00d58733          	add	a4,a1,a3
    80000d34:	fce57be3          	bgeu	a0,a4,80000d0a <memmove+0xc>
    d += n;
    80000d38:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d3a:	fff6079b          	addiw	a5,a2,-1
    80000d3e:	1782                	slli	a5,a5,0x20
    80000d40:	9381                	srli	a5,a5,0x20
    80000d42:	fff7c793          	not	a5,a5
    80000d46:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d48:	177d                	addi	a4,a4,-1
    80000d4a:	16fd                	addi	a3,a3,-1
    80000d4c:	00074603          	lbu	a2,0(a4)
    80000d50:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d54:	fef71ae3          	bne	a4,a5,80000d48 <memmove+0x4a>
    80000d58:	b7f1                	j	80000d24 <memmove+0x26>

0000000080000d5a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d5a:	1141                	addi	sp,sp,-16
    80000d5c:	e406                	sd	ra,8(sp)
    80000d5e:	e022                	sd	s0,0(sp)
    80000d60:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d62:	f9dff0ef          	jal	80000cfe <memmove>
}
    80000d66:	60a2                	ld	ra,8(sp)
    80000d68:	6402                	ld	s0,0(sp)
    80000d6a:	0141                	addi	sp,sp,16
    80000d6c:	8082                	ret

0000000080000d6e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d6e:	1141                	addi	sp,sp,-16
    80000d70:	e422                	sd	s0,8(sp)
    80000d72:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d74:	ce11                	beqz	a2,80000d90 <strncmp+0x22>
    80000d76:	00054783          	lbu	a5,0(a0)
    80000d7a:	cf89                	beqz	a5,80000d94 <strncmp+0x26>
    80000d7c:	0005c703          	lbu	a4,0(a1)
    80000d80:	00f71a63          	bne	a4,a5,80000d94 <strncmp+0x26>
    n--, p++, q++;
    80000d84:	367d                	addiw	a2,a2,-1
    80000d86:	0505                	addi	a0,a0,1
    80000d88:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000d8a:	f675                	bnez	a2,80000d76 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000d8c:	4501                	li	a0,0
    80000d8e:	a801                	j	80000d9e <strncmp+0x30>
    80000d90:	4501                	li	a0,0
    80000d92:	a031                	j	80000d9e <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000d94:	00054503          	lbu	a0,0(a0)
    80000d98:	0005c783          	lbu	a5,0(a1)
    80000d9c:	9d1d                	subw	a0,a0,a5
}
    80000d9e:	6422                	ld	s0,8(sp)
    80000da0:	0141                	addi	sp,sp,16
    80000da2:	8082                	ret

0000000080000da4 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000da4:	1141                	addi	sp,sp,-16
    80000da6:	e422                	sd	s0,8(sp)
    80000da8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000daa:	87aa                	mv	a5,a0
    80000dac:	86b2                	mv	a3,a2
    80000dae:	367d                	addiw	a2,a2,-1
    80000db0:	02d05563          	blez	a3,80000dda <strncpy+0x36>
    80000db4:	0785                	addi	a5,a5,1
    80000db6:	0005c703          	lbu	a4,0(a1)
    80000dba:	fee78fa3          	sb	a4,-1(a5)
    80000dbe:	0585                	addi	a1,a1,1
    80000dc0:	f775                	bnez	a4,80000dac <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dc2:	873e                	mv	a4,a5
    80000dc4:	9fb5                	addw	a5,a5,a3
    80000dc6:	37fd                	addiw	a5,a5,-1
    80000dc8:	00c05963          	blez	a2,80000dda <strncpy+0x36>
    *s++ = 0;
    80000dcc:	0705                	addi	a4,a4,1
    80000dce:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000dd2:	40e786bb          	subw	a3,a5,a4
    80000dd6:	fed04be3          	bgtz	a3,80000dcc <strncpy+0x28>
  return os;
}
    80000dda:	6422                	ld	s0,8(sp)
    80000ddc:	0141                	addi	sp,sp,16
    80000dde:	8082                	ret

0000000080000de0 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000de0:	1141                	addi	sp,sp,-16
    80000de2:	e422                	sd	s0,8(sp)
    80000de4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000de6:	02c05363          	blez	a2,80000e0c <safestrcpy+0x2c>
    80000dea:	fff6069b          	addiw	a3,a2,-1
    80000dee:	1682                	slli	a3,a3,0x20
    80000df0:	9281                	srli	a3,a3,0x20
    80000df2:	96ae                	add	a3,a3,a1
    80000df4:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000df6:	00d58963          	beq	a1,a3,80000e08 <safestrcpy+0x28>
    80000dfa:	0585                	addi	a1,a1,1
    80000dfc:	0785                	addi	a5,a5,1
    80000dfe:	fff5c703          	lbu	a4,-1(a1)
    80000e02:	fee78fa3          	sb	a4,-1(a5)
    80000e06:	fb65                	bnez	a4,80000df6 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e08:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e0c:	6422                	ld	s0,8(sp)
    80000e0e:	0141                	addi	sp,sp,16
    80000e10:	8082                	ret

0000000080000e12 <strlen>:

int
strlen(const char *s)
{
    80000e12:	1141                	addi	sp,sp,-16
    80000e14:	e422                	sd	s0,8(sp)
    80000e16:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e18:	00054783          	lbu	a5,0(a0)
    80000e1c:	cf91                	beqz	a5,80000e38 <strlen+0x26>
    80000e1e:	0505                	addi	a0,a0,1
    80000e20:	87aa                	mv	a5,a0
    80000e22:	86be                	mv	a3,a5
    80000e24:	0785                	addi	a5,a5,1
    80000e26:	fff7c703          	lbu	a4,-1(a5)
    80000e2a:	ff65                	bnez	a4,80000e22 <strlen+0x10>
    80000e2c:	40a6853b          	subw	a0,a3,a0
    80000e30:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000e32:	6422                	ld	s0,8(sp)
    80000e34:	0141                	addi	sp,sp,16
    80000e36:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e38:	4501                	li	a0,0
    80000e3a:	bfe5                	j	80000e32 <strlen+0x20>

0000000080000e3c <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e3c:	1141                	addi	sp,sp,-16
    80000e3e:	e406                	sd	ra,8(sp)
    80000e40:	e022                	sd	s0,0(sp)
    80000e42:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e44:	2c3000ef          	jal	80001906 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e48:	00007717          	auipc	a4,0x7
    80000e4c:	c5870713          	addi	a4,a4,-936 # 80007aa0 <started>
  if(cpuid() == 0){
    80000e50:	c51d                	beqz	a0,80000e7e <main+0x42>
    while(started == 0)
    80000e52:	431c                	lw	a5,0(a4)
    80000e54:	2781                	sext.w	a5,a5
    80000e56:	dff5                	beqz	a5,80000e52 <main+0x16>
      ;
    __sync_synchronize();
    80000e58:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e5c:	2ab000ef          	jal	80001906 <cpuid>
    80000e60:	85aa                	mv	a1,a0
    80000e62:	00006517          	auipc	a0,0x6
    80000e66:	23650513          	addi	a0,a0,566 # 80007098 <etext+0x98>
    80000e6a:	e90ff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000e6e:	080000ef          	jal	80000eee <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e72:	7e4010ef          	jal	80002656 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e76:	073040ef          	jal	800056e8 <plicinithart>
  }

  scheduler();        
    80000e7a:	72d000ef          	jal	80001da6 <scheduler>
    consoleinit();
    80000e7e:	da6ff0ef          	jal	80000424 <consoleinit>
    printfinit();
    80000e82:	99bff0ef          	jal	8000081c <printfinit>
    printf("\n");
    80000e86:	00006517          	auipc	a0,0x6
    80000e8a:	1f250513          	addi	a0,a0,498 # 80007078 <etext+0x78>
    80000e8e:	e6cff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000e92:	00006517          	auipc	a0,0x6
    80000e96:	1ee50513          	addi	a0,a0,494 # 80007080 <etext+0x80>
    80000e9a:	e60ff0ef          	jal	800004fa <printf>
    printf("\n");
    80000e9e:	00006517          	auipc	a0,0x6
    80000ea2:	1da50513          	addi	a0,a0,474 # 80007078 <etext+0x78>
    80000ea6:	e54ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000eaa:	c21ff0ef          	jal	80000aca <kinit>
    kvminit();       // create kernel page table
    80000eae:	2ca000ef          	jal	80001178 <kvminit>
    kvminithart();   // turn on paging
    80000eb2:	03c000ef          	jal	80000eee <kvminithart>
    procinit();      // process table
    80000eb6:	19b000ef          	jal	80001850 <procinit>
    trapinit();      // trap vectors
    80000eba:	778010ef          	jal	80002632 <trapinit>
    trapinithart();  // install kernel trap vector
    80000ebe:	798010ef          	jal	80002656 <trapinithart>
    plicinit();      // set up interrupt controller
    80000ec2:	00d040ef          	jal	800056ce <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000ec6:	023040ef          	jal	800056e8 <plicinithart>
    binit();         // buffer cache
    80000eca:	6db010ef          	jal	80002da4 <binit>
    iinit();         // inode table
    80000ece:	460020ef          	jal	8000332e <iinit>
    fileinit();      // file table
    80000ed2:	352030ef          	jal	80004224 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000ed6:	103040ef          	jal	800057d8 <virtio_disk_init>
    userinit();      // first user process
    80000eda:	533000ef          	jal	80001c0c <userinit>
    __sync_synchronize();
    80000ede:	0ff0000f          	fence
    started = 1;
    80000ee2:	4785                	li	a5,1
    80000ee4:	00007717          	auipc	a4,0x7
    80000ee8:	baf72e23          	sw	a5,-1092(a4) # 80007aa0 <started>
    80000eec:	b779                	j	80000e7a <main+0x3e>

0000000080000eee <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000eee:	1141                	addi	sp,sp,-16
    80000ef0:	e422                	sd	s0,8(sp)
    80000ef2:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000ef4:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000ef8:	00007797          	auipc	a5,0x7
    80000efc:	bb07b783          	ld	a5,-1104(a5) # 80007aa8 <kernel_pagetable>
    80000f00:	83b1                	srli	a5,a5,0xc
    80000f02:	577d                	li	a4,-1
    80000f04:	177e                	slli	a4,a4,0x3f
    80000f06:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f08:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f0c:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f10:	6422                	ld	s0,8(sp)
    80000f12:	0141                	addi	sp,sp,16
    80000f14:	8082                	ret

0000000080000f16 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f16:	7139                	addi	sp,sp,-64
    80000f18:	fc06                	sd	ra,56(sp)
    80000f1a:	f822                	sd	s0,48(sp)
    80000f1c:	f426                	sd	s1,40(sp)
    80000f1e:	f04a                	sd	s2,32(sp)
    80000f20:	ec4e                	sd	s3,24(sp)
    80000f22:	e852                	sd	s4,16(sp)
    80000f24:	e456                	sd	s5,8(sp)
    80000f26:	e05a                	sd	s6,0(sp)
    80000f28:	0080                	addi	s0,sp,64
    80000f2a:	84aa                	mv	s1,a0
    80000f2c:	89ae                	mv	s3,a1
    80000f2e:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f30:	57fd                	li	a5,-1
    80000f32:	83e9                	srli	a5,a5,0x1a
    80000f34:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f36:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f38:	02b7fc63          	bgeu	a5,a1,80000f70 <walk+0x5a>
    panic("walk");
    80000f3c:	00006517          	auipc	a0,0x6
    80000f40:	17450513          	addi	a0,a0,372 # 800070b0 <etext+0xb0>
    80000f44:	89dff0ef          	jal	800007e0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f48:	060a8263          	beqz	s5,80000fac <walk+0x96>
    80000f4c:	bb3ff0ef          	jal	80000afe <kalloc>
    80000f50:	84aa                	mv	s1,a0
    80000f52:	c139                	beqz	a0,80000f98 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f54:	6605                	lui	a2,0x1
    80000f56:	4581                	li	a1,0
    80000f58:	d4bff0ef          	jal	80000ca2 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f5c:	00c4d793          	srli	a5,s1,0xc
    80000f60:	07aa                	slli	a5,a5,0xa
    80000f62:	0017e793          	ori	a5,a5,1
    80000f66:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f6a:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdde1f>
    80000f6c:	036a0063          	beq	s4,s6,80000f8c <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f70:	0149d933          	srl	s2,s3,s4
    80000f74:	1ff97913          	andi	s2,s2,511
    80000f78:	090e                	slli	s2,s2,0x3
    80000f7a:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000f7c:	00093483          	ld	s1,0(s2)
    80000f80:	0014f793          	andi	a5,s1,1
    80000f84:	d3f1                	beqz	a5,80000f48 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f86:	80a9                	srli	s1,s1,0xa
    80000f88:	04b2                	slli	s1,s1,0xc
    80000f8a:	b7c5                	j	80000f6a <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f8c:	00c9d513          	srli	a0,s3,0xc
    80000f90:	1ff57513          	andi	a0,a0,511
    80000f94:	050e                	slli	a0,a0,0x3
    80000f96:	9526                	add	a0,a0,s1
}
    80000f98:	70e2                	ld	ra,56(sp)
    80000f9a:	7442                	ld	s0,48(sp)
    80000f9c:	74a2                	ld	s1,40(sp)
    80000f9e:	7902                	ld	s2,32(sp)
    80000fa0:	69e2                	ld	s3,24(sp)
    80000fa2:	6a42                	ld	s4,16(sp)
    80000fa4:	6aa2                	ld	s5,8(sp)
    80000fa6:	6b02                	ld	s6,0(sp)
    80000fa8:	6121                	addi	sp,sp,64
    80000faa:	8082                	ret
        return 0;
    80000fac:	4501                	li	a0,0
    80000fae:	b7ed                	j	80000f98 <walk+0x82>

0000000080000fb0 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000fb0:	57fd                	li	a5,-1
    80000fb2:	83e9                	srli	a5,a5,0x1a
    80000fb4:	00b7f463          	bgeu	a5,a1,80000fbc <walkaddr+0xc>
    return 0;
    80000fb8:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fba:	8082                	ret
{
    80000fbc:	1141                	addi	sp,sp,-16
    80000fbe:	e406                	sd	ra,8(sp)
    80000fc0:	e022                	sd	s0,0(sp)
    80000fc2:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fc4:	4601                	li	a2,0
    80000fc6:	f51ff0ef          	jal	80000f16 <walk>
  if(pte == 0)
    80000fca:	c105                	beqz	a0,80000fea <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000fcc:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000fce:	0117f693          	andi	a3,a5,17
    80000fd2:	4745                	li	a4,17
    return 0;
    80000fd4:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000fd6:	00e68663          	beq	a3,a4,80000fe2 <walkaddr+0x32>
}
    80000fda:	60a2                	ld	ra,8(sp)
    80000fdc:	6402                	ld	s0,0(sp)
    80000fde:	0141                	addi	sp,sp,16
    80000fe0:	8082                	ret
  pa = PTE2PA(*pte);
    80000fe2:	83a9                	srli	a5,a5,0xa
    80000fe4:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000fe8:	bfcd                	j	80000fda <walkaddr+0x2a>
    return 0;
    80000fea:	4501                	li	a0,0
    80000fec:	b7fd                	j	80000fda <walkaddr+0x2a>

0000000080000fee <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fee:	715d                	addi	sp,sp,-80
    80000ff0:	e486                	sd	ra,72(sp)
    80000ff2:	e0a2                	sd	s0,64(sp)
    80000ff4:	fc26                	sd	s1,56(sp)
    80000ff6:	f84a                	sd	s2,48(sp)
    80000ff8:	f44e                	sd	s3,40(sp)
    80000ffa:	f052                	sd	s4,32(sp)
    80000ffc:	ec56                	sd	s5,24(sp)
    80000ffe:	e85a                	sd	s6,16(sp)
    80001000:	e45e                	sd	s7,8(sp)
    80001002:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001004:	03459793          	slli	a5,a1,0x34
    80001008:	e7a9                	bnez	a5,80001052 <mappages+0x64>
    8000100a:	8aaa                	mv	s5,a0
    8000100c:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000100e:	03461793          	slli	a5,a2,0x34
    80001012:	e7b1                	bnez	a5,8000105e <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80001014:	ca39                	beqz	a2,8000106a <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001016:	77fd                	lui	a5,0xfffff
    80001018:	963e                	add	a2,a2,a5
    8000101a:	00b609b3          	add	s3,a2,a1
  a = va;
    8000101e:	892e                	mv	s2,a1
    80001020:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001024:	6b85                	lui	s7,0x1
    80001026:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    8000102a:	4605                	li	a2,1
    8000102c:	85ca                	mv	a1,s2
    8000102e:	8556                	mv	a0,s5
    80001030:	ee7ff0ef          	jal	80000f16 <walk>
    80001034:	c539                	beqz	a0,80001082 <mappages+0x94>
    if(*pte & PTE_V)
    80001036:	611c                	ld	a5,0(a0)
    80001038:	8b85                	andi	a5,a5,1
    8000103a:	ef95                	bnez	a5,80001076 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000103c:	80b1                	srli	s1,s1,0xc
    8000103e:	04aa                	slli	s1,s1,0xa
    80001040:	0164e4b3          	or	s1,s1,s6
    80001044:	0014e493          	ori	s1,s1,1
    80001048:	e104                	sd	s1,0(a0)
    if(a == last)
    8000104a:	05390863          	beq	s2,s3,8000109a <mappages+0xac>
    a += PGSIZE;
    8000104e:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001050:	bfd9                	j	80001026 <mappages+0x38>
    panic("mappages: va not aligned");
    80001052:	00006517          	auipc	a0,0x6
    80001056:	06650513          	addi	a0,a0,102 # 800070b8 <etext+0xb8>
    8000105a:	f86ff0ef          	jal	800007e0 <panic>
    panic("mappages: size not aligned");
    8000105e:	00006517          	auipc	a0,0x6
    80001062:	07a50513          	addi	a0,a0,122 # 800070d8 <etext+0xd8>
    80001066:	f7aff0ef          	jal	800007e0 <panic>
    panic("mappages: size");
    8000106a:	00006517          	auipc	a0,0x6
    8000106e:	08e50513          	addi	a0,a0,142 # 800070f8 <etext+0xf8>
    80001072:	f6eff0ef          	jal	800007e0 <panic>
      panic("mappages: remap");
    80001076:	00006517          	auipc	a0,0x6
    8000107a:	09250513          	addi	a0,a0,146 # 80007108 <etext+0x108>
    8000107e:	f62ff0ef          	jal	800007e0 <panic>
      return -1;
    80001082:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001084:	60a6                	ld	ra,72(sp)
    80001086:	6406                	ld	s0,64(sp)
    80001088:	74e2                	ld	s1,56(sp)
    8000108a:	7942                	ld	s2,48(sp)
    8000108c:	79a2                	ld	s3,40(sp)
    8000108e:	7a02                	ld	s4,32(sp)
    80001090:	6ae2                	ld	s5,24(sp)
    80001092:	6b42                	ld	s6,16(sp)
    80001094:	6ba2                	ld	s7,8(sp)
    80001096:	6161                	addi	sp,sp,80
    80001098:	8082                	ret
  return 0;
    8000109a:	4501                	li	a0,0
    8000109c:	b7e5                	j	80001084 <mappages+0x96>

000000008000109e <kvmmap>:
{
    8000109e:	1141                	addi	sp,sp,-16
    800010a0:	e406                	sd	ra,8(sp)
    800010a2:	e022                	sd	s0,0(sp)
    800010a4:	0800                	addi	s0,sp,16
    800010a6:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010a8:	86b2                	mv	a3,a2
    800010aa:	863e                	mv	a2,a5
    800010ac:	f43ff0ef          	jal	80000fee <mappages>
    800010b0:	e509                	bnez	a0,800010ba <kvmmap+0x1c>
}
    800010b2:	60a2                	ld	ra,8(sp)
    800010b4:	6402                	ld	s0,0(sp)
    800010b6:	0141                	addi	sp,sp,16
    800010b8:	8082                	ret
    panic("kvmmap");
    800010ba:	00006517          	auipc	a0,0x6
    800010be:	05e50513          	addi	a0,a0,94 # 80007118 <etext+0x118>
    800010c2:	f1eff0ef          	jal	800007e0 <panic>

00000000800010c6 <kvmmake>:
{
    800010c6:	1101                	addi	sp,sp,-32
    800010c8:	ec06                	sd	ra,24(sp)
    800010ca:	e822                	sd	s0,16(sp)
    800010cc:	e426                	sd	s1,8(sp)
    800010ce:	e04a                	sd	s2,0(sp)
    800010d0:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800010d2:	a2dff0ef          	jal	80000afe <kalloc>
    800010d6:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010d8:	6605                	lui	a2,0x1
    800010da:	4581                	li	a1,0
    800010dc:	bc7ff0ef          	jal	80000ca2 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800010e0:	4719                	li	a4,6
    800010e2:	6685                	lui	a3,0x1
    800010e4:	10000637          	lui	a2,0x10000
    800010e8:	100005b7          	lui	a1,0x10000
    800010ec:	8526                	mv	a0,s1
    800010ee:	fb1ff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010f2:	4719                	li	a4,6
    800010f4:	6685                	lui	a3,0x1
    800010f6:	10001637          	lui	a2,0x10001
    800010fa:	100015b7          	lui	a1,0x10001
    800010fe:	8526                	mv	a0,s1
    80001100:	f9fff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001104:	4719                	li	a4,6
    80001106:	040006b7          	lui	a3,0x4000
    8000110a:	0c000637          	lui	a2,0xc000
    8000110e:	0c0005b7          	lui	a1,0xc000
    80001112:	8526                	mv	a0,s1
    80001114:	f8bff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001118:	00006917          	auipc	s2,0x6
    8000111c:	ee890913          	addi	s2,s2,-280 # 80007000 <etext>
    80001120:	4729                	li	a4,10
    80001122:	80006697          	auipc	a3,0x80006
    80001126:	ede68693          	addi	a3,a3,-290 # 7000 <_entry-0x7fff9000>
    8000112a:	4605                	li	a2,1
    8000112c:	067e                	slli	a2,a2,0x1f
    8000112e:	85b2                	mv	a1,a2
    80001130:	8526                	mv	a0,s1
    80001132:	f6dff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001136:	46c5                	li	a3,17
    80001138:	06ee                	slli	a3,a3,0x1b
    8000113a:	4719                	li	a4,6
    8000113c:	412686b3          	sub	a3,a3,s2
    80001140:	864a                	mv	a2,s2
    80001142:	85ca                	mv	a1,s2
    80001144:	8526                	mv	a0,s1
    80001146:	f59ff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000114a:	4729                	li	a4,10
    8000114c:	6685                	lui	a3,0x1
    8000114e:	00005617          	auipc	a2,0x5
    80001152:	eb260613          	addi	a2,a2,-334 # 80006000 <_trampoline>
    80001156:	040005b7          	lui	a1,0x4000
    8000115a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000115c:	05b2                	slli	a1,a1,0xc
    8000115e:	8526                	mv	a0,s1
    80001160:	f3fff0ef          	jal	8000109e <kvmmap>
  proc_mapstacks(kpgtbl);
    80001164:	8526                	mv	a0,s1
    80001166:	652000ef          	jal	800017b8 <proc_mapstacks>
}
    8000116a:	8526                	mv	a0,s1
    8000116c:	60e2                	ld	ra,24(sp)
    8000116e:	6442                	ld	s0,16(sp)
    80001170:	64a2                	ld	s1,8(sp)
    80001172:	6902                	ld	s2,0(sp)
    80001174:	6105                	addi	sp,sp,32
    80001176:	8082                	ret

0000000080001178 <kvminit>:
{
    80001178:	1141                	addi	sp,sp,-16
    8000117a:	e406                	sd	ra,8(sp)
    8000117c:	e022                	sd	s0,0(sp)
    8000117e:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001180:	f47ff0ef          	jal	800010c6 <kvmmake>
    80001184:	00007797          	auipc	a5,0x7
    80001188:	92a7b223          	sd	a0,-1756(a5) # 80007aa8 <kernel_pagetable>
}
    8000118c:	60a2                	ld	ra,8(sp)
    8000118e:	6402                	ld	s0,0(sp)
    80001190:	0141                	addi	sp,sp,16
    80001192:	8082                	ret

0000000080001194 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001194:	1101                	addi	sp,sp,-32
    80001196:	ec06                	sd	ra,24(sp)
    80001198:	e822                	sd	s0,16(sp)
    8000119a:	e426                	sd	s1,8(sp)
    8000119c:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000119e:	961ff0ef          	jal	80000afe <kalloc>
    800011a2:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800011a4:	c509                	beqz	a0,800011ae <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011a6:	6605                	lui	a2,0x1
    800011a8:	4581                	li	a1,0
    800011aa:	af9ff0ef          	jal	80000ca2 <memset>
  return pagetable;
}
    800011ae:	8526                	mv	a0,s1
    800011b0:	60e2                	ld	ra,24(sp)
    800011b2:	6442                	ld	s0,16(sp)
    800011b4:	64a2                	ld	s1,8(sp)
    800011b6:	6105                	addi	sp,sp,32
    800011b8:	8082                	ret

00000000800011ba <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011ba:	7139                	addi	sp,sp,-64
    800011bc:	fc06                	sd	ra,56(sp)
    800011be:	f822                	sd	s0,48(sp)
    800011c0:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800011c2:	03459793          	slli	a5,a1,0x34
    800011c6:	e38d                	bnez	a5,800011e8 <uvmunmap+0x2e>
    800011c8:	f04a                	sd	s2,32(sp)
    800011ca:	ec4e                	sd	s3,24(sp)
    800011cc:	e852                	sd	s4,16(sp)
    800011ce:	e456                	sd	s5,8(sp)
    800011d0:	e05a                	sd	s6,0(sp)
    800011d2:	8a2a                	mv	s4,a0
    800011d4:	892e                	mv	s2,a1
    800011d6:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011d8:	0632                	slli	a2,a2,0xc
    800011da:	00b609b3          	add	s3,a2,a1
    800011de:	6b05                	lui	s6,0x1
    800011e0:	0535f963          	bgeu	a1,s3,80001232 <uvmunmap+0x78>
    800011e4:	f426                	sd	s1,40(sp)
    800011e6:	a015                	j	8000120a <uvmunmap+0x50>
    800011e8:	f426                	sd	s1,40(sp)
    800011ea:	f04a                	sd	s2,32(sp)
    800011ec:	ec4e                	sd	s3,24(sp)
    800011ee:	e852                	sd	s4,16(sp)
    800011f0:	e456                	sd	s5,8(sp)
    800011f2:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011f4:	00006517          	auipc	a0,0x6
    800011f8:	f2c50513          	addi	a0,a0,-212 # 80007120 <etext+0x120>
    800011fc:	de4ff0ef          	jal	800007e0 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001200:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001204:	995a                	add	s2,s2,s6
    80001206:	03397563          	bgeu	s2,s3,80001230 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000120a:	4601                	li	a2,0
    8000120c:	85ca                	mv	a1,s2
    8000120e:	8552                	mv	a0,s4
    80001210:	d07ff0ef          	jal	80000f16 <walk>
    80001214:	84aa                	mv	s1,a0
    80001216:	d57d                	beqz	a0,80001204 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001218:	611c                	ld	a5,0(a0)
    8000121a:	0017f713          	andi	a4,a5,1
    8000121e:	d37d                	beqz	a4,80001204 <uvmunmap+0x4a>
    if(do_free){
    80001220:	fe0a80e3          	beqz	s5,80001200 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001224:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001226:	00c79513          	slli	a0,a5,0xc
    8000122a:	ff2ff0ef          	jal	80000a1c <kfree>
    8000122e:	bfc9                	j	80001200 <uvmunmap+0x46>
    80001230:	74a2                	ld	s1,40(sp)
    80001232:	7902                	ld	s2,32(sp)
    80001234:	69e2                	ld	s3,24(sp)
    80001236:	6a42                	ld	s4,16(sp)
    80001238:	6aa2                	ld	s5,8(sp)
    8000123a:	6b02                	ld	s6,0(sp)
  }
}
    8000123c:	70e2                	ld	ra,56(sp)
    8000123e:	7442                	ld	s0,48(sp)
    80001240:	6121                	addi	sp,sp,64
    80001242:	8082                	ret

0000000080001244 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001244:	1101                	addi	sp,sp,-32
    80001246:	ec06                	sd	ra,24(sp)
    80001248:	e822                	sd	s0,16(sp)
    8000124a:	e426                	sd	s1,8(sp)
    8000124c:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    8000124e:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80001250:	00b67d63          	bgeu	a2,a1,8000126a <uvmdealloc+0x26>
    80001254:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001256:	6785                	lui	a5,0x1
    80001258:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000125a:	00f60733          	add	a4,a2,a5
    8000125e:	76fd                	lui	a3,0xfffff
    80001260:	8f75                	and	a4,a4,a3
    80001262:	97ae                	add	a5,a5,a1
    80001264:	8ff5                	and	a5,a5,a3
    80001266:	00f76863          	bltu	a4,a5,80001276 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    8000126a:	8526                	mv	a0,s1
    8000126c:	60e2                	ld	ra,24(sp)
    8000126e:	6442                	ld	s0,16(sp)
    80001270:	64a2                	ld	s1,8(sp)
    80001272:	6105                	addi	sp,sp,32
    80001274:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001276:	8f99                	sub	a5,a5,a4
    80001278:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000127a:	4685                	li	a3,1
    8000127c:	0007861b          	sext.w	a2,a5
    80001280:	85ba                	mv	a1,a4
    80001282:	f39ff0ef          	jal	800011ba <uvmunmap>
    80001286:	b7d5                	j	8000126a <uvmdealloc+0x26>

0000000080001288 <uvmalloc>:
  if(newsz < oldsz)
    80001288:	08b66f63          	bltu	a2,a1,80001326 <uvmalloc+0x9e>
{
    8000128c:	7139                	addi	sp,sp,-64
    8000128e:	fc06                	sd	ra,56(sp)
    80001290:	f822                	sd	s0,48(sp)
    80001292:	ec4e                	sd	s3,24(sp)
    80001294:	e852                	sd	s4,16(sp)
    80001296:	e456                	sd	s5,8(sp)
    80001298:	0080                	addi	s0,sp,64
    8000129a:	8aaa                	mv	s5,a0
    8000129c:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000129e:	6785                	lui	a5,0x1
    800012a0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012a2:	95be                	add	a1,a1,a5
    800012a4:	77fd                	lui	a5,0xfffff
    800012a6:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012aa:	08c9f063          	bgeu	s3,a2,8000132a <uvmalloc+0xa2>
    800012ae:	f426                	sd	s1,40(sp)
    800012b0:	f04a                	sd	s2,32(sp)
    800012b2:	e05a                	sd	s6,0(sp)
    800012b4:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012b6:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012ba:	845ff0ef          	jal	80000afe <kalloc>
    800012be:	84aa                	mv	s1,a0
    if(mem == 0){
    800012c0:	c515                	beqz	a0,800012ec <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    800012c2:	6605                	lui	a2,0x1
    800012c4:	4581                	li	a1,0
    800012c6:	9ddff0ef          	jal	80000ca2 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012ca:	875a                	mv	a4,s6
    800012cc:	86a6                	mv	a3,s1
    800012ce:	6605                	lui	a2,0x1
    800012d0:	85ca                	mv	a1,s2
    800012d2:	8556                	mv	a0,s5
    800012d4:	d1bff0ef          	jal	80000fee <mappages>
    800012d8:	e915                	bnez	a0,8000130c <uvmalloc+0x84>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012da:	6785                	lui	a5,0x1
    800012dc:	993e                	add	s2,s2,a5
    800012de:	fd496ee3          	bltu	s2,s4,800012ba <uvmalloc+0x32>
  return newsz;
    800012e2:	8552                	mv	a0,s4
    800012e4:	74a2                	ld	s1,40(sp)
    800012e6:	7902                	ld	s2,32(sp)
    800012e8:	6b02                	ld	s6,0(sp)
    800012ea:	a811                	j	800012fe <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012ec:	864e                	mv	a2,s3
    800012ee:	85ca                	mv	a1,s2
    800012f0:	8556                	mv	a0,s5
    800012f2:	f53ff0ef          	jal	80001244 <uvmdealloc>
      return 0;
    800012f6:	4501                	li	a0,0
    800012f8:	74a2                	ld	s1,40(sp)
    800012fa:	7902                	ld	s2,32(sp)
    800012fc:	6b02                	ld	s6,0(sp)
}
    800012fe:	70e2                	ld	ra,56(sp)
    80001300:	7442                	ld	s0,48(sp)
    80001302:	69e2                	ld	s3,24(sp)
    80001304:	6a42                	ld	s4,16(sp)
    80001306:	6aa2                	ld	s5,8(sp)
    80001308:	6121                	addi	sp,sp,64
    8000130a:	8082                	ret
      kfree(mem);
    8000130c:	8526                	mv	a0,s1
    8000130e:	f0eff0ef          	jal	80000a1c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001312:	864e                	mv	a2,s3
    80001314:	85ca                	mv	a1,s2
    80001316:	8556                	mv	a0,s5
    80001318:	f2dff0ef          	jal	80001244 <uvmdealloc>
      return 0;
    8000131c:	4501                	li	a0,0
    8000131e:	74a2                	ld	s1,40(sp)
    80001320:	7902                	ld	s2,32(sp)
    80001322:	6b02                	ld	s6,0(sp)
    80001324:	bfe9                	j	800012fe <uvmalloc+0x76>
    return oldsz;
    80001326:	852e                	mv	a0,a1
}
    80001328:	8082                	ret
  return newsz;
    8000132a:	8532                	mv	a0,a2
    8000132c:	bfc9                	j	800012fe <uvmalloc+0x76>

000000008000132e <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000132e:	7179                	addi	sp,sp,-48
    80001330:	f406                	sd	ra,40(sp)
    80001332:	f022                	sd	s0,32(sp)
    80001334:	ec26                	sd	s1,24(sp)
    80001336:	e84a                	sd	s2,16(sp)
    80001338:	e44e                	sd	s3,8(sp)
    8000133a:	e052                	sd	s4,0(sp)
    8000133c:	1800                	addi	s0,sp,48
    8000133e:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80001340:	84aa                	mv	s1,a0
    80001342:	6905                	lui	s2,0x1
    80001344:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001346:	4985                	li	s3,1
    80001348:	a819                	j	8000135e <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000134a:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000134c:	00c79513          	slli	a0,a5,0xc
    80001350:	fdfff0ef          	jal	8000132e <freewalk>
      pagetable[i] = 0;
    80001354:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001358:	04a1                	addi	s1,s1,8
    8000135a:	01248f63          	beq	s1,s2,80001378 <freewalk+0x4a>
    pte_t pte = pagetable[i];
    8000135e:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001360:	00f7f713          	andi	a4,a5,15
    80001364:	ff3703e3          	beq	a4,s3,8000134a <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001368:	8b85                	andi	a5,a5,1
    8000136a:	d7fd                	beqz	a5,80001358 <freewalk+0x2a>
      panic("freewalk: leaf");
    8000136c:	00006517          	auipc	a0,0x6
    80001370:	dcc50513          	addi	a0,a0,-564 # 80007138 <etext+0x138>
    80001374:	c6cff0ef          	jal	800007e0 <panic>
    }
  }
  kfree((void*)pagetable);
    80001378:	8552                	mv	a0,s4
    8000137a:	ea2ff0ef          	jal	80000a1c <kfree>
}
    8000137e:	70a2                	ld	ra,40(sp)
    80001380:	7402                	ld	s0,32(sp)
    80001382:	64e2                	ld	s1,24(sp)
    80001384:	6942                	ld	s2,16(sp)
    80001386:	69a2                	ld	s3,8(sp)
    80001388:	6a02                	ld	s4,0(sp)
    8000138a:	6145                	addi	sp,sp,48
    8000138c:	8082                	ret

000000008000138e <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000138e:	1101                	addi	sp,sp,-32
    80001390:	ec06                	sd	ra,24(sp)
    80001392:	e822                	sd	s0,16(sp)
    80001394:	e426                	sd	s1,8(sp)
    80001396:	1000                	addi	s0,sp,32
    80001398:	84aa                	mv	s1,a0
  if(sz > 0)
    8000139a:	e989                	bnez	a1,800013ac <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    8000139c:	8526                	mv	a0,s1
    8000139e:	f91ff0ef          	jal	8000132e <freewalk>
}
    800013a2:	60e2                	ld	ra,24(sp)
    800013a4:	6442                	ld	s0,16(sp)
    800013a6:	64a2                	ld	s1,8(sp)
    800013a8:	6105                	addi	sp,sp,32
    800013aa:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800013ac:	6785                	lui	a5,0x1
    800013ae:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013b0:	95be                	add	a1,a1,a5
    800013b2:	4685                	li	a3,1
    800013b4:	00c5d613          	srli	a2,a1,0xc
    800013b8:	4581                	li	a1,0
    800013ba:	e01ff0ef          	jal	800011ba <uvmunmap>
    800013be:	bff9                	j	8000139c <uvmfree+0xe>

00000000800013c0 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800013c0:	ce49                	beqz	a2,8000145a <uvmcopy+0x9a>
{
    800013c2:	715d                	addi	sp,sp,-80
    800013c4:	e486                	sd	ra,72(sp)
    800013c6:	e0a2                	sd	s0,64(sp)
    800013c8:	fc26                	sd	s1,56(sp)
    800013ca:	f84a                	sd	s2,48(sp)
    800013cc:	f44e                	sd	s3,40(sp)
    800013ce:	f052                	sd	s4,32(sp)
    800013d0:	ec56                	sd	s5,24(sp)
    800013d2:	e85a                	sd	s6,16(sp)
    800013d4:	e45e                	sd	s7,8(sp)
    800013d6:	0880                	addi	s0,sp,80
    800013d8:	8aaa                	mv	s5,a0
    800013da:	8b2e                	mv	s6,a1
    800013dc:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800013de:	4481                	li	s1,0
    800013e0:	a029                	j	800013ea <uvmcopy+0x2a>
    800013e2:	6785                	lui	a5,0x1
    800013e4:	94be                	add	s1,s1,a5
    800013e6:	0544fe63          	bgeu	s1,s4,80001442 <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    800013ea:	4601                	li	a2,0
    800013ec:	85a6                	mv	a1,s1
    800013ee:	8556                	mv	a0,s5
    800013f0:	b27ff0ef          	jal	80000f16 <walk>
    800013f4:	d57d                	beqz	a0,800013e2 <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    800013f6:	6118                	ld	a4,0(a0)
    800013f8:	00177793          	andi	a5,a4,1
    800013fc:	d3fd                	beqz	a5,800013e2 <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013fe:	00a75593          	srli	a1,a4,0xa
    80001402:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001406:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    8000140a:	ef4ff0ef          	jal	80000afe <kalloc>
    8000140e:	89aa                	mv	s3,a0
    80001410:	c105                	beqz	a0,80001430 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001412:	6605                	lui	a2,0x1
    80001414:	85de                	mv	a1,s7
    80001416:	8e9ff0ef          	jal	80000cfe <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000141a:	874a                	mv	a4,s2
    8000141c:	86ce                	mv	a3,s3
    8000141e:	6605                	lui	a2,0x1
    80001420:	85a6                	mv	a1,s1
    80001422:	855a                	mv	a0,s6
    80001424:	bcbff0ef          	jal	80000fee <mappages>
    80001428:	dd4d                	beqz	a0,800013e2 <uvmcopy+0x22>
      kfree(mem);
    8000142a:	854e                	mv	a0,s3
    8000142c:	df0ff0ef          	jal	80000a1c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001430:	4685                	li	a3,1
    80001432:	00c4d613          	srli	a2,s1,0xc
    80001436:	4581                	li	a1,0
    80001438:	855a                	mv	a0,s6
    8000143a:	d81ff0ef          	jal	800011ba <uvmunmap>
  return -1;
    8000143e:	557d                	li	a0,-1
    80001440:	a011                	j	80001444 <uvmcopy+0x84>
  return 0;
    80001442:	4501                	li	a0,0
}
    80001444:	60a6                	ld	ra,72(sp)
    80001446:	6406                	ld	s0,64(sp)
    80001448:	74e2                	ld	s1,56(sp)
    8000144a:	7942                	ld	s2,48(sp)
    8000144c:	79a2                	ld	s3,40(sp)
    8000144e:	7a02                	ld	s4,32(sp)
    80001450:	6ae2                	ld	s5,24(sp)
    80001452:	6b42                	ld	s6,16(sp)
    80001454:	6ba2                	ld	s7,8(sp)
    80001456:	6161                	addi	sp,sp,80
    80001458:	8082                	ret
  return 0;
    8000145a:	4501                	li	a0,0
}
    8000145c:	8082                	ret

000000008000145e <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000145e:	1141                	addi	sp,sp,-16
    80001460:	e406                	sd	ra,8(sp)
    80001462:	e022                	sd	s0,0(sp)
    80001464:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001466:	4601                	li	a2,0
    80001468:	aafff0ef          	jal	80000f16 <walk>
  if(pte == 0)
    8000146c:	c901                	beqz	a0,8000147c <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000146e:	611c                	ld	a5,0(a0)
    80001470:	9bbd                	andi	a5,a5,-17
    80001472:	e11c                	sd	a5,0(a0)
}
    80001474:	60a2                	ld	ra,8(sp)
    80001476:	6402                	ld	s0,0(sp)
    80001478:	0141                	addi	sp,sp,16
    8000147a:	8082                	ret
    panic("uvmclear");
    8000147c:	00006517          	auipc	a0,0x6
    80001480:	ccc50513          	addi	a0,a0,-820 # 80007148 <etext+0x148>
    80001484:	b5cff0ef          	jal	800007e0 <panic>

0000000080001488 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001488:	c6dd                	beqz	a3,80001536 <copyinstr+0xae>
{
    8000148a:	715d                	addi	sp,sp,-80
    8000148c:	e486                	sd	ra,72(sp)
    8000148e:	e0a2                	sd	s0,64(sp)
    80001490:	fc26                	sd	s1,56(sp)
    80001492:	f84a                	sd	s2,48(sp)
    80001494:	f44e                	sd	s3,40(sp)
    80001496:	f052                	sd	s4,32(sp)
    80001498:	ec56                	sd	s5,24(sp)
    8000149a:	e85a                	sd	s6,16(sp)
    8000149c:	e45e                	sd	s7,8(sp)
    8000149e:	0880                	addi	s0,sp,80
    800014a0:	8a2a                	mv	s4,a0
    800014a2:	8b2e                	mv	s6,a1
    800014a4:	8bb2                	mv	s7,a2
    800014a6:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    800014a8:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800014aa:	6985                	lui	s3,0x1
    800014ac:	a825                	j	800014e4 <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800014ae:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800014b2:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800014b4:	37fd                	addiw	a5,a5,-1
    800014b6:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800014ba:	60a6                	ld	ra,72(sp)
    800014bc:	6406                	ld	s0,64(sp)
    800014be:	74e2                	ld	s1,56(sp)
    800014c0:	7942                	ld	s2,48(sp)
    800014c2:	79a2                	ld	s3,40(sp)
    800014c4:	7a02                	ld	s4,32(sp)
    800014c6:	6ae2                	ld	s5,24(sp)
    800014c8:	6b42                	ld	s6,16(sp)
    800014ca:	6ba2                	ld	s7,8(sp)
    800014cc:	6161                	addi	sp,sp,80
    800014ce:	8082                	ret
    800014d0:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800014d4:	9742                	add	a4,a4,a6
      --max;
    800014d6:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800014da:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    800014de:	04e58463          	beq	a1,a4,80001526 <copyinstr+0x9e>
{
    800014e2:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    800014e4:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800014e8:	85a6                	mv	a1,s1
    800014ea:	8552                	mv	a0,s4
    800014ec:	ac5ff0ef          	jal	80000fb0 <walkaddr>
    if(pa0 == 0)
    800014f0:	cd0d                	beqz	a0,8000152a <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    800014f2:	417486b3          	sub	a3,s1,s7
    800014f6:	96ce                	add	a3,a3,s3
    if(n > max)
    800014f8:	00d97363          	bgeu	s2,a3,800014fe <copyinstr+0x76>
    800014fc:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    800014fe:	955e                	add	a0,a0,s7
    80001500:	8d05                	sub	a0,a0,s1
    while(n > 0){
    80001502:	c695                	beqz	a3,8000152e <copyinstr+0xa6>
    80001504:	87da                	mv	a5,s6
    80001506:	885a                	mv	a6,s6
      if(*p == '\0'){
    80001508:	41650633          	sub	a2,a0,s6
    while(n > 0){
    8000150c:	96da                	add	a3,a3,s6
    8000150e:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001510:	00f60733          	add	a4,a2,a5
    80001514:	00074703          	lbu	a4,0(a4)
    80001518:	db59                	beqz	a4,800014ae <copyinstr+0x26>
        *dst = *p;
    8000151a:	00e78023          	sb	a4,0(a5)
      dst++;
    8000151e:	0785                	addi	a5,a5,1
    while(n > 0){
    80001520:	fed797e3          	bne	a5,a3,8000150e <copyinstr+0x86>
    80001524:	b775                	j	800014d0 <copyinstr+0x48>
    80001526:	4781                	li	a5,0
    80001528:	b771                	j	800014b4 <copyinstr+0x2c>
      return -1;
    8000152a:	557d                	li	a0,-1
    8000152c:	b779                	j	800014ba <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    8000152e:	6b85                	lui	s7,0x1
    80001530:	9ba6                	add	s7,s7,s1
    80001532:	87da                	mv	a5,s6
    80001534:	b77d                	j	800014e2 <copyinstr+0x5a>
  int got_null = 0;
    80001536:	4781                	li	a5,0
  if(got_null){
    80001538:	37fd                	addiw	a5,a5,-1
    8000153a:	0007851b          	sext.w	a0,a5
}
    8000153e:	8082                	ret

0000000080001540 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001540:	1141                	addi	sp,sp,-16
    80001542:	e406                	sd	ra,8(sp)
    80001544:	e022                	sd	s0,0(sp)
    80001546:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001548:	4601                	li	a2,0
    8000154a:	9cdff0ef          	jal	80000f16 <walk>
  if (pte == 0) {
    8000154e:	c519                	beqz	a0,8000155c <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001550:	6108                	ld	a0,0(a0)
    80001552:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001554:	60a2                	ld	ra,8(sp)
    80001556:	6402                	ld	s0,0(sp)
    80001558:	0141                	addi	sp,sp,16
    8000155a:	8082                	ret
    return 0;
    8000155c:	4501                	li	a0,0
    8000155e:	bfdd                	j	80001554 <ismapped+0x14>

0000000080001560 <vmfault>:
{
    80001560:	7179                	addi	sp,sp,-48
    80001562:	f406                	sd	ra,40(sp)
    80001564:	f022                	sd	s0,32(sp)
    80001566:	ec26                	sd	s1,24(sp)
    80001568:	e44e                	sd	s3,8(sp)
    8000156a:	1800                	addi	s0,sp,48
    8000156c:	89aa                	mv	s3,a0
    8000156e:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    80001570:	3c2000ef          	jal	80001932 <myproc>
  if (va >= p->sz)
    80001574:	653c                	ld	a5,72(a0)
    80001576:	00f4ea63          	bltu	s1,a5,8000158a <vmfault+0x2a>
    return 0;
    8000157a:	4981                	li	s3,0
}
    8000157c:	854e                	mv	a0,s3
    8000157e:	70a2                	ld	ra,40(sp)
    80001580:	7402                	ld	s0,32(sp)
    80001582:	64e2                	ld	s1,24(sp)
    80001584:	69a2                	ld	s3,8(sp)
    80001586:	6145                	addi	sp,sp,48
    80001588:	8082                	ret
    8000158a:	e84a                	sd	s2,16(sp)
    8000158c:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000158e:	77fd                	lui	a5,0xfffff
    80001590:	8cfd                	and	s1,s1,a5
  if(ismapped(pagetable, va)) {
    80001592:	85a6                	mv	a1,s1
    80001594:	854e                	mv	a0,s3
    80001596:	fabff0ef          	jal	80001540 <ismapped>
    return 0;
    8000159a:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    8000159c:	c119                	beqz	a0,800015a2 <vmfault+0x42>
    8000159e:	6942                	ld	s2,16(sp)
    800015a0:	bff1                	j	8000157c <vmfault+0x1c>
    800015a2:	e052                	sd	s4,0(sp)
  mem = (uint64) kalloc();
    800015a4:	d5aff0ef          	jal	80000afe <kalloc>
    800015a8:	8a2a                	mv	s4,a0
  if(mem == 0)
    800015aa:	c90d                	beqz	a0,800015dc <vmfault+0x7c>
  mem = (uint64) kalloc();
    800015ac:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    800015ae:	6605                	lui	a2,0x1
    800015b0:	4581                	li	a1,0
    800015b2:	ef0ff0ef          	jal	80000ca2 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    800015b6:	4759                	li	a4,22
    800015b8:	86d2                	mv	a3,s4
    800015ba:	6605                	lui	a2,0x1
    800015bc:	85a6                	mv	a1,s1
    800015be:	05093503          	ld	a0,80(s2)
    800015c2:	a2dff0ef          	jal	80000fee <mappages>
    800015c6:	e501                	bnez	a0,800015ce <vmfault+0x6e>
    800015c8:	6942                	ld	s2,16(sp)
    800015ca:	6a02                	ld	s4,0(sp)
    800015cc:	bf45                	j	8000157c <vmfault+0x1c>
    kfree((void *)mem);
    800015ce:	8552                	mv	a0,s4
    800015d0:	c4cff0ef          	jal	80000a1c <kfree>
    return 0;
    800015d4:	4981                	li	s3,0
    800015d6:	6942                	ld	s2,16(sp)
    800015d8:	6a02                	ld	s4,0(sp)
    800015da:	b74d                	j	8000157c <vmfault+0x1c>
    800015dc:	6942                	ld	s2,16(sp)
    800015de:	6a02                	ld	s4,0(sp)
    800015e0:	bf71                	j	8000157c <vmfault+0x1c>

00000000800015e2 <copyout>:
  while(len > 0){
    800015e2:	c2cd                	beqz	a3,80001684 <copyout+0xa2>
{
    800015e4:	711d                	addi	sp,sp,-96
    800015e6:	ec86                	sd	ra,88(sp)
    800015e8:	e8a2                	sd	s0,80(sp)
    800015ea:	e4a6                	sd	s1,72(sp)
    800015ec:	f852                	sd	s4,48(sp)
    800015ee:	f05a                	sd	s6,32(sp)
    800015f0:	ec5e                	sd	s7,24(sp)
    800015f2:	e862                	sd	s8,16(sp)
    800015f4:	1080                	addi	s0,sp,96
    800015f6:	8c2a                	mv	s8,a0
    800015f8:	8b2e                	mv	s6,a1
    800015fa:	8bb2                	mv	s7,a2
    800015fc:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015fe:	74fd                	lui	s1,0xfffff
    80001600:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80001602:	57fd                	li	a5,-1
    80001604:	83e9                	srli	a5,a5,0x1a
    80001606:	0897e163          	bltu	a5,s1,80001688 <copyout+0xa6>
    8000160a:	e0ca                	sd	s2,64(sp)
    8000160c:	fc4e                	sd	s3,56(sp)
    8000160e:	f456                	sd	s5,40(sp)
    80001610:	e466                	sd	s9,8(sp)
    80001612:	e06a                	sd	s10,0(sp)
    80001614:	6d05                	lui	s10,0x1
    80001616:	8cbe                	mv	s9,a5
    80001618:	a015                	j	8000163c <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000161a:	409b0533          	sub	a0,s6,s1
    8000161e:	0009861b          	sext.w	a2,s3
    80001622:	85de                	mv	a1,s7
    80001624:	954a                	add	a0,a0,s2
    80001626:	ed8ff0ef          	jal	80000cfe <memmove>
    len -= n;
    8000162a:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000162e:	9bce                	add	s7,s7,s3
  while(len > 0){
    80001630:	040a0363          	beqz	s4,80001676 <copyout+0x94>
    if(va0 >= MAXVA)
    80001634:	055cec63          	bltu	s9,s5,8000168c <copyout+0xaa>
    80001638:	84d6                	mv	s1,s5
    8000163a:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    8000163c:	85a6                	mv	a1,s1
    8000163e:	8562                	mv	a0,s8
    80001640:	971ff0ef          	jal	80000fb0 <walkaddr>
    80001644:	892a                	mv	s2,a0
    if(pa0 == 0) {
    80001646:	e901                	bnez	a0,80001656 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001648:	4601                	li	a2,0
    8000164a:	85a6                	mv	a1,s1
    8000164c:	8562                	mv	a0,s8
    8000164e:	f13ff0ef          	jal	80001560 <vmfault>
    80001652:	892a                	mv	s2,a0
    80001654:	c139                	beqz	a0,8000169a <copyout+0xb8>
    pte = walk(pagetable, va0, 0);
    80001656:	4601                	li	a2,0
    80001658:	85a6                	mv	a1,s1
    8000165a:	8562                	mv	a0,s8
    8000165c:	8bbff0ef          	jal	80000f16 <walk>
    if((*pte & PTE_W) == 0)
    80001660:	611c                	ld	a5,0(a0)
    80001662:	8b91                	andi	a5,a5,4
    80001664:	c3b1                	beqz	a5,800016a8 <copyout+0xc6>
    n = PGSIZE - (dstva - va0);
    80001666:	01a48ab3          	add	s5,s1,s10
    8000166a:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    8000166e:	fb3a76e3          	bgeu	s4,s3,8000161a <copyout+0x38>
    80001672:	89d2                	mv	s3,s4
    80001674:	b75d                	j	8000161a <copyout+0x38>
  return 0;
    80001676:	4501                	li	a0,0
    80001678:	6906                	ld	s2,64(sp)
    8000167a:	79e2                	ld	s3,56(sp)
    8000167c:	7aa2                	ld	s5,40(sp)
    8000167e:	6ca2                	ld	s9,8(sp)
    80001680:	6d02                	ld	s10,0(sp)
    80001682:	a80d                	j	800016b4 <copyout+0xd2>
    80001684:	4501                	li	a0,0
}
    80001686:	8082                	ret
      return -1;
    80001688:	557d                	li	a0,-1
    8000168a:	a02d                	j	800016b4 <copyout+0xd2>
    8000168c:	557d                	li	a0,-1
    8000168e:	6906                	ld	s2,64(sp)
    80001690:	79e2                	ld	s3,56(sp)
    80001692:	7aa2                	ld	s5,40(sp)
    80001694:	6ca2                	ld	s9,8(sp)
    80001696:	6d02                	ld	s10,0(sp)
    80001698:	a831                	j	800016b4 <copyout+0xd2>
        return -1;
    8000169a:	557d                	li	a0,-1
    8000169c:	6906                	ld	s2,64(sp)
    8000169e:	79e2                	ld	s3,56(sp)
    800016a0:	7aa2                	ld	s5,40(sp)
    800016a2:	6ca2                	ld	s9,8(sp)
    800016a4:	6d02                	ld	s10,0(sp)
    800016a6:	a039                	j	800016b4 <copyout+0xd2>
      return -1;
    800016a8:	557d                	li	a0,-1
    800016aa:	6906                	ld	s2,64(sp)
    800016ac:	79e2                	ld	s3,56(sp)
    800016ae:	7aa2                	ld	s5,40(sp)
    800016b0:	6ca2                	ld	s9,8(sp)
    800016b2:	6d02                	ld	s10,0(sp)
}
    800016b4:	60e6                	ld	ra,88(sp)
    800016b6:	6446                	ld	s0,80(sp)
    800016b8:	64a6                	ld	s1,72(sp)
    800016ba:	7a42                	ld	s4,48(sp)
    800016bc:	7b02                	ld	s6,32(sp)
    800016be:	6be2                	ld	s7,24(sp)
    800016c0:	6c42                	ld	s8,16(sp)
    800016c2:	6125                	addi	sp,sp,96
    800016c4:	8082                	ret

00000000800016c6 <copyin>:
  while(len > 0){
    800016c6:	c6c9                	beqz	a3,80001750 <copyin+0x8a>
{
    800016c8:	715d                	addi	sp,sp,-80
    800016ca:	e486                	sd	ra,72(sp)
    800016cc:	e0a2                	sd	s0,64(sp)
    800016ce:	fc26                	sd	s1,56(sp)
    800016d0:	f84a                	sd	s2,48(sp)
    800016d2:	f44e                	sd	s3,40(sp)
    800016d4:	f052                	sd	s4,32(sp)
    800016d6:	ec56                	sd	s5,24(sp)
    800016d8:	e85a                	sd	s6,16(sp)
    800016da:	e45e                	sd	s7,8(sp)
    800016dc:	e062                	sd	s8,0(sp)
    800016de:	0880                	addi	s0,sp,80
    800016e0:	8baa                	mv	s7,a0
    800016e2:	8aae                	mv	s5,a1
    800016e4:	8932                	mv	s2,a2
    800016e6:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    800016e8:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800016ea:	6b05                	lui	s6,0x1
    800016ec:	a035                	j	80001718 <copyin+0x52>
    800016ee:	412984b3          	sub	s1,s3,s2
    800016f2:	94da                	add	s1,s1,s6
    if(n > len)
    800016f4:	009a7363          	bgeu	s4,s1,800016fa <copyin+0x34>
    800016f8:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016fa:	413905b3          	sub	a1,s2,s3
    800016fe:	0004861b          	sext.w	a2,s1
    80001702:	95aa                	add	a1,a1,a0
    80001704:	8556                	mv	a0,s5
    80001706:	df8ff0ef          	jal	80000cfe <memmove>
    len -= n;
    8000170a:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000170e:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001710:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001714:	020a0163          	beqz	s4,80001736 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001718:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000171c:	85ce                	mv	a1,s3
    8000171e:	855e                	mv	a0,s7
    80001720:	891ff0ef          	jal	80000fb0 <walkaddr>
    if(pa0 == 0) {
    80001724:	f569                	bnez	a0,800016ee <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001726:	4601                	li	a2,0
    80001728:	85ce                	mv	a1,s3
    8000172a:	855e                	mv	a0,s7
    8000172c:	e35ff0ef          	jal	80001560 <vmfault>
    80001730:	fd5d                	bnez	a0,800016ee <copyin+0x28>
        return -1;
    80001732:	557d                	li	a0,-1
    80001734:	a011                	j	80001738 <copyin+0x72>
  return 0;
    80001736:	4501                	li	a0,0
}
    80001738:	60a6                	ld	ra,72(sp)
    8000173a:	6406                	ld	s0,64(sp)
    8000173c:	74e2                	ld	s1,56(sp)
    8000173e:	7942                	ld	s2,48(sp)
    80001740:	79a2                	ld	s3,40(sp)
    80001742:	7a02                	ld	s4,32(sp)
    80001744:	6ae2                	ld	s5,24(sp)
    80001746:	6b42                	ld	s6,16(sp)
    80001748:	6ba2                	ld	s7,8(sp)
    8000174a:	6c02                	ld	s8,0(sp)
    8000174c:	6161                	addi	sp,sp,80
    8000174e:	8082                	ret
  return 0;
    80001750:	4501                	li	a0,0
}
    80001752:	8082                	ret

0000000080001754 <compute_weight>:
extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

uint64 compute_weight(int nice) {
    80001754:	1141                	addi	sp,sp,-16
    80001756:	e422                	sd	s0,8(sp)
    80001758:	0800                	addi	s0,sp,16
    return nice_to_weight[nice + 20];
    8000175a:	2551                	addiw	a0,a0,20
    8000175c:	050e                	slli	a0,a0,0x3
    8000175e:	00006797          	auipc	a5,0x6
    80001762:	0c278793          	addi	a5,a5,194 # 80007820 <nice_to_weight>
    80001766:	97aa                	add	a5,a5,a0
}
    80001768:	6388                	ld	a0,0(a5)
    8000176a:	6422                	ld	s0,8(sp)
    8000176c:	0141                	addi	sp,sp,16
    8000176e:	8082                	ret

0000000080001770 <srand>:

static unsigned long rand_seed = 1;

void srand(unsigned int seed) {
    80001770:	1141                	addi	sp,sp,-16
    80001772:	e422                	sd	s0,8(sp)
    80001774:	0800                	addi	s0,sp,16
    rand_seed = seed;
    80001776:	1502                	slli	a0,a0,0x20
    80001778:	9101                	srli	a0,a0,0x20
    8000177a:	00006797          	auipc	a5,0x6
    8000177e:	2ea7bf23          	sd	a0,766(a5) # 80007a78 <rand_seed>
}
    80001782:	6422                	ld	s0,8(sp)
    80001784:	0141                	addi	sp,sp,16
    80001786:	8082                	ret

0000000080001788 <rand>:

int rand(void) {
    80001788:	1141                	addi	sp,sp,-16
    8000178a:	e422                	sd	s0,8(sp)
    8000178c:	0800                	addi	s0,sp,16
    rand_seed = rand_seed * 1103515245 + 12345;
    8000178e:	00006717          	auipc	a4,0x6
    80001792:	2ea70713          	addi	a4,a4,746 # 80007a78 <rand_seed>
    80001796:	6308                	ld	a0,0(a4)
    80001798:	41c657b7          	lui	a5,0x41c65
    8000179c:	e6d78793          	addi	a5,a5,-403 # 41c64e6d <_entry-0x3e39b193>
    800017a0:	02f50533          	mul	a0,a0,a5
    800017a4:	678d                	lui	a5,0x3
    800017a6:	03978793          	addi	a5,a5,57 # 3039 <_entry-0x7fffcfc7>
    800017aa:	953e                	add	a0,a0,a5
    800017ac:	e308                	sd	a0,0(a4)
    return (rand_seed / 65536) % 32768;  // returns 0..32767
    800017ae:	1506                	slli	a0,a0,0x21
}
    800017b0:	9145                	srli	a0,a0,0x31
    800017b2:	6422                	ld	s0,8(sp)
    800017b4:	0141                	addi	sp,sp,16
    800017b6:	8082                	ret

00000000800017b8 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017b8:	7139                	addi	sp,sp,-64
    800017ba:	fc06                	sd	ra,56(sp)
    800017bc:	f822                	sd	s0,48(sp)
    800017be:	f426                	sd	s1,40(sp)
    800017c0:	f04a                	sd	s2,32(sp)
    800017c2:	ec4e                	sd	s3,24(sp)
    800017c4:	e852                	sd	s4,16(sp)
    800017c6:	e456                	sd	s5,8(sp)
    800017c8:	e05a                	sd	s6,0(sp)
    800017ca:	0080                	addi	s0,sp,64
    800017cc:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ce:	0000f497          	auipc	s1,0xf
    800017d2:	82a48493          	addi	s1,s1,-2006 # 8000fff8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017d6:	8b26                	mv	s6,s1
    800017d8:	00a36937          	lui	s2,0xa36
    800017dc:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    800017e0:	0932                	slli	s2,s2,0xc
    800017e2:	46d90913          	addi	s2,s2,1133
    800017e6:	0936                	slli	s2,s2,0xd
    800017e8:	df590913          	addi	s2,s2,-523
    800017ec:	093a                	slli	s2,s2,0xe
    800017ee:	6cf90913          	addi	s2,s2,1743
    800017f2:	040009b7          	lui	s3,0x4000
    800017f6:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017f8:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800017fa:	00014a97          	auipc	s5,0x14
    800017fe:	5fea8a93          	addi	s5,s5,1534 # 80015df8 <tickslock>
    char *pa = kalloc();
    80001802:	afcff0ef          	jal	80000afe <kalloc>
    80001806:	862a                	mv	a2,a0
    if(pa == 0)
    80001808:	cd15                	beqz	a0,80001844 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int) (p - proc));
    8000180a:	416485b3          	sub	a1,s1,s6
    8000180e:	858d                	srai	a1,a1,0x3
    80001810:	032585b3          	mul	a1,a1,s2
    80001814:	2585                	addiw	a1,a1,1
    80001816:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000181a:	4719                	li	a4,6
    8000181c:	6685                	lui	a3,0x1
    8000181e:	40b985b3          	sub	a1,s3,a1
    80001822:	8552                	mv	a0,s4
    80001824:	87bff0ef          	jal	8000109e <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001828:	17848493          	addi	s1,s1,376
    8000182c:	fd549be3          	bne	s1,s5,80001802 <proc_mapstacks+0x4a>
  }
}
    80001830:	70e2                	ld	ra,56(sp)
    80001832:	7442                	ld	s0,48(sp)
    80001834:	74a2                	ld	s1,40(sp)
    80001836:	7902                	ld	s2,32(sp)
    80001838:	69e2                	ld	s3,24(sp)
    8000183a:	6a42                	ld	s4,16(sp)
    8000183c:	6aa2                	ld	s5,8(sp)
    8000183e:	6b02                	ld	s6,0(sp)
    80001840:	6121                	addi	sp,sp,64
    80001842:	8082                	ret
      panic("kalloc");
    80001844:	00006517          	auipc	a0,0x6
    80001848:	91450513          	addi	a0,a0,-1772 # 80007158 <etext+0x158>
    8000184c:	f95fe0ef          	jal	800007e0 <panic>

0000000080001850 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001850:	7139                	addi	sp,sp,-64
    80001852:	fc06                	sd	ra,56(sp)
    80001854:	f822                	sd	s0,48(sp)
    80001856:	f426                	sd	s1,40(sp)
    80001858:	f04a                	sd	s2,32(sp)
    8000185a:	ec4e                	sd	s3,24(sp)
    8000185c:	e852                	sd	s4,16(sp)
    8000185e:	e456                	sd	s5,8(sp)
    80001860:	e05a                	sd	s6,0(sp)
    80001862:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001864:	00006597          	auipc	a1,0x6
    80001868:	8fc58593          	addi	a1,a1,-1796 # 80007160 <etext+0x160>
    8000186c:	0000e517          	auipc	a0,0xe
    80001870:	35c50513          	addi	a0,a0,860 # 8000fbc8 <pid_lock>
    80001874:	adaff0ef          	jal	80000b4e <initlock>
  initlock(&wait_lock, "wait_lock");
    80001878:	00006597          	auipc	a1,0x6
    8000187c:	8f058593          	addi	a1,a1,-1808 # 80007168 <etext+0x168>
    80001880:	0000e517          	auipc	a0,0xe
    80001884:	36050513          	addi	a0,a0,864 # 8000fbe0 <wait_lock>
    80001888:	ac6ff0ef          	jal	80000b4e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000188c:	0000e497          	auipc	s1,0xe
    80001890:	76c48493          	addi	s1,s1,1900 # 8000fff8 <proc>
      initlock(&p->lock, "proc");
    80001894:	00006b17          	auipc	s6,0x6
    80001898:	8e4b0b13          	addi	s6,s6,-1820 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000189c:	8aa6                	mv	s5,s1
    8000189e:	00a36937          	lui	s2,0xa36
    800018a2:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    800018a6:	0932                	slli	s2,s2,0xc
    800018a8:	46d90913          	addi	s2,s2,1133
    800018ac:	0936                	slli	s2,s2,0xd
    800018ae:	df590913          	addi	s2,s2,-523
    800018b2:	093a                	slli	s2,s2,0xe
    800018b4:	6cf90913          	addi	s2,s2,1743
    800018b8:	040009b7          	lui	s3,0x4000
    800018bc:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018be:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018c0:	00014a17          	auipc	s4,0x14
    800018c4:	538a0a13          	addi	s4,s4,1336 # 80015df8 <tickslock>
      initlock(&p->lock, "proc");
    800018c8:	85da                	mv	a1,s6
    800018ca:	8526                	mv	a0,s1
    800018cc:	a82ff0ef          	jal	80000b4e <initlock>
      p->state = UNUSED;
    800018d0:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018d4:	415487b3          	sub	a5,s1,s5
    800018d8:	878d                	srai	a5,a5,0x3
    800018da:	032787b3          	mul	a5,a5,s2
    800018de:	2785                	addiw	a5,a5,1
    800018e0:	00d7979b          	slliw	a5,a5,0xd
    800018e4:	40f987b3          	sub	a5,s3,a5
    800018e8:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018ea:	17848493          	addi	s1,s1,376
    800018ee:	fd449de3          	bne	s1,s4,800018c8 <procinit+0x78>
  }
}
    800018f2:	70e2                	ld	ra,56(sp)
    800018f4:	7442                	ld	s0,48(sp)
    800018f6:	74a2                	ld	s1,40(sp)
    800018f8:	7902                	ld	s2,32(sp)
    800018fa:	69e2                	ld	s3,24(sp)
    800018fc:	6a42                	ld	s4,16(sp)
    800018fe:	6aa2                	ld	s5,8(sp)
    80001900:	6b02                	ld	s6,0(sp)
    80001902:	6121                	addi	sp,sp,64
    80001904:	8082                	ret

0000000080001906 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001906:	1141                	addi	sp,sp,-16
    80001908:	e422                	sd	s0,8(sp)
    8000190a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    8000190c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    8000190e:	2501                	sext.w	a0,a0
    80001910:	6422                	ld	s0,8(sp)
    80001912:	0141                	addi	sp,sp,16
    80001914:	8082                	ret

0000000080001916 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001916:	1141                	addi	sp,sp,-16
    80001918:	e422                	sd	s0,8(sp)
    8000191a:	0800                	addi	s0,sp,16
    8000191c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000191e:	2781                	sext.w	a5,a5
    80001920:	079e                	slli	a5,a5,0x7
  return c;
}
    80001922:	0000e517          	auipc	a0,0xe
    80001926:	2d650513          	addi	a0,a0,726 # 8000fbf8 <cpus>
    8000192a:	953e                	add	a0,a0,a5
    8000192c:	6422                	ld	s0,8(sp)
    8000192e:	0141                	addi	sp,sp,16
    80001930:	8082                	ret

0000000080001932 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001932:	1101                	addi	sp,sp,-32
    80001934:	ec06                	sd	ra,24(sp)
    80001936:	e822                	sd	s0,16(sp)
    80001938:	e426                	sd	s1,8(sp)
    8000193a:	1000                	addi	s0,sp,32
  push_off();
    8000193c:	a52ff0ef          	jal	80000b8e <push_off>
    80001940:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001942:	2781                	sext.w	a5,a5
    80001944:	079e                	slli	a5,a5,0x7
    80001946:	0000e717          	auipc	a4,0xe
    8000194a:	28270713          	addi	a4,a4,642 # 8000fbc8 <pid_lock>
    8000194e:	97ba                	add	a5,a5,a4
    80001950:	7b84                	ld	s1,48(a5)
  pop_off();
    80001952:	ac0ff0ef          	jal	80000c12 <pop_off>
  return p;
}
    80001956:	8526                	mv	a0,s1
    80001958:	60e2                	ld	ra,24(sp)
    8000195a:	6442                	ld	s0,16(sp)
    8000195c:	64a2                	ld	s1,8(sp)
    8000195e:	6105                	addi	sp,sp,32
    80001960:	8082                	ret

0000000080001962 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001962:	7179                	addi	sp,sp,-48
    80001964:	f406                	sd	ra,40(sp)
    80001966:	f022                	sd	s0,32(sp)
    80001968:	ec26                	sd	s1,24(sp)
    8000196a:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    8000196c:	fc7ff0ef          	jal	80001932 <myproc>
    80001970:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001972:	af4ff0ef          	jal	80000c66 <release>

  if (first) {
    80001976:	00006797          	auipc	a5,0x6
    8000197a:	0fa7a783          	lw	a5,250(a5) # 80007a70 <first.1>
    8000197e:	cf8d                	beqz	a5,800019b8 <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001980:	4505                	li	a0,1
    80001982:	669010ef          	jal	800037ea <fsinit>

    first = 0;
    80001986:	00006797          	auipc	a5,0x6
    8000198a:	0e07a523          	sw	zero,234(a5) # 80007a70 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000198e:	0ff0000f          	fence

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001992:	00005517          	auipc	a0,0x5
    80001996:	7ee50513          	addi	a0,a0,2030 # 80007180 <etext+0x180>
    8000199a:	fca43823          	sd	a0,-48(s0)
    8000199e:	fc043c23          	sd	zero,-40(s0)
    800019a2:	fd040593          	addi	a1,s0,-48
    800019a6:	745020ef          	jal	800048ea <kexec>
    800019aa:	6cbc                	ld	a5,88(s1)
    800019ac:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800019ae:	6cbc                	ld	a5,88(s1)
    800019b0:	7bb8                	ld	a4,112(a5)
    800019b2:	57fd                	li	a5,-1
    800019b4:	02f70d63          	beq	a4,a5,800019ee <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800019b8:	4b7000ef          	jal	8000266e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019bc:	68a8                	ld	a0,80(s1)
    800019be:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019c0:	04000737          	lui	a4,0x4000
    800019c4:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019c6:	0732                	slli	a4,a4,0xc
    800019c8:	00004797          	auipc	a5,0x4
    800019cc:	6d478793          	addi	a5,a5,1748 # 8000609c <userret>
    800019d0:	00004697          	auipc	a3,0x4
    800019d4:	63068693          	addi	a3,a3,1584 # 80006000 <_trampoline>
    800019d8:	8f95                	sub	a5,a5,a3
    800019da:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019dc:	577d                	li	a4,-1
    800019de:	177e                	slli	a4,a4,0x3f
    800019e0:	8d59                	or	a0,a0,a4
    800019e2:	9782                	jalr	a5
}
    800019e4:	70a2                	ld	ra,40(sp)
    800019e6:	7402                	ld	s0,32(sp)
    800019e8:	64e2                	ld	s1,24(sp)
    800019ea:	6145                	addi	sp,sp,48
    800019ec:	8082                	ret
      panic("exec");
    800019ee:	00005517          	auipc	a0,0x5
    800019f2:	79a50513          	addi	a0,a0,1946 # 80007188 <etext+0x188>
    800019f6:	debfe0ef          	jal	800007e0 <panic>

00000000800019fa <allocpid>:
{
    800019fa:	1101                	addi	sp,sp,-32
    800019fc:	ec06                	sd	ra,24(sp)
    800019fe:	e822                	sd	s0,16(sp)
    80001a00:	e426                	sd	s1,8(sp)
    80001a02:	e04a                	sd	s2,0(sp)
    80001a04:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a06:	0000e917          	auipc	s2,0xe
    80001a0a:	1c290913          	addi	s2,s2,450 # 8000fbc8 <pid_lock>
    80001a0e:	854a                	mv	a0,s2
    80001a10:	9beff0ef          	jal	80000bce <acquire>
  pid = nextpid;
    80001a14:	00006797          	auipc	a5,0x6
    80001a18:	06c78793          	addi	a5,a5,108 # 80007a80 <nextpid>
    80001a1c:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a1e:	0014871b          	addiw	a4,s1,1
    80001a22:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a24:	854a                	mv	a0,s2
    80001a26:	a40ff0ef          	jal	80000c66 <release>
}
    80001a2a:	8526                	mv	a0,s1
    80001a2c:	60e2                	ld	ra,24(sp)
    80001a2e:	6442                	ld	s0,16(sp)
    80001a30:	64a2                	ld	s1,8(sp)
    80001a32:	6902                	ld	s2,0(sp)
    80001a34:	6105                	addi	sp,sp,32
    80001a36:	8082                	ret

0000000080001a38 <proc_pagetable>:
{
    80001a38:	1101                	addi	sp,sp,-32
    80001a3a:	ec06                	sd	ra,24(sp)
    80001a3c:	e822                	sd	s0,16(sp)
    80001a3e:	e426                	sd	s1,8(sp)
    80001a40:	e04a                	sd	s2,0(sp)
    80001a42:	1000                	addi	s0,sp,32
    80001a44:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a46:	f4eff0ef          	jal	80001194 <uvmcreate>
    80001a4a:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a4c:	cd05                	beqz	a0,80001a84 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a4e:	4729                	li	a4,10
    80001a50:	00004697          	auipc	a3,0x4
    80001a54:	5b068693          	addi	a3,a3,1456 # 80006000 <_trampoline>
    80001a58:	6605                	lui	a2,0x1
    80001a5a:	040005b7          	lui	a1,0x4000
    80001a5e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a60:	05b2                	slli	a1,a1,0xc
    80001a62:	d8cff0ef          	jal	80000fee <mappages>
    80001a66:	02054663          	bltz	a0,80001a92 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a6a:	4719                	li	a4,6
    80001a6c:	05893683          	ld	a3,88(s2)
    80001a70:	6605                	lui	a2,0x1
    80001a72:	020005b7          	lui	a1,0x2000
    80001a76:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a78:	05b6                	slli	a1,a1,0xd
    80001a7a:	8526                	mv	a0,s1
    80001a7c:	d72ff0ef          	jal	80000fee <mappages>
    80001a80:	00054f63          	bltz	a0,80001a9e <proc_pagetable+0x66>
}
    80001a84:	8526                	mv	a0,s1
    80001a86:	60e2                	ld	ra,24(sp)
    80001a88:	6442                	ld	s0,16(sp)
    80001a8a:	64a2                	ld	s1,8(sp)
    80001a8c:	6902                	ld	s2,0(sp)
    80001a8e:	6105                	addi	sp,sp,32
    80001a90:	8082                	ret
    uvmfree(pagetable, 0);
    80001a92:	4581                	li	a1,0
    80001a94:	8526                	mv	a0,s1
    80001a96:	8f9ff0ef          	jal	8000138e <uvmfree>
    return 0;
    80001a9a:	4481                	li	s1,0
    80001a9c:	b7e5                	j	80001a84 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a9e:	4681                	li	a3,0
    80001aa0:	4605                	li	a2,1
    80001aa2:	040005b7          	lui	a1,0x4000
    80001aa6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aa8:	05b2                	slli	a1,a1,0xc
    80001aaa:	8526                	mv	a0,s1
    80001aac:	f0eff0ef          	jal	800011ba <uvmunmap>
    uvmfree(pagetable, 0);
    80001ab0:	4581                	li	a1,0
    80001ab2:	8526                	mv	a0,s1
    80001ab4:	8dbff0ef          	jal	8000138e <uvmfree>
    return 0;
    80001ab8:	4481                	li	s1,0
    80001aba:	b7e9                	j	80001a84 <proc_pagetable+0x4c>

0000000080001abc <proc_freepagetable>:
{
    80001abc:	1101                	addi	sp,sp,-32
    80001abe:	ec06                	sd	ra,24(sp)
    80001ac0:	e822                	sd	s0,16(sp)
    80001ac2:	e426                	sd	s1,8(sp)
    80001ac4:	e04a                	sd	s2,0(sp)
    80001ac6:	1000                	addi	s0,sp,32
    80001ac8:	84aa                	mv	s1,a0
    80001aca:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001acc:	4681                	li	a3,0
    80001ace:	4605                	li	a2,1
    80001ad0:	040005b7          	lui	a1,0x4000
    80001ad4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ad6:	05b2                	slli	a1,a1,0xc
    80001ad8:	ee2ff0ef          	jal	800011ba <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001adc:	4681                	li	a3,0
    80001ade:	4605                	li	a2,1
    80001ae0:	020005b7          	lui	a1,0x2000
    80001ae4:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ae6:	05b6                	slli	a1,a1,0xd
    80001ae8:	8526                	mv	a0,s1
    80001aea:	ed0ff0ef          	jal	800011ba <uvmunmap>
  uvmfree(pagetable, sz);
    80001aee:	85ca                	mv	a1,s2
    80001af0:	8526                	mv	a0,s1
    80001af2:	89dff0ef          	jal	8000138e <uvmfree>
}
    80001af6:	60e2                	ld	ra,24(sp)
    80001af8:	6442                	ld	s0,16(sp)
    80001afa:	64a2                	ld	s1,8(sp)
    80001afc:	6902                	ld	s2,0(sp)
    80001afe:	6105                	addi	sp,sp,32
    80001b00:	8082                	ret

0000000080001b02 <freeproc>:
{
    80001b02:	1101                	addi	sp,sp,-32
    80001b04:	ec06                	sd	ra,24(sp)
    80001b06:	e822                	sd	s0,16(sp)
    80001b08:	e426                	sd	s1,8(sp)
    80001b0a:	1000                	addi	s0,sp,32
    80001b0c:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001b0e:	6d28                	ld	a0,88(a0)
    80001b10:	c119                	beqz	a0,80001b16 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001b12:	f0bfe0ef          	jal	80000a1c <kfree>
  p->trapframe = 0;
    80001b16:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001b1a:	68a8                	ld	a0,80(s1)
    80001b1c:	c501                	beqz	a0,80001b24 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b1e:	64ac                	ld	a1,72(s1)
    80001b20:	f9dff0ef          	jal	80001abc <proc_freepagetable>
  p->pagetable = 0;
    80001b24:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b28:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b2c:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001b30:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001b34:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b38:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b3c:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b40:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b44:	0004ac23          	sw	zero,24(s1)
}
    80001b48:	60e2                	ld	ra,24(sp)
    80001b4a:	6442                	ld	s0,16(sp)
    80001b4c:	64a2                	ld	s1,8(sp)
    80001b4e:	6105                	addi	sp,sp,32
    80001b50:	8082                	ret

0000000080001b52 <allocproc>:
{
    80001b52:	1101                	addi	sp,sp,-32
    80001b54:	ec06                	sd	ra,24(sp)
    80001b56:	e822                	sd	s0,16(sp)
    80001b58:	e426                	sd	s1,8(sp)
    80001b5a:	e04a                	sd	s2,0(sp)
    80001b5c:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b5e:	0000e497          	auipc	s1,0xe
    80001b62:	49a48493          	addi	s1,s1,1178 # 8000fff8 <proc>
    80001b66:	00014917          	auipc	s2,0x14
    80001b6a:	29290913          	addi	s2,s2,658 # 80015df8 <tickslock>
    acquire(&p->lock);
    80001b6e:	8526                	mv	a0,s1
    80001b70:	85eff0ef          	jal	80000bce <acquire>
    if(p->state == UNUSED) {
    80001b74:	4c9c                	lw	a5,24(s1)
    80001b76:	cb91                	beqz	a5,80001b8a <allocproc+0x38>
      release(&p->lock);
    80001b78:	8526                	mv	a0,s1
    80001b7a:	8ecff0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b7e:	17848493          	addi	s1,s1,376
    80001b82:	ff2496e3          	bne	s1,s2,80001b6e <allocproc+0x1c>
  return 0;
    80001b86:	4481                	li	s1,0
    80001b88:	a899                	j	80001bde <allocproc+0x8c>
  p->pid = allocpid();
    80001b8a:	e71ff0ef          	jal	800019fa <allocpid>
    80001b8e:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b90:	4785                	li	a5,1
    80001b92:	cc9c                	sw	a5,24(s1)
  p->creation_time = ticks;   // global ticks counter
    80001b94:	00006797          	auipc	a5,0x6
    80001b98:	f247a783          	lw	a5,-220(a5) # 80007ab8 <ticks>
    80001b9c:	16f4a423          	sw	a5,360(s1)
  p->start_time = 0;          // not scheduled yet
    80001ba0:	1604a623          	sw	zero,364(s1)
  p->end_time = 0;            // not finished yet
    80001ba4:	1604a823          	sw	zero,368(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001ba8:	f57fe0ef          	jal	80000afe <kalloc>
    80001bac:	892a                	mv	s2,a0
    80001bae:	eca8                	sd	a0,88(s1)
    80001bb0:	cd15                	beqz	a0,80001bec <allocproc+0x9a>
  p->pagetable = proc_pagetable(p);
    80001bb2:	8526                	mv	a0,s1
    80001bb4:	e85ff0ef          	jal	80001a38 <proc_pagetable>
    80001bb8:	892a                	mv	s2,a0
    80001bba:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001bbc:	c121                	beqz	a0,80001bfc <allocproc+0xaa>
  memset(&p->context, 0, sizeof(p->context));
    80001bbe:	07000613          	li	a2,112
    80001bc2:	4581                	li	a1,0
    80001bc4:	06048513          	addi	a0,s1,96
    80001bc8:	8daff0ef          	jal	80000ca2 <memset>
  p->context.ra = (uint64)forkret;
    80001bcc:	00000797          	auipc	a5,0x0
    80001bd0:	d9678793          	addi	a5,a5,-618 # 80001962 <forkret>
    80001bd4:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001bd6:	60bc                	ld	a5,64(s1)
    80001bd8:	6705                	lui	a4,0x1
    80001bda:	97ba                	add	a5,a5,a4
    80001bdc:	f4bc                	sd	a5,104(s1)
}
    80001bde:	8526                	mv	a0,s1
    80001be0:	60e2                	ld	ra,24(sp)
    80001be2:	6442                	ld	s0,16(sp)
    80001be4:	64a2                	ld	s1,8(sp)
    80001be6:	6902                	ld	s2,0(sp)
    80001be8:	6105                	addi	sp,sp,32
    80001bea:	8082                	ret
    freeproc(p);
    80001bec:	8526                	mv	a0,s1
    80001bee:	f15ff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001bf2:	8526                	mv	a0,s1
    80001bf4:	872ff0ef          	jal	80000c66 <release>
    return 0;
    80001bf8:	84ca                	mv	s1,s2
    80001bfa:	b7d5                	j	80001bde <allocproc+0x8c>
    freeproc(p);
    80001bfc:	8526                	mv	a0,s1
    80001bfe:	f05ff0ef          	jal	80001b02 <freeproc>
    release(&p->lock);
    80001c02:	8526                	mv	a0,s1
    80001c04:	862ff0ef          	jal	80000c66 <release>
    return 0;
    80001c08:	84ca                	mv	s1,s2
    80001c0a:	bfd1                	j	80001bde <allocproc+0x8c>

0000000080001c0c <userinit>:
{
    80001c0c:	1101                	addi	sp,sp,-32
    80001c0e:	ec06                	sd	ra,24(sp)
    80001c10:	e822                	sd	s0,16(sp)
    80001c12:	e426                	sd	s1,8(sp)
    80001c14:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c16:	f3dff0ef          	jal	80001b52 <allocproc>
    80001c1a:	84aa                	mv	s1,a0
  initproc = p;
    80001c1c:	00006797          	auipc	a5,0x6
    80001c20:	e8a7ba23          	sd	a0,-364(a5) # 80007ab0 <initproc>
  p->cwd = namei("/");
    80001c24:	00005517          	auipc	a0,0x5
    80001c28:	56c50513          	addi	a0,a0,1388 # 80007190 <etext+0x190>
    80001c2c:	0e0020ef          	jal	80003d0c <namei>
    80001c30:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c34:	478d                	li	a5,3
    80001c36:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c38:	8526                	mv	a0,s1
    80001c3a:	82cff0ef          	jal	80000c66 <release>
}
    80001c3e:	60e2                	ld	ra,24(sp)
    80001c40:	6442                	ld	s0,16(sp)
    80001c42:	64a2                	ld	s1,8(sp)
    80001c44:	6105                	addi	sp,sp,32
    80001c46:	8082                	ret

0000000080001c48 <growproc>:
{
    80001c48:	1101                	addi	sp,sp,-32
    80001c4a:	ec06                	sd	ra,24(sp)
    80001c4c:	e822                	sd	s0,16(sp)
    80001c4e:	e426                	sd	s1,8(sp)
    80001c50:	e04a                	sd	s2,0(sp)
    80001c52:	1000                	addi	s0,sp,32
    80001c54:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c56:	cddff0ef          	jal	80001932 <myproc>
    80001c5a:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c5c:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c5e:	01204c63          	bgtz	s2,80001c76 <growproc+0x2e>
  } else if(n < 0){
    80001c62:	02094463          	bltz	s2,80001c8a <growproc+0x42>
  p->sz = sz;
    80001c66:	e4ac                	sd	a1,72(s1)
  return 0;
    80001c68:	4501                	li	a0,0
}
    80001c6a:	60e2                	ld	ra,24(sp)
    80001c6c:	6442                	ld	s0,16(sp)
    80001c6e:	64a2                	ld	s1,8(sp)
    80001c70:	6902                	ld	s2,0(sp)
    80001c72:	6105                	addi	sp,sp,32
    80001c74:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c76:	4691                	li	a3,4
    80001c78:	00b90633          	add	a2,s2,a1
    80001c7c:	6928                	ld	a0,80(a0)
    80001c7e:	e0aff0ef          	jal	80001288 <uvmalloc>
    80001c82:	85aa                	mv	a1,a0
    80001c84:	f16d                	bnez	a0,80001c66 <growproc+0x1e>
      return -1;
    80001c86:	557d                	li	a0,-1
    80001c88:	b7cd                	j	80001c6a <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c8a:	00b90633          	add	a2,s2,a1
    80001c8e:	6928                	ld	a0,80(a0)
    80001c90:	db4ff0ef          	jal	80001244 <uvmdealloc>
    80001c94:	85aa                	mv	a1,a0
    80001c96:	bfc1                	j	80001c66 <growproc+0x1e>

0000000080001c98 <kfork>:
{
    80001c98:	7139                	addi	sp,sp,-64
    80001c9a:	fc06                	sd	ra,56(sp)
    80001c9c:	f822                	sd	s0,48(sp)
    80001c9e:	f04a                	sd	s2,32(sp)
    80001ca0:	e456                	sd	s5,8(sp)
    80001ca2:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001ca4:	c8fff0ef          	jal	80001932 <myproc>
    80001ca8:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001caa:	ea9ff0ef          	jal	80001b52 <allocproc>
    80001cae:	0e050a63          	beqz	a0,80001da2 <kfork+0x10a>
    80001cb2:	e852                	sd	s4,16(sp)
    80001cb4:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001cb6:	048ab603          	ld	a2,72(s5)
    80001cba:	692c                	ld	a1,80(a0)
    80001cbc:	050ab503          	ld	a0,80(s5)
    80001cc0:	f00ff0ef          	jal	800013c0 <uvmcopy>
    80001cc4:	04054a63          	bltz	a0,80001d18 <kfork+0x80>
    80001cc8:	f426                	sd	s1,40(sp)
    80001cca:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001ccc:	048ab783          	ld	a5,72(s5)
    80001cd0:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cd4:	058ab683          	ld	a3,88(s5)
    80001cd8:	87b6                	mv	a5,a3
    80001cda:	058a3703          	ld	a4,88(s4)
    80001cde:	12068693          	addi	a3,a3,288
    80001ce2:	0007b803          	ld	a6,0(a5)
    80001ce6:	6788                	ld	a0,8(a5)
    80001ce8:	6b8c                	ld	a1,16(a5)
    80001cea:	6f90                	ld	a2,24(a5)
    80001cec:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001cf0:	e708                	sd	a0,8(a4)
    80001cf2:	eb0c                	sd	a1,16(a4)
    80001cf4:	ef10                	sd	a2,24(a4)
    80001cf6:	02078793          	addi	a5,a5,32
    80001cfa:	02070713          	addi	a4,a4,32
    80001cfe:	fed792e3          	bne	a5,a3,80001ce2 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001d02:	058a3783          	ld	a5,88(s4)
    80001d06:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001d0a:	0d0a8493          	addi	s1,s5,208
    80001d0e:	0d0a0913          	addi	s2,s4,208
    80001d12:	150a8993          	addi	s3,s5,336
    80001d16:	a831                	j	80001d32 <kfork+0x9a>
    freeproc(np);
    80001d18:	8552                	mv	a0,s4
    80001d1a:	de9ff0ef          	jal	80001b02 <freeproc>
    release(&np->lock);
    80001d1e:	8552                	mv	a0,s4
    80001d20:	f47fe0ef          	jal	80000c66 <release>
    return -1;
    80001d24:	597d                	li	s2,-1
    80001d26:	6a42                	ld	s4,16(sp)
    80001d28:	a0b5                	j	80001d94 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001d2a:	04a1                	addi	s1,s1,8
    80001d2c:	0921                	addi	s2,s2,8
    80001d2e:	01348963          	beq	s1,s3,80001d40 <kfork+0xa8>
    if(p->ofile[i])
    80001d32:	6088                	ld	a0,0(s1)
    80001d34:	d97d                	beqz	a0,80001d2a <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d36:	570020ef          	jal	800042a6 <filedup>
    80001d3a:	00a93023          	sd	a0,0(s2)
    80001d3e:	b7f5                	j	80001d2a <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001d40:	150ab503          	ld	a0,336(s5)
    80001d44:	77c010ef          	jal	800034c0 <idup>
    80001d48:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d4c:	4641                	li	a2,16
    80001d4e:	158a8593          	addi	a1,s5,344
    80001d52:	158a0513          	addi	a0,s4,344
    80001d56:	88aff0ef          	jal	80000de0 <safestrcpy>
  pid = np->pid;
    80001d5a:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001d5e:	8552                	mv	a0,s4
    80001d60:	f07fe0ef          	jal	80000c66 <release>
  acquire(&wait_lock);
    80001d64:	0000e497          	auipc	s1,0xe
    80001d68:	e7c48493          	addi	s1,s1,-388 # 8000fbe0 <wait_lock>
    80001d6c:	8526                	mv	a0,s1
    80001d6e:	e61fe0ef          	jal	80000bce <acquire>
  np->parent = p;
    80001d72:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d76:	8526                	mv	a0,s1
    80001d78:	eeffe0ef          	jal	80000c66 <release>
  acquire(&np->lock);
    80001d7c:	8552                	mv	a0,s4
    80001d7e:	e51fe0ef          	jal	80000bce <acquire>
  np->state = RUNNABLE;
    80001d82:	478d                	li	a5,3
    80001d84:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d88:	8552                	mv	a0,s4
    80001d8a:	eddfe0ef          	jal	80000c66 <release>
  return pid;
    80001d8e:	74a2                	ld	s1,40(sp)
    80001d90:	69e2                	ld	s3,24(sp)
    80001d92:	6a42                	ld	s4,16(sp)
}
    80001d94:	854a                	mv	a0,s2
    80001d96:	70e2                	ld	ra,56(sp)
    80001d98:	7442                	ld	s0,48(sp)
    80001d9a:	7902                	ld	s2,32(sp)
    80001d9c:	6aa2                	ld	s5,8(sp)
    80001d9e:	6121                	addi	sp,sp,64
    80001da0:	8082                	ret
    return -1;
    80001da2:	597d                	li	s2,-1
    80001da4:	bfc5                	j	80001d94 <kfork+0xfc>

0000000080001da6 <scheduler>:
{
    80001da6:	7159                	addi	sp,sp,-112
    80001da8:	f486                	sd	ra,104(sp)
    80001daa:	f0a2                	sd	s0,96(sp)
    80001dac:	eca6                	sd	s1,88(sp)
    80001dae:	e8ca                	sd	s2,80(sp)
    80001db0:	e4ce                	sd	s3,72(sp)
    80001db2:	e0d2                	sd	s4,64(sp)
    80001db4:	fc56                	sd	s5,56(sp)
    80001db6:	f85a                	sd	s6,48(sp)
    80001db8:	f45e                	sd	s7,40(sp)
    80001dba:	f062                	sd	s8,32(sp)
    80001dbc:	ec66                	sd	s9,24(sp)
    80001dbe:	e86a                	sd	s10,16(sp)
    80001dc0:	e46e                	sd	s11,8(sp)
    80001dc2:	1880                	addi	s0,sp,112
    80001dc4:	8792                	mv	a5,tp
  int id = r_tp();
    80001dc6:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001dc8:	00779d13          	slli	s10,a5,0x7
    80001dcc:	0000e717          	auipc	a4,0xe
    80001dd0:	dfc70713          	addi	a4,a4,-516 # 8000fbc8 <pid_lock>
    80001dd4:	976a                	add	a4,a4,s10
    80001dd6:	02073823          	sd	zero,48(a4)
      swtch(&c->context, &chosen->context);
    80001dda:	0000e717          	auipc	a4,0xe
    80001dde:	e2670713          	addi	a4,a4,-474 # 8000fc00 <cpus+0x8>
    80001de2:	9d3a                	add	s10,s10,a4
    uint64 earliest = (uint64)-1;
    80001de4:	5cfd                	li	s9,-1
    chosen = 0;
    80001de6:	4c01                	li	s8,0
        printf("PID: %d | creationTime: %d\n", p->pid, p->creation_time);
    80001de8:	00005b17          	auipc	s6,0x5
    80001dec:	3b0b0b13          	addi	s6,s6,944 # 80007198 <etext+0x198>
    for(p = proc; p < &proc[NPROC]; p++){
    80001df0:	00014997          	auipc	s3,0x14
    80001df4:	00898993          	addi	s3,s3,8 # 80015df8 <tickslock>
      c->proc = chosen;
    80001df8:	079e                	slli	a5,a5,0x7
    80001dfa:	0000eb97          	auipc	s7,0xe
    80001dfe:	dceb8b93          	addi	s7,s7,-562 # 8000fbc8 <pid_lock>
    80001e02:	9bbe                	add	s7,s7,a5
          chosen->start_time = ticks;  // record first scheduled
    80001e04:	00006d97          	auipc	s11,0x6
    80001e08:	cb4d8d93          	addi	s11,s11,-844 # 80007ab8 <ticks>
    80001e0c:	a049                	j	80001e8e <scheduler+0xe8>
      release(&p->lock);
    80001e0e:	8526                	mv	a0,s1
    80001e10:	e57fe0ef          	jal	80000c66 <release>
    for(p = proc; p < &proc[NPROC]; p++){
    80001e14:	17848493          	addi	s1,s1,376
    80001e18:	03348b63          	beq	s1,s3,80001e4e <scheduler+0xa8>
      acquire(&p->lock);
    80001e1c:	8526                	mv	a0,s1
    80001e1e:	db1fe0ef          	jal	80000bce <acquire>
      if(p->state == RUNNABLE){
    80001e22:	4c9c                	lw	a5,24(s1)
    80001e24:	ff2795e3          	bne	a5,s2,80001e0e <scheduler+0x68>
        printf("PID: %d | creationTime: %d\n", p->pid, p->creation_time);
    80001e28:	1684a603          	lw	a2,360(s1)
    80001e2c:	588c                	lw	a1,48(s1)
    80001e2e:	855a                	mv	a0,s6
    80001e30:	ecafe0ef          	jal	800004fa <printf>
        if(p->creation_time < earliest){
    80001e34:	1684e783          	lwu	a5,360(s1)
    80001e38:	fd47fbe3          	bgeu	a5,s4,80001e0e <scheduler+0x68>
          if(chosen) release(&chosen->lock);
    80001e3c:	000a8563          	beqz	s5,80001e46 <scheduler+0xa0>
    80001e40:	8556                	mv	a0,s5
    80001e42:	e25fe0ef          	jal	80000c66 <release>
          earliest = p->creation_time;
    80001e46:	1684ea03          	lwu	s4,360(s1)
          chosen = p; // keep chosen->lock held
    80001e4a:	8aa6                	mv	s5,s1
          continue;   // keep chosen's lock held, release others as we go
    80001e4c:	b7e1                	j	80001e14 <scheduler+0x6e>
    if(chosen){
    80001e4e:	040a8e63          	beqz	s5,80001eaa <scheduler+0x104>
      if(chosen->start_time == 0) {
    80001e52:	16caa783          	lw	a5,364(s5)
    80001e56:	e789                	bnez	a5,80001e60 <scheduler+0xba>
          chosen->start_time = ticks;  // record first scheduled
    80001e58:	000da783          	lw	a5,0(s11)
    80001e5c:	16faa623          	sw	a5,364(s5)
      chosen->state = RUNNING;
    80001e60:	4791                	li	a5,4
    80001e62:	00faac23          	sw	a5,24(s5)
      c->proc = chosen;
    80001e66:	035bb823          	sd	s5,48(s7)
      printf("--> Scheduling PID %d (lowest creation_time)\n", chosen->pid);
    80001e6a:	030aa583          	lw	a1,48(s5)
    80001e6e:	00005517          	auipc	a0,0x5
    80001e72:	34a50513          	addi	a0,a0,842 # 800071b8 <etext+0x1b8>
    80001e76:	e84fe0ef          	jal	800004fa <printf>
      swtch(&c->context, &chosen->context);
    80001e7a:	060a8593          	addi	a1,s5,96
    80001e7e:	856a                	mv	a0,s10
    80001e80:	748000ef          	jal	800025c8 <swtch>
      c->proc = 0;
    80001e84:	020bb823          	sd	zero,48(s7)
      release(&chosen->lock);
    80001e88:	8556                	mv	a0,s5
    80001e8a:	dddfe0ef          	jal	80000c66 <release>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e8e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e92:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e96:	10079073          	csrw	sstatus,a5
    uint64 earliest = (uint64)-1;
    80001e9a:	8a66                	mv	s4,s9
    chosen = 0;
    80001e9c:	8ae2                	mv	s5,s8
    for(p = proc; p < &proc[NPROC]; p++){
    80001e9e:	0000e497          	auipc	s1,0xe
    80001ea2:	15a48493          	addi	s1,s1,346 # 8000fff8 <proc>
      if(p->state == RUNNABLE){
    80001ea6:	490d                	li	s2,3
    80001ea8:	bf95                	j	80001e1c <scheduler+0x76>
      asm volatile("wfi");
    80001eaa:	10500073          	wfi
    80001eae:	b7c5                	j	80001e8e <scheduler+0xe8>

0000000080001eb0 <sched>:
{
    80001eb0:	7179                	addi	sp,sp,-48
    80001eb2:	f406                	sd	ra,40(sp)
    80001eb4:	f022                	sd	s0,32(sp)
    80001eb6:	ec26                	sd	s1,24(sp)
    80001eb8:	e84a                	sd	s2,16(sp)
    80001eba:	e44e                	sd	s3,8(sp)
    80001ebc:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001ebe:	a75ff0ef          	jal	80001932 <myproc>
    80001ec2:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001ec4:	ca1fe0ef          	jal	80000b64 <holding>
    80001ec8:	c92d                	beqz	a0,80001f3a <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001eca:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001ecc:	2781                	sext.w	a5,a5
    80001ece:	079e                	slli	a5,a5,0x7
    80001ed0:	0000e717          	auipc	a4,0xe
    80001ed4:	cf870713          	addi	a4,a4,-776 # 8000fbc8 <pid_lock>
    80001ed8:	97ba                	add	a5,a5,a4
    80001eda:	0a87a703          	lw	a4,168(a5)
    80001ede:	4785                	li	a5,1
    80001ee0:	06f71363          	bne	a4,a5,80001f46 <sched+0x96>
  if(p->state == RUNNING)
    80001ee4:	4c98                	lw	a4,24(s1)
    80001ee6:	4791                	li	a5,4
    80001ee8:	06f70563          	beq	a4,a5,80001f52 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001eec:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001ef0:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001ef2:	e7b5                	bnez	a5,80001f5e <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001ef4:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001ef6:	0000e917          	auipc	s2,0xe
    80001efa:	cd290913          	addi	s2,s2,-814 # 8000fbc8 <pid_lock>
    80001efe:	2781                	sext.w	a5,a5
    80001f00:	079e                	slli	a5,a5,0x7
    80001f02:	97ca                	add	a5,a5,s2
    80001f04:	0ac7a983          	lw	s3,172(a5)
    80001f08:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001f0a:	2781                	sext.w	a5,a5
    80001f0c:	079e                	slli	a5,a5,0x7
    80001f0e:	0000e597          	auipc	a1,0xe
    80001f12:	cf258593          	addi	a1,a1,-782 # 8000fc00 <cpus+0x8>
    80001f16:	95be                	add	a1,a1,a5
    80001f18:	06048513          	addi	a0,s1,96
    80001f1c:	6ac000ef          	jal	800025c8 <swtch>
    80001f20:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001f22:	2781                	sext.w	a5,a5
    80001f24:	079e                	slli	a5,a5,0x7
    80001f26:	993e                	add	s2,s2,a5
    80001f28:	0b392623          	sw	s3,172(s2)
}
    80001f2c:	70a2                	ld	ra,40(sp)
    80001f2e:	7402                	ld	s0,32(sp)
    80001f30:	64e2                	ld	s1,24(sp)
    80001f32:	6942                	ld	s2,16(sp)
    80001f34:	69a2                	ld	s3,8(sp)
    80001f36:	6145                	addi	sp,sp,48
    80001f38:	8082                	ret
    panic("sched p->lock");
    80001f3a:	00005517          	auipc	a0,0x5
    80001f3e:	2ae50513          	addi	a0,a0,686 # 800071e8 <etext+0x1e8>
    80001f42:	89ffe0ef          	jal	800007e0 <panic>
    panic("sched locks");
    80001f46:	00005517          	auipc	a0,0x5
    80001f4a:	2b250513          	addi	a0,a0,690 # 800071f8 <etext+0x1f8>
    80001f4e:	893fe0ef          	jal	800007e0 <panic>
    panic("sched RUNNING");
    80001f52:	00005517          	auipc	a0,0x5
    80001f56:	2b650513          	addi	a0,a0,694 # 80007208 <etext+0x208>
    80001f5a:	887fe0ef          	jal	800007e0 <panic>
    panic("sched interruptible");
    80001f5e:	00005517          	auipc	a0,0x5
    80001f62:	2ba50513          	addi	a0,a0,698 # 80007218 <etext+0x218>
    80001f66:	87bfe0ef          	jal	800007e0 <panic>

0000000080001f6a <yield>:
{
    80001f6a:	1101                	addi	sp,sp,-32
    80001f6c:	ec06                	sd	ra,24(sp)
    80001f6e:	e822                	sd	s0,16(sp)
    80001f70:	e426                	sd	s1,8(sp)
    80001f72:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f74:	9bfff0ef          	jal	80001932 <myproc>
    80001f78:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f7a:	c55fe0ef          	jal	80000bce <acquire>
  p->state = RUNNABLE;
    80001f7e:	478d                	li	a5,3
    80001f80:	cc9c                	sw	a5,24(s1)
  sched();
    80001f82:	f2fff0ef          	jal	80001eb0 <sched>
  release(&p->lock);
    80001f86:	8526                	mv	a0,s1
    80001f88:	cdffe0ef          	jal	80000c66 <release>
}
    80001f8c:	60e2                	ld	ra,24(sp)
    80001f8e:	6442                	ld	s0,16(sp)
    80001f90:	64a2                	ld	s1,8(sp)
    80001f92:	6105                	addi	sp,sp,32
    80001f94:	8082                	ret

0000000080001f96 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001f96:	7179                	addi	sp,sp,-48
    80001f98:	f406                	sd	ra,40(sp)
    80001f9a:	f022                	sd	s0,32(sp)
    80001f9c:	ec26                	sd	s1,24(sp)
    80001f9e:	e84a                	sd	s2,16(sp)
    80001fa0:	e44e                	sd	s3,8(sp)
    80001fa2:	1800                	addi	s0,sp,48
    80001fa4:	89aa                	mv	s3,a0
    80001fa6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001fa8:	98bff0ef          	jal	80001932 <myproc>
    80001fac:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001fae:	c21fe0ef          	jal	80000bce <acquire>
  release(lk);
    80001fb2:	854a                	mv	a0,s2
    80001fb4:	cb3fe0ef          	jal	80000c66 <release>

  // Go to sleep.
  p->chan = chan;
    80001fb8:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001fbc:	4789                	li	a5,2
    80001fbe:	cc9c                	sw	a5,24(s1)

  sched();
    80001fc0:	ef1ff0ef          	jal	80001eb0 <sched>

  // Tidy up.
  p->chan = 0;
    80001fc4:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001fc8:	8526                	mv	a0,s1
    80001fca:	c9dfe0ef          	jal	80000c66 <release>
  acquire(lk);
    80001fce:	854a                	mv	a0,s2
    80001fd0:	bfffe0ef          	jal	80000bce <acquire>
}
    80001fd4:	70a2                	ld	ra,40(sp)
    80001fd6:	7402                	ld	s0,32(sp)
    80001fd8:	64e2                	ld	s1,24(sp)
    80001fda:	6942                	ld	s2,16(sp)
    80001fdc:	69a2                	ld	s3,8(sp)
    80001fde:	6145                	addi	sp,sp,48
    80001fe0:	8082                	ret

0000000080001fe2 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001fe2:	7139                	addi	sp,sp,-64
    80001fe4:	fc06                	sd	ra,56(sp)
    80001fe6:	f822                	sd	s0,48(sp)
    80001fe8:	f426                	sd	s1,40(sp)
    80001fea:	f04a                	sd	s2,32(sp)
    80001fec:	ec4e                	sd	s3,24(sp)
    80001fee:	e852                	sd	s4,16(sp)
    80001ff0:	e456                	sd	s5,8(sp)
    80001ff2:	0080                	addi	s0,sp,64
    80001ff4:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001ff6:	0000e497          	auipc	s1,0xe
    80001ffa:	00248493          	addi	s1,s1,2 # 8000fff8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001ffe:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002000:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80002002:	00014917          	auipc	s2,0x14
    80002006:	df690913          	addi	s2,s2,-522 # 80015df8 <tickslock>
    8000200a:	a801                	j	8000201a <wakeup+0x38>
      }
      release(&p->lock);
    8000200c:	8526                	mv	a0,s1
    8000200e:	c59fe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80002012:	17848493          	addi	s1,s1,376
    80002016:	03248263          	beq	s1,s2,8000203a <wakeup+0x58>
    if(p != myproc()){
    8000201a:	919ff0ef          	jal	80001932 <myproc>
    8000201e:	fea48ae3          	beq	s1,a0,80002012 <wakeup+0x30>
      acquire(&p->lock);
    80002022:	8526                	mv	a0,s1
    80002024:	babfe0ef          	jal	80000bce <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80002028:	4c9c                	lw	a5,24(s1)
    8000202a:	ff3791e3          	bne	a5,s3,8000200c <wakeup+0x2a>
    8000202e:	709c                	ld	a5,32(s1)
    80002030:	fd479ee3          	bne	a5,s4,8000200c <wakeup+0x2a>
        p->state = RUNNABLE;
    80002034:	0154ac23          	sw	s5,24(s1)
    80002038:	bfd1                	j	8000200c <wakeup+0x2a>
    }
  }
}
    8000203a:	70e2                	ld	ra,56(sp)
    8000203c:	7442                	ld	s0,48(sp)
    8000203e:	74a2                	ld	s1,40(sp)
    80002040:	7902                	ld	s2,32(sp)
    80002042:	69e2                	ld	s3,24(sp)
    80002044:	6a42                	ld	s4,16(sp)
    80002046:	6aa2                	ld	s5,8(sp)
    80002048:	6121                	addi	sp,sp,64
    8000204a:	8082                	ret

000000008000204c <reparent>:
{
    8000204c:	7179                	addi	sp,sp,-48
    8000204e:	f406                	sd	ra,40(sp)
    80002050:	f022                	sd	s0,32(sp)
    80002052:	ec26                	sd	s1,24(sp)
    80002054:	e84a                	sd	s2,16(sp)
    80002056:	e44e                	sd	s3,8(sp)
    80002058:	e052                	sd	s4,0(sp)
    8000205a:	1800                	addi	s0,sp,48
    8000205c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000205e:	0000e497          	auipc	s1,0xe
    80002062:	f9a48493          	addi	s1,s1,-102 # 8000fff8 <proc>
      pp->parent = initproc;
    80002066:	00006a17          	auipc	s4,0x6
    8000206a:	a4aa0a13          	addi	s4,s4,-1462 # 80007ab0 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000206e:	00014997          	auipc	s3,0x14
    80002072:	d8a98993          	addi	s3,s3,-630 # 80015df8 <tickslock>
    80002076:	a029                	j	80002080 <reparent+0x34>
    80002078:	17848493          	addi	s1,s1,376
    8000207c:	01348b63          	beq	s1,s3,80002092 <reparent+0x46>
    if(pp->parent == p){
    80002080:	7c9c                	ld	a5,56(s1)
    80002082:	ff279be3          	bne	a5,s2,80002078 <reparent+0x2c>
      pp->parent = initproc;
    80002086:	000a3503          	ld	a0,0(s4)
    8000208a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000208c:	f57ff0ef          	jal	80001fe2 <wakeup>
    80002090:	b7e5                	j	80002078 <reparent+0x2c>
}
    80002092:	70a2                	ld	ra,40(sp)
    80002094:	7402                	ld	s0,32(sp)
    80002096:	64e2                	ld	s1,24(sp)
    80002098:	6942                	ld	s2,16(sp)
    8000209a:	69a2                	ld	s3,8(sp)
    8000209c:	6a02                	ld	s4,0(sp)
    8000209e:	6145                	addi	sp,sp,48
    800020a0:	8082                	ret

00000000800020a2 <kexit>:
{
    800020a2:	7179                	addi	sp,sp,-48
    800020a4:	f406                	sd	ra,40(sp)
    800020a6:	f022                	sd	s0,32(sp)
    800020a8:	ec26                	sd	s1,24(sp)
    800020aa:	e84a                	sd	s2,16(sp)
    800020ac:	e44e                	sd	s3,8(sp)
    800020ae:	e052                	sd	s4,0(sp)
    800020b0:	1800                	addi	s0,sp,48
    800020b2:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800020b4:	87fff0ef          	jal	80001932 <myproc>
    800020b8:	89aa                	mv	s3,a0
  if(p == initproc)
    800020ba:	00006797          	auipc	a5,0x6
    800020be:	9f67b783          	ld	a5,-1546(a5) # 80007ab0 <initproc>
    800020c2:	0d050493          	addi	s1,a0,208
    800020c6:	15050913          	addi	s2,a0,336
    800020ca:	00a79f63          	bne	a5,a0,800020e8 <kexit+0x46>
    panic("init exiting");
    800020ce:	00005517          	auipc	a0,0x5
    800020d2:	16250513          	addi	a0,a0,354 # 80007230 <etext+0x230>
    800020d6:	f0afe0ef          	jal	800007e0 <panic>
      fileclose(f);
    800020da:	212020ef          	jal	800042ec <fileclose>
      p->ofile[fd] = 0;
    800020de:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800020e2:	04a1                	addi	s1,s1,8
    800020e4:	01248563          	beq	s1,s2,800020ee <kexit+0x4c>
    if(p->ofile[fd]){
    800020e8:	6088                	ld	a0,0(s1)
    800020ea:	f965                	bnez	a0,800020da <kexit+0x38>
    800020ec:	bfdd                	j	800020e2 <kexit+0x40>
  begin_op();
    800020ee:	5f3010ef          	jal	80003ee0 <begin_op>
  iput(p->cwd);
    800020f2:	1509b503          	ld	a0,336(s3)
    800020f6:	582010ef          	jal	80003678 <iput>
  end_op();
    800020fa:	651010ef          	jal	80003f4a <end_op>
  p->cwd = 0;
    800020fe:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002102:	0000e497          	auipc	s1,0xe
    80002106:	ade48493          	addi	s1,s1,-1314 # 8000fbe0 <wait_lock>
    8000210a:	8526                	mv	a0,s1
    8000210c:	ac3fe0ef          	jal	80000bce <acquire>
  reparent(p);
    80002110:	854e                	mv	a0,s3
    80002112:	f3bff0ef          	jal	8000204c <reparent>
  wakeup(p->parent);
    80002116:	0389b503          	ld	a0,56(s3)
    8000211a:	ec9ff0ef          	jal	80001fe2 <wakeup>
  acquire(&p->lock);
    8000211e:	854e                	mv	a0,s3
    80002120:	aaffe0ef          	jal	80000bce <acquire>
  p->xstate = status;
    80002124:	0349a623          	sw	s4,44(s3)
  p->end_time = ticks;  
    80002128:	00006797          	auipc	a5,0x6
    8000212c:	9907a783          	lw	a5,-1648(a5) # 80007ab8 <ticks>
    80002130:	16f9a823          	sw	a5,368(s3)
  printf("===========================================UPDATED END TIME==============================================\n");     // record exit time
    80002134:	00005517          	auipc	a0,0x5
    80002138:	10c50513          	addi	a0,a0,268 # 80007240 <etext+0x240>
    8000213c:	bbefe0ef          	jal	800004fa <printf>
  p->state = ZOMBIE;
    80002140:	4795                	li	a5,5
    80002142:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002146:	8526                	mv	a0,s1
    80002148:	b1ffe0ef          	jal	80000c66 <release>
  sched();
    8000214c:	d65ff0ef          	jal	80001eb0 <sched>
  panic("zombie exit");
    80002150:	00005517          	auipc	a0,0x5
    80002154:	16050513          	addi	a0,a0,352 # 800072b0 <etext+0x2b0>
    80002158:	e88fe0ef          	jal	800007e0 <panic>

000000008000215c <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    8000215c:	7179                	addi	sp,sp,-48
    8000215e:	f406                	sd	ra,40(sp)
    80002160:	f022                	sd	s0,32(sp)
    80002162:	ec26                	sd	s1,24(sp)
    80002164:	e84a                	sd	s2,16(sp)
    80002166:	e44e                	sd	s3,8(sp)
    80002168:	1800                	addi	s0,sp,48
    8000216a:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000216c:	0000e497          	auipc	s1,0xe
    80002170:	e8c48493          	addi	s1,s1,-372 # 8000fff8 <proc>
    80002174:	00014997          	auipc	s3,0x14
    80002178:	c8498993          	addi	s3,s3,-892 # 80015df8 <tickslock>
    acquire(&p->lock);
    8000217c:	8526                	mv	a0,s1
    8000217e:	a51fe0ef          	jal	80000bce <acquire>
    if(p->pid == pid){
    80002182:	589c                	lw	a5,48(s1)
    80002184:	01278b63          	beq	a5,s2,8000219a <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002188:	8526                	mv	a0,s1
    8000218a:	addfe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000218e:	17848493          	addi	s1,s1,376
    80002192:	ff3495e3          	bne	s1,s3,8000217c <kkill+0x20>
  }
  return -1;
    80002196:	557d                	li	a0,-1
    80002198:	a819                	j	800021ae <kkill+0x52>
      p->killed = 1;
    8000219a:	4785                	li	a5,1
    8000219c:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000219e:	4c98                	lw	a4,24(s1)
    800021a0:	4789                	li	a5,2
    800021a2:	00f70d63          	beq	a4,a5,800021bc <kkill+0x60>
      release(&p->lock);
    800021a6:	8526                	mv	a0,s1
    800021a8:	abffe0ef          	jal	80000c66 <release>
      return 0;
    800021ac:	4501                	li	a0,0
}
    800021ae:	70a2                	ld	ra,40(sp)
    800021b0:	7402                	ld	s0,32(sp)
    800021b2:	64e2                	ld	s1,24(sp)
    800021b4:	6942                	ld	s2,16(sp)
    800021b6:	69a2                	ld	s3,8(sp)
    800021b8:	6145                	addi	sp,sp,48
    800021ba:	8082                	ret
        p->state = RUNNABLE;
    800021bc:	478d                	li	a5,3
    800021be:	cc9c                	sw	a5,24(s1)
    800021c0:	b7dd                	j	800021a6 <kkill+0x4a>

00000000800021c2 <setkilled>:

void
setkilled(struct proc *p)
{
    800021c2:	1101                	addi	sp,sp,-32
    800021c4:	ec06                	sd	ra,24(sp)
    800021c6:	e822                	sd	s0,16(sp)
    800021c8:	e426                	sd	s1,8(sp)
    800021ca:	1000                	addi	s0,sp,32
    800021cc:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800021ce:	a01fe0ef          	jal	80000bce <acquire>
  p->killed = 1;
    800021d2:	4785                	li	a5,1
    800021d4:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800021d6:	8526                	mv	a0,s1
    800021d8:	a8ffe0ef          	jal	80000c66 <release>
}
    800021dc:	60e2                	ld	ra,24(sp)
    800021de:	6442                	ld	s0,16(sp)
    800021e0:	64a2                	ld	s1,8(sp)
    800021e2:	6105                	addi	sp,sp,32
    800021e4:	8082                	ret

00000000800021e6 <killed>:

int
killed(struct proc *p)
{
    800021e6:	1101                	addi	sp,sp,-32
    800021e8:	ec06                	sd	ra,24(sp)
    800021ea:	e822                	sd	s0,16(sp)
    800021ec:	e426                	sd	s1,8(sp)
    800021ee:	e04a                	sd	s2,0(sp)
    800021f0:	1000                	addi	s0,sp,32
    800021f2:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800021f4:	9dbfe0ef          	jal	80000bce <acquire>
  k = p->killed;
    800021f8:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800021fc:	8526                	mv	a0,s1
    800021fe:	a69fe0ef          	jal	80000c66 <release>
  return k;
}
    80002202:	854a                	mv	a0,s2
    80002204:	60e2                	ld	ra,24(sp)
    80002206:	6442                	ld	s0,16(sp)
    80002208:	64a2                	ld	s1,8(sp)
    8000220a:	6902                	ld	s2,0(sp)
    8000220c:	6105                	addi	sp,sp,32
    8000220e:	8082                	ret

0000000080002210 <waitx>:
{
    80002210:	7159                	addi	sp,sp,-112
    80002212:	f486                	sd	ra,104(sp)
    80002214:	f0a2                	sd	s0,96(sp)
    80002216:	eca6                	sd	s1,88(sp)
    80002218:	e8ca                	sd	s2,80(sp)
    8000221a:	e4ce                	sd	s3,72(sp)
    8000221c:	e0d2                	sd	s4,64(sp)
    8000221e:	fc56                	sd	s5,56(sp)
    80002220:	f85a                	sd	s6,48(sp)
    80002222:	f45e                	sd	s7,40(sp)
    80002224:	f062                	sd	s8,32(sp)
    80002226:	ec66                	sd	s9,24(sp)
    80002228:	e86a                	sd	s10,16(sp)
    8000222a:	1880                	addi	s0,sp,112
    8000222c:	8c2a                	mv	s8,a0
    8000222e:	8bae                	mv	s7,a1
    80002230:	8b32                	mv	s6,a2
  struct proc *p = myproc();
    80002232:	f00ff0ef          	jal	80001932 <myproc>
    80002236:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002238:	0000e517          	auipc	a0,0xe
    8000223c:	9a850513          	addi	a0,a0,-1624 # 8000fbe0 <wait_lock>
    80002240:	98ffe0ef          	jal	80000bce <acquire>
    havekids = 0;
    80002244:	4c81                	li	s9,0
        if(pp->state == ZOMBIE){
    80002246:	4a15                	li	s4,5
        havekids = 1;
    80002248:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000224a:	00014997          	auipc	s3,0x14
    8000224e:	bae98993          	addi	s3,s3,-1106 # 80015df8 <tickslock>
    sleep(p, &wait_lock);  // DOC: wait-sleep - releases wait_lock, acquires p->lock inside sleep
    80002252:	0000ed17          	auipc	s10,0xe
    80002256:	98ed0d13          	addi	s10,s10,-1650 # 8000fbe0 <wait_lock>
    8000225a:	aa39                	j	80002378 <waitx+0x168>
          int wtime = (int)(pp->start_time - pp->creation_time);
    8000225c:	16c4a703          	lw	a4,364(s1)
    80002260:	1684a683          	lw	a3,360(s1)
    80002264:	40d707bb          	subw	a5,a4,a3
    80002268:	f8f42a23          	sw	a5,-108(s0)
          int rtime = (int)(pp->end_time - pp->start_time);
    8000226c:	1704a783          	lw	a5,368(s1)
    80002270:	40e7873b          	subw	a4,a5,a4
    80002274:	f8e42c23          	sw	a4,-104(s0)
          int tatime = (int)(pp->end_time - pp->creation_time);
    80002278:	9f95                	subw	a5,a5,a3
    8000227a:	f8f42e23          	sw	a5,-100(s0)
          pid = pp->pid;
    8000227e:	0304a983          	lw	s3,48(s1)
          if(addr_w && copyout(p->pagetable, addr_w, (char *)&wtime, sizeof(wtime)) < 0){
    80002282:	040c1b63          	bnez	s8,800022d8 <waitx+0xc8>
          if(addr_r && copyout(p->pagetable, addr_r, (char *)&rtime, sizeof(rtime)) < 0){
    80002286:	060b9e63          	bnez	s7,80002302 <waitx+0xf2>
          if(addr_t && copyout(p->pagetable, addr_t, (char *)&tatime, sizeof(tatime)) < 0){
    8000228a:	000b0c63          	beqz	s6,800022a2 <waitx+0x92>
    8000228e:	4691                	li	a3,4
    80002290:	f9c40613          	addi	a2,s0,-100
    80002294:	85da                	mv	a1,s6
    80002296:	05093503          	ld	a0,80(s2)
    8000229a:	b48ff0ef          	jal	800015e2 <copyout>
    8000229e:	08054763          	bltz	a0,8000232c <waitx+0x11c>
          freeproc(pp);
    800022a2:	8526                	mv	a0,s1
    800022a4:	85fff0ef          	jal	80001b02 <freeproc>
          release(&pp->lock);
    800022a8:	8526                	mv	a0,s1
    800022aa:	9bdfe0ef          	jal	80000c66 <release>
          release(&wait_lock);
    800022ae:	0000e517          	auipc	a0,0xe
    800022b2:	93250513          	addi	a0,a0,-1742 # 8000fbe0 <wait_lock>
    800022b6:	9b1fe0ef          	jal	80000c66 <release>
}
    800022ba:	854e                	mv	a0,s3
    800022bc:	70a6                	ld	ra,104(sp)
    800022be:	7406                	ld	s0,96(sp)
    800022c0:	64e6                	ld	s1,88(sp)
    800022c2:	6946                	ld	s2,80(sp)
    800022c4:	69a6                	ld	s3,72(sp)
    800022c6:	6a06                	ld	s4,64(sp)
    800022c8:	7ae2                	ld	s5,56(sp)
    800022ca:	7b42                	ld	s6,48(sp)
    800022cc:	7ba2                	ld	s7,40(sp)
    800022ce:	7c02                	ld	s8,32(sp)
    800022d0:	6ce2                	ld	s9,24(sp)
    800022d2:	6d42                	ld	s10,16(sp)
    800022d4:	6165                	addi	sp,sp,112
    800022d6:	8082                	ret
          if(addr_w && copyout(p->pagetable, addr_w, (char *)&wtime, sizeof(wtime)) < 0){
    800022d8:	4691                	li	a3,4
    800022da:	f9440613          	addi	a2,s0,-108
    800022de:	85e2                	mv	a1,s8
    800022e0:	05093503          	ld	a0,80(s2)
    800022e4:	afeff0ef          	jal	800015e2 <copyout>
    800022e8:	f8055fe3          	bgez	a0,80002286 <waitx+0x76>
            release(&pp->lock);
    800022ec:	8526                	mv	a0,s1
    800022ee:	979fe0ef          	jal	80000c66 <release>
            release(&wait_lock);
    800022f2:	0000e517          	auipc	a0,0xe
    800022f6:	8ee50513          	addi	a0,a0,-1810 # 8000fbe0 <wait_lock>
    800022fa:	96dfe0ef          	jal	80000c66 <release>
            return -1;
    800022fe:	59fd                	li	s3,-1
    80002300:	bf6d                	j	800022ba <waitx+0xaa>
          if(addr_r && copyout(p->pagetable, addr_r, (char *)&rtime, sizeof(rtime)) < 0){
    80002302:	4691                	li	a3,4
    80002304:	f9840613          	addi	a2,s0,-104
    80002308:	85de                	mv	a1,s7
    8000230a:	05093503          	ld	a0,80(s2)
    8000230e:	ad4ff0ef          	jal	800015e2 <copyout>
    80002312:	f6055ce3          	bgez	a0,8000228a <waitx+0x7a>
            release(&pp->lock);
    80002316:	8526                	mv	a0,s1
    80002318:	94ffe0ef          	jal	80000c66 <release>
            release(&wait_lock);
    8000231c:	0000e517          	auipc	a0,0xe
    80002320:	8c450513          	addi	a0,a0,-1852 # 8000fbe0 <wait_lock>
    80002324:	943fe0ef          	jal	80000c66 <release>
            return -1;
    80002328:	59fd                	li	s3,-1
    8000232a:	bf41                	j	800022ba <waitx+0xaa>
            release(&pp->lock);
    8000232c:	8526                	mv	a0,s1
    8000232e:	939fe0ef          	jal	80000c66 <release>
            release(&wait_lock);
    80002332:	0000e517          	auipc	a0,0xe
    80002336:	8ae50513          	addi	a0,a0,-1874 # 8000fbe0 <wait_lock>
    8000233a:	92dfe0ef          	jal	80000c66 <release>
            return -1;
    8000233e:	59fd                	li	s3,-1
    80002340:	bfad                	j	800022ba <waitx+0xaa>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002342:	17848493          	addi	s1,s1,376
    80002346:	03348063          	beq	s1,s3,80002366 <waitx+0x156>
      if(pp->parent == p){
    8000234a:	7c9c                	ld	a5,56(s1)
    8000234c:	ff279be3          	bne	a5,s2,80002342 <waitx+0x132>
        acquire(&pp->lock);
    80002350:	8526                	mv	a0,s1
    80002352:	87dfe0ef          	jal	80000bce <acquire>
        if(pp->state == ZOMBIE){
    80002356:	4c9c                	lw	a5,24(s1)
    80002358:	f14782e3          	beq	a5,s4,8000225c <waitx+0x4c>
        release(&pp->lock);
    8000235c:	8526                	mv	a0,s1
    8000235e:	909fe0ef          	jal	80000c66 <release>
        havekids = 1;
    80002362:	8756                	mv	a4,s5
    80002364:	bff9                	j	80002342 <waitx+0x132>
    if(!havekids || killed(p)){
    80002366:	cf19                	beqz	a4,80002384 <waitx+0x174>
    80002368:	854a                	mv	a0,s2
    8000236a:	e7dff0ef          	jal	800021e6 <killed>
    8000236e:	e919                	bnez	a0,80002384 <waitx+0x174>
    sleep(p, &wait_lock);  // DOC: wait-sleep - releases wait_lock, acquires p->lock inside sleep
    80002370:	85ea                	mv	a1,s10
    80002372:	854a                	mv	a0,s2
    80002374:	c23ff0ef          	jal	80001f96 <sleep>
    havekids = 0;
    80002378:	8766                	mv	a4,s9
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000237a:	0000e497          	auipc	s1,0xe
    8000237e:	c7e48493          	addi	s1,s1,-898 # 8000fff8 <proc>
    80002382:	b7e1                	j	8000234a <waitx+0x13a>
      release(&wait_lock);
    80002384:	0000e517          	auipc	a0,0xe
    80002388:	85c50513          	addi	a0,a0,-1956 # 8000fbe0 <wait_lock>
    8000238c:	8dbfe0ef          	jal	80000c66 <release>
      return -1;
    80002390:	59fd                	li	s3,-1
    80002392:	b725                	j	800022ba <waitx+0xaa>

0000000080002394 <kwait>:
{
    80002394:	715d                	addi	sp,sp,-80
    80002396:	e486                	sd	ra,72(sp)
    80002398:	e0a2                	sd	s0,64(sp)
    8000239a:	fc26                	sd	s1,56(sp)
    8000239c:	f84a                	sd	s2,48(sp)
    8000239e:	f44e                	sd	s3,40(sp)
    800023a0:	f052                	sd	s4,32(sp)
    800023a2:	ec56                	sd	s5,24(sp)
    800023a4:	e85a                	sd	s6,16(sp)
    800023a6:	e45e                	sd	s7,8(sp)
    800023a8:	e062                	sd	s8,0(sp)
    800023aa:	0880                	addi	s0,sp,80
    800023ac:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800023ae:	d84ff0ef          	jal	80001932 <myproc>
    800023b2:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800023b4:	0000e517          	auipc	a0,0xe
    800023b8:	82c50513          	addi	a0,a0,-2004 # 8000fbe0 <wait_lock>
    800023bc:	813fe0ef          	jal	80000bce <acquire>
    havekids = 0;
    800023c0:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800023c2:	4a15                	li	s4,5
        havekids = 1;
    800023c4:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800023c6:	00014997          	auipc	s3,0x14
    800023ca:	a3298993          	addi	s3,s3,-1486 # 80015df8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800023ce:	0000ec17          	auipc	s8,0xe
    800023d2:	812c0c13          	addi	s8,s8,-2030 # 8000fbe0 <wait_lock>
    800023d6:	a871                	j	80002472 <kwait+0xde>
          pid = pp->pid;
    800023d8:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800023dc:	000b0c63          	beqz	s6,800023f4 <kwait+0x60>
    800023e0:	4691                	li	a3,4
    800023e2:	02c48613          	addi	a2,s1,44
    800023e6:	85da                	mv	a1,s6
    800023e8:	05093503          	ld	a0,80(s2)
    800023ec:	9f6ff0ef          	jal	800015e2 <copyout>
    800023f0:	02054b63          	bltz	a0,80002426 <kwait+0x92>
          freeproc(pp);
    800023f4:	8526                	mv	a0,s1
    800023f6:	f0cff0ef          	jal	80001b02 <freeproc>
          release(&pp->lock);
    800023fa:	8526                	mv	a0,s1
    800023fc:	86bfe0ef          	jal	80000c66 <release>
          release(&wait_lock);
    80002400:	0000d517          	auipc	a0,0xd
    80002404:	7e050513          	addi	a0,a0,2016 # 8000fbe0 <wait_lock>
    80002408:	85ffe0ef          	jal	80000c66 <release>
}
    8000240c:	854e                	mv	a0,s3
    8000240e:	60a6                	ld	ra,72(sp)
    80002410:	6406                	ld	s0,64(sp)
    80002412:	74e2                	ld	s1,56(sp)
    80002414:	7942                	ld	s2,48(sp)
    80002416:	79a2                	ld	s3,40(sp)
    80002418:	7a02                	ld	s4,32(sp)
    8000241a:	6ae2                	ld	s5,24(sp)
    8000241c:	6b42                	ld	s6,16(sp)
    8000241e:	6ba2                	ld	s7,8(sp)
    80002420:	6c02                	ld	s8,0(sp)
    80002422:	6161                	addi	sp,sp,80
    80002424:	8082                	ret
            release(&pp->lock);
    80002426:	8526                	mv	a0,s1
    80002428:	83ffe0ef          	jal	80000c66 <release>
            release(&wait_lock);
    8000242c:	0000d517          	auipc	a0,0xd
    80002430:	7b450513          	addi	a0,a0,1972 # 8000fbe0 <wait_lock>
    80002434:	833fe0ef          	jal	80000c66 <release>
            return -1;
    80002438:	59fd                	li	s3,-1
    8000243a:	bfc9                	j	8000240c <kwait+0x78>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000243c:	17848493          	addi	s1,s1,376
    80002440:	03348063          	beq	s1,s3,80002460 <kwait+0xcc>
      if(pp->parent == p){
    80002444:	7c9c                	ld	a5,56(s1)
    80002446:	ff279be3          	bne	a5,s2,8000243c <kwait+0xa8>
        acquire(&pp->lock);
    8000244a:	8526                	mv	a0,s1
    8000244c:	f82fe0ef          	jal	80000bce <acquire>
        if(pp->state == ZOMBIE){
    80002450:	4c9c                	lw	a5,24(s1)
    80002452:	f94783e3          	beq	a5,s4,800023d8 <kwait+0x44>
        release(&pp->lock);
    80002456:	8526                	mv	a0,s1
    80002458:	80ffe0ef          	jal	80000c66 <release>
        havekids = 1;
    8000245c:	8756                	mv	a4,s5
    8000245e:	bff9                	j	8000243c <kwait+0xa8>
    if(!havekids || killed(p)){
    80002460:	cf19                	beqz	a4,8000247e <kwait+0xea>
    80002462:	854a                	mv	a0,s2
    80002464:	d83ff0ef          	jal	800021e6 <killed>
    80002468:	e919                	bnez	a0,8000247e <kwait+0xea>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000246a:	85e2                	mv	a1,s8
    8000246c:	854a                	mv	a0,s2
    8000246e:	b29ff0ef          	jal	80001f96 <sleep>
    havekids = 0;
    80002472:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002474:	0000e497          	auipc	s1,0xe
    80002478:	b8448493          	addi	s1,s1,-1148 # 8000fff8 <proc>
    8000247c:	b7e1                	j	80002444 <kwait+0xb0>
      release(&wait_lock);
    8000247e:	0000d517          	auipc	a0,0xd
    80002482:	76250513          	addi	a0,a0,1890 # 8000fbe0 <wait_lock>
    80002486:	fe0fe0ef          	jal	80000c66 <release>
      return -1;
    8000248a:	59fd                	li	s3,-1
    8000248c:	b741                	j	8000240c <kwait+0x78>

000000008000248e <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000248e:	7179                	addi	sp,sp,-48
    80002490:	f406                	sd	ra,40(sp)
    80002492:	f022                	sd	s0,32(sp)
    80002494:	ec26                	sd	s1,24(sp)
    80002496:	e84a                	sd	s2,16(sp)
    80002498:	e44e                	sd	s3,8(sp)
    8000249a:	e052                	sd	s4,0(sp)
    8000249c:	1800                	addi	s0,sp,48
    8000249e:	84aa                	mv	s1,a0
    800024a0:	892e                	mv	s2,a1
    800024a2:	89b2                	mv	s3,a2
    800024a4:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800024a6:	c8cff0ef          	jal	80001932 <myproc>
  if(user_dst){
    800024aa:	cc99                	beqz	s1,800024c8 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800024ac:	86d2                	mv	a3,s4
    800024ae:	864e                	mv	a2,s3
    800024b0:	85ca                	mv	a1,s2
    800024b2:	6928                	ld	a0,80(a0)
    800024b4:	92eff0ef          	jal	800015e2 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800024b8:	70a2                	ld	ra,40(sp)
    800024ba:	7402                	ld	s0,32(sp)
    800024bc:	64e2                	ld	s1,24(sp)
    800024be:	6942                	ld	s2,16(sp)
    800024c0:	69a2                	ld	s3,8(sp)
    800024c2:	6a02                	ld	s4,0(sp)
    800024c4:	6145                	addi	sp,sp,48
    800024c6:	8082                	ret
    memmove((char *)dst, src, len);
    800024c8:	000a061b          	sext.w	a2,s4
    800024cc:	85ce                	mv	a1,s3
    800024ce:	854a                	mv	a0,s2
    800024d0:	82ffe0ef          	jal	80000cfe <memmove>
    return 0;
    800024d4:	8526                	mv	a0,s1
    800024d6:	b7cd                	j	800024b8 <either_copyout+0x2a>

00000000800024d8 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800024d8:	7179                	addi	sp,sp,-48
    800024da:	f406                	sd	ra,40(sp)
    800024dc:	f022                	sd	s0,32(sp)
    800024de:	ec26                	sd	s1,24(sp)
    800024e0:	e84a                	sd	s2,16(sp)
    800024e2:	e44e                	sd	s3,8(sp)
    800024e4:	e052                	sd	s4,0(sp)
    800024e6:	1800                	addi	s0,sp,48
    800024e8:	892a                	mv	s2,a0
    800024ea:	84ae                	mv	s1,a1
    800024ec:	89b2                	mv	s3,a2
    800024ee:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800024f0:	c42ff0ef          	jal	80001932 <myproc>
  if(user_src){
    800024f4:	cc99                	beqz	s1,80002512 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800024f6:	86d2                	mv	a3,s4
    800024f8:	864e                	mv	a2,s3
    800024fa:	85ca                	mv	a1,s2
    800024fc:	6928                	ld	a0,80(a0)
    800024fe:	9c8ff0ef          	jal	800016c6 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002502:	70a2                	ld	ra,40(sp)
    80002504:	7402                	ld	s0,32(sp)
    80002506:	64e2                	ld	s1,24(sp)
    80002508:	6942                	ld	s2,16(sp)
    8000250a:	69a2                	ld	s3,8(sp)
    8000250c:	6a02                	ld	s4,0(sp)
    8000250e:	6145                	addi	sp,sp,48
    80002510:	8082                	ret
    memmove(dst, (char*)src, len);
    80002512:	000a061b          	sext.w	a2,s4
    80002516:	85ce                	mv	a1,s3
    80002518:	854a                	mv	a0,s2
    8000251a:	fe4fe0ef          	jal	80000cfe <memmove>
    return 0;
    8000251e:	8526                	mv	a0,s1
    80002520:	b7cd                	j	80002502 <either_copyin+0x2a>

0000000080002522 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002522:	7139                	addi	sp,sp,-64
    80002524:	fc06                	sd	ra,56(sp)
    80002526:	f822                	sd	s0,48(sp)
    80002528:	f426                	sd	s1,40(sp)
    8000252a:	f04a                	sd	s2,32(sp)
    8000252c:	ec4e                	sd	s3,24(sp)
    8000252e:	e852                	sd	s4,16(sp)
    80002530:	e456                	sd	s5,8(sp)
    80002532:	e05a                	sd	s6,0(sp)
    80002534:	0080                	addi	s0,sp,64
  #ifdef SCHEDULER_CFS
  printf("\n");
  printf("PID\tState\tvruntime\tNice\tWeight\n");
  printf("-------------------------------------------\n");
  #else
  printf("\n");
    80002536:	00005517          	auipc	a0,0x5
    8000253a:	b4250513          	addi	a0,a0,-1214 # 80007078 <etext+0x78>
    8000253e:	fbdfd0ef          	jal	800004fa <printf>
  printf("PID\tState\n");
    80002542:	00005517          	auipc	a0,0x5
    80002546:	d8650513          	addi	a0,a0,-634 # 800072c8 <etext+0x2c8>
    8000254a:	fb1fd0ef          	jal	800004fa <printf>
  printf("-------------------------------------------\n");
    8000254e:	00005517          	auipc	a0,0x5
    80002552:	d8a50513          	addi	a0,a0,-630 # 800072d8 <etext+0x2d8>
    80002556:	fa5fd0ef          	jal	800004fa <printf>
  #endif

  for(p = proc; p < &proc[NPROC]; p++){
    8000255a:	0000e497          	auipc	s1,0xe
    8000255e:	a9e48493          	addi	s1,s1,-1378 # 8000fff8 <proc>
    if(p->state == UNUSED)
      continue;

    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002562:	4a95                	li	s5,5
      state = states[p->state];
    else
      state = "???";
    80002564:	00005997          	auipc	s3,0x5
    80002568:	d5c98993          	addi	s3,s3,-676 # 800072c0 <etext+0x2c0>
      // Print all metrics in one line
      printf("%d\t%s\t%ld\t%d\t%ld\n", 
              p->pid, state, p->vruntime, p->nice, p->weight);
    #else
      // For other schedulers, just print PID and state
      printf("%d\t%s\n", p->pid, state);
    8000256c:	00005a17          	auipc	s4,0x5
    80002570:	d9ca0a13          	addi	s4,s4,-612 # 80007308 <etext+0x308>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002574:	00005b17          	auipc	s6,0x5
    80002578:	2acb0b13          	addi	s6,s6,684 # 80007820 <nice_to_weight>
  for(p = proc; p < &proc[NPROC]; p++){
    8000257c:	00014917          	auipc	s2,0x14
    80002580:	87c90913          	addi	s2,s2,-1924 # 80015df8 <tickslock>
    80002584:	a809                	j	80002596 <procdump+0x74>
      printf("%d\t%s\n", p->pid, state);
    80002586:	588c                	lw	a1,48(s1)
    80002588:	8552                	mv	a0,s4
    8000258a:	f71fd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000258e:	17848493          	addi	s1,s1,376
    80002592:	03248163          	beq	s1,s2,800025b4 <procdump+0x92>
    if(p->state == UNUSED)
    80002596:	4c9c                	lw	a5,24(s1)
    80002598:	dbfd                	beqz	a5,8000258e <procdump+0x6c>
      state = "???";
    8000259a:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000259c:	fefae5e3          	bltu	s5,a5,80002586 <procdump+0x64>
    800025a0:	02079713          	slli	a4,a5,0x20
    800025a4:	01d75793          	srli	a5,a4,0x1d
    800025a8:	97da                	add	a5,a5,s6
    800025aa:	1407b603          	ld	a2,320(a5)
    800025ae:	fe61                	bnez	a2,80002586 <procdump+0x64>
      state = "???";
    800025b0:	864e                	mv	a2,s3
    800025b2:	bfd1                	j	80002586 <procdump+0x64>
    #endif
  }
    800025b4:	70e2                	ld	ra,56(sp)
    800025b6:	7442                	ld	s0,48(sp)
    800025b8:	74a2                	ld	s1,40(sp)
    800025ba:	7902                	ld	s2,32(sp)
    800025bc:	69e2                	ld	s3,24(sp)
    800025be:	6a42                	ld	s4,16(sp)
    800025c0:	6aa2                	ld	s5,8(sp)
    800025c2:	6b02                	ld	s6,0(sp)
    800025c4:	6121                	addi	sp,sp,64
    800025c6:	8082                	ret

00000000800025c8 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800025c8:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800025cc:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800025d0:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800025d2:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800025d4:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800025d8:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800025dc:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800025e0:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800025e4:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800025e8:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800025ec:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800025f0:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800025f4:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800025f8:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800025fc:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002600:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002604:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002606:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002608:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000260c:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002610:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002614:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002618:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000261c:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002620:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002624:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002628:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000262c:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002630:	8082                	ret

0000000080002632 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002632:	1141                	addi	sp,sp,-16
    80002634:	e406                	sd	ra,8(sp)
    80002636:	e022                	sd	s0,0(sp)
    80002638:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000263a:	00005597          	auipc	a1,0x5
    8000263e:	d0658593          	addi	a1,a1,-762 # 80007340 <etext+0x340>
    80002642:	00013517          	auipc	a0,0x13
    80002646:	7b650513          	addi	a0,a0,1974 # 80015df8 <tickslock>
    8000264a:	d04fe0ef          	jal	80000b4e <initlock>
}
    8000264e:	60a2                	ld	ra,8(sp)
    80002650:	6402                	ld	s0,0(sp)
    80002652:	0141                	addi	sp,sp,16
    80002654:	8082                	ret

0000000080002656 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002656:	1141                	addi	sp,sp,-16
    80002658:	e422                	sd	s0,8(sp)
    8000265a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000265c:	00003797          	auipc	a5,0x3
    80002660:	01478793          	addi	a5,a5,20 # 80005670 <kernelvec>
    80002664:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002668:	6422                	ld	s0,8(sp)
    8000266a:	0141                	addi	sp,sp,16
    8000266c:	8082                	ret

000000008000266e <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000266e:	1141                	addi	sp,sp,-16
    80002670:	e406                	sd	ra,8(sp)
    80002672:	e022                	sd	s0,0(sp)
    80002674:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002676:	abcff0ef          	jal	80001932 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000267a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000267e:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002680:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002684:	04000737          	lui	a4,0x4000
    80002688:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000268a:	0732                	slli	a4,a4,0xc
    8000268c:	00004797          	auipc	a5,0x4
    80002690:	97478793          	addi	a5,a5,-1676 # 80006000 <_trampoline>
    80002694:	00004697          	auipc	a3,0x4
    80002698:	96c68693          	addi	a3,a3,-1684 # 80006000 <_trampoline>
    8000269c:	8f95                	sub	a5,a5,a3
    8000269e:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800026a0:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800026a4:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800026a6:	18002773          	csrr	a4,satp
    800026aa:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800026ac:	6d38                	ld	a4,88(a0)
    800026ae:	613c                	ld	a5,64(a0)
    800026b0:	6685                	lui	a3,0x1
    800026b2:	97b6                	add	a5,a5,a3
    800026b4:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800026b6:	6d3c                	ld	a5,88(a0)
    800026b8:	00000717          	auipc	a4,0x0
    800026bc:	0f870713          	addi	a4,a4,248 # 800027b0 <usertrap>
    800026c0:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800026c2:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800026c4:	8712                	mv	a4,tp
    800026c6:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026c8:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800026cc:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800026d0:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800026d4:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800026d8:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800026da:	6f9c                	ld	a5,24(a5)
    800026dc:	14179073          	csrw	sepc,a5
}
    800026e0:	60a2                	ld	ra,8(sp)
    800026e2:	6402                	ld	s0,0(sp)
    800026e4:	0141                	addi	sp,sp,16
    800026e6:	8082                	ret

00000000800026e8 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800026e8:	1101                	addi	sp,sp,-32
    800026ea:	ec06                	sd	ra,24(sp)
    800026ec:	e822                	sd	s0,16(sp)
    800026ee:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800026f0:	a16ff0ef          	jal	80001906 <cpuid>
    800026f4:	cd11                	beqz	a0,80002710 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800026f6:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800026fa:	000f4737          	lui	a4,0xf4
    800026fe:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002702:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002704:	14d79073          	csrw	stimecmp,a5
}
    80002708:	60e2                	ld	ra,24(sp)
    8000270a:	6442                	ld	s0,16(sp)
    8000270c:	6105                	addi	sp,sp,32
    8000270e:	8082                	ret
    80002710:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    80002712:	00013497          	auipc	s1,0x13
    80002716:	6e648493          	addi	s1,s1,1766 # 80015df8 <tickslock>
    8000271a:	8526                	mv	a0,s1
    8000271c:	cb2fe0ef          	jal	80000bce <acquire>
    ticks++;
    80002720:	00005517          	auipc	a0,0x5
    80002724:	39850513          	addi	a0,a0,920 # 80007ab8 <ticks>
    80002728:	411c                	lw	a5,0(a0)
    8000272a:	2785                	addiw	a5,a5,1
    8000272c:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    8000272e:	8b5ff0ef          	jal	80001fe2 <wakeup>
    release(&tickslock);
    80002732:	8526                	mv	a0,s1
    80002734:	d32fe0ef          	jal	80000c66 <release>
    80002738:	64a2                	ld	s1,8(sp)
    8000273a:	bf75                	j	800026f6 <clockintr+0xe>

000000008000273c <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000273c:	1101                	addi	sp,sp,-32
    8000273e:	ec06                	sd	ra,24(sp)
    80002740:	e822                	sd	s0,16(sp)
    80002742:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002744:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002748:	57fd                	li	a5,-1
    8000274a:	17fe                	slli	a5,a5,0x3f
    8000274c:	07a5                	addi	a5,a5,9
    8000274e:	00f70c63          	beq	a4,a5,80002766 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002752:	57fd                	li	a5,-1
    80002754:	17fe                	slli	a5,a5,0x3f
    80002756:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002758:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000275a:	04f70763          	beq	a4,a5,800027a8 <devintr+0x6c>
  }
}
    8000275e:	60e2                	ld	ra,24(sp)
    80002760:	6442                	ld	s0,16(sp)
    80002762:	6105                	addi	sp,sp,32
    80002764:	8082                	ret
    80002766:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002768:	7b5020ef          	jal	8000571c <plic_claim>
    8000276c:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    8000276e:	47a9                	li	a5,10
    80002770:	00f50963          	beq	a0,a5,80002782 <devintr+0x46>
    } else if(irq == VIRTIO0_IRQ){
    80002774:	4785                	li	a5,1
    80002776:	00f50963          	beq	a0,a5,80002788 <devintr+0x4c>
    return 1;
    8000277a:	4505                	li	a0,1
    } else if(irq){
    8000277c:	e889                	bnez	s1,8000278e <devintr+0x52>
    8000277e:	64a2                	ld	s1,8(sp)
    80002780:	bff9                	j	8000275e <devintr+0x22>
      uartintr();
    80002782:	a2efe0ef          	jal	800009b0 <uartintr>
    if(irq)
    80002786:	a819                	j	8000279c <devintr+0x60>
      virtio_disk_intr();
    80002788:	45a030ef          	jal	80005be2 <virtio_disk_intr>
    if(irq)
    8000278c:	a801                	j	8000279c <devintr+0x60>
      printf("unexpected interrupt irq=%d\n", irq);
    8000278e:	85a6                	mv	a1,s1
    80002790:	00005517          	auipc	a0,0x5
    80002794:	bb850513          	addi	a0,a0,-1096 # 80007348 <etext+0x348>
    80002798:	d63fd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    8000279c:	8526                	mv	a0,s1
    8000279e:	79f020ef          	jal	8000573c <plic_complete>
    return 1;
    800027a2:	4505                	li	a0,1
    800027a4:	64a2                	ld	s1,8(sp)
    800027a6:	bf65                	j	8000275e <devintr+0x22>
    clockintr();
    800027a8:	f41ff0ef          	jal	800026e8 <clockintr>
    return 2;
    800027ac:	4509                	li	a0,2
    800027ae:	bf45                	j	8000275e <devintr+0x22>

00000000800027b0 <usertrap>:
{
    800027b0:	1101                	addi	sp,sp,-32
    800027b2:	ec06                	sd	ra,24(sp)
    800027b4:	e822                	sd	s0,16(sp)
    800027b6:	e426                	sd	s1,8(sp)
    800027b8:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027ba:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800027be:	1007f793          	andi	a5,a5,256
    800027c2:	e7bd                	bnez	a5,80002830 <usertrap+0x80>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800027c4:	00003797          	auipc	a5,0x3
    800027c8:	eac78793          	addi	a5,a5,-340 # 80005670 <kernelvec>
    800027cc:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800027d0:	962ff0ef          	jal	80001932 <myproc>
    800027d4:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800027d6:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027d8:	14102773          	csrr	a4,sepc
    800027dc:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027de:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800027e2:	47a1                	li	a5,8
    800027e4:	04f70c63          	beq	a4,a5,8000283c <usertrap+0x8c>
  } else if((which_dev = devintr()) != 0){
    800027e8:	f55ff0ef          	jal	8000273c <devintr>
    800027ec:	e53d                	bnez	a0,8000285a <usertrap+0xaa>
    800027ee:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800027f2:	47bd                	li	a5,15
    800027f4:	08f70763          	beq	a4,a5,80002882 <usertrap+0xd2>
    800027f8:	14202773          	csrr	a4,scause
    800027fc:	47b5                	li	a5,13
    800027fe:	08f70263          	beq	a4,a5,80002882 <usertrap+0xd2>
    80002802:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002806:	5890                	lw	a2,48(s1)
    80002808:	00005517          	auipc	a0,0x5
    8000280c:	b8050513          	addi	a0,a0,-1152 # 80007388 <etext+0x388>
    80002810:	cebfd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002814:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002818:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000281c:	00005517          	auipc	a0,0x5
    80002820:	b9c50513          	addi	a0,a0,-1124 # 800073b8 <etext+0x3b8>
    80002824:	cd7fd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002828:	8526                	mv	a0,s1
    8000282a:	999ff0ef          	jal	800021c2 <setkilled>
    8000282e:	a035                	j	8000285a <usertrap+0xaa>
    panic("usertrap: not from user mode");
    80002830:	00005517          	auipc	a0,0x5
    80002834:	b3850513          	addi	a0,a0,-1224 # 80007368 <etext+0x368>
    80002838:	fa9fd0ef          	jal	800007e0 <panic>
    if(killed(p))
    8000283c:	9abff0ef          	jal	800021e6 <killed>
    80002840:	ed0d                	bnez	a0,8000287a <usertrap+0xca>
    p->trapframe->epc += 4;
    80002842:	6cb8                	ld	a4,88(s1)
    80002844:	6f1c                	ld	a5,24(a4)
    80002846:	0791                	addi	a5,a5,4
    80002848:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000284a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000284e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002852:	10079073          	csrw	sstatus,a5
    syscall();
    80002856:	22e000ef          	jal	80002a84 <syscall>
  if(killed(p))
    8000285a:	8526                	mv	a0,s1
    8000285c:	98bff0ef          	jal	800021e6 <killed>
    80002860:	ed0d                	bnez	a0,8000289a <usertrap+0xea>
  prepare_return();
    80002862:	e0dff0ef          	jal	8000266e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002866:	68a8                	ld	a0,80(s1)
    80002868:	8131                	srli	a0,a0,0xc
}
    8000286a:	57fd                	li	a5,-1
    8000286c:	17fe                	slli	a5,a5,0x3f
    8000286e:	8d5d                	or	a0,a0,a5
    80002870:	60e2                	ld	ra,24(sp)
    80002872:	6442                	ld	s0,16(sp)
    80002874:	64a2                	ld	s1,8(sp)
    80002876:	6105                	addi	sp,sp,32
    80002878:	8082                	ret
      kexit(-1);
    8000287a:	557d                	li	a0,-1
    8000287c:	827ff0ef          	jal	800020a2 <kexit>
    80002880:	b7c9                	j	80002842 <usertrap+0x92>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002882:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002886:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    8000288a:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    8000288c:	00163613          	seqz	a2,a2
    80002890:	68a8                	ld	a0,80(s1)
    80002892:	ccffe0ef          	jal	80001560 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002896:	f171                	bnez	a0,8000285a <usertrap+0xaa>
    80002898:	b7ad                	j	80002802 <usertrap+0x52>
    kexit(-1);
    8000289a:	557d                	li	a0,-1
    8000289c:	807ff0ef          	jal	800020a2 <kexit>
    800028a0:	b7c9                	j	80002862 <usertrap+0xb2>

00000000800028a2 <kerneltrap>:
{
    800028a2:	7179                	addi	sp,sp,-48
    800028a4:	f406                	sd	ra,40(sp)
    800028a6:	f022                	sd	s0,32(sp)
    800028a8:	ec26                	sd	s1,24(sp)
    800028aa:	e84a                	sd	s2,16(sp)
    800028ac:	e44e                	sd	s3,8(sp)
    800028ae:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028b0:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028b4:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028b8:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800028bc:	1004f793          	andi	a5,s1,256
    800028c0:	c795                	beqz	a5,800028ec <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028c2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800028c6:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800028c8:	eb85                	bnez	a5,800028f8 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    800028ca:	e73ff0ef          	jal	8000273c <devintr>
    800028ce:	c91d                	beqz	a0,80002904 <kerneltrap+0x62>
    if (which_dev == 2 && myproc() != 0)
    800028d0:	4789                	li	a5,2
    800028d2:	04f50a63          	beq	a0,a5,80002926 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800028d6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028da:	10049073          	csrw	sstatus,s1
}
    800028de:	70a2                	ld	ra,40(sp)
    800028e0:	7402                	ld	s0,32(sp)
    800028e2:	64e2                	ld	s1,24(sp)
    800028e4:	6942                	ld	s2,16(sp)
    800028e6:	69a2                	ld	s3,8(sp)
    800028e8:	6145                	addi	sp,sp,48
    800028ea:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800028ec:	00005517          	auipc	a0,0x5
    800028f0:	af450513          	addi	a0,a0,-1292 # 800073e0 <etext+0x3e0>
    800028f4:	eedfd0ef          	jal	800007e0 <panic>
    panic("kerneltrap: interrupts enabled");
    800028f8:	00005517          	auipc	a0,0x5
    800028fc:	b1050513          	addi	a0,a0,-1264 # 80007408 <etext+0x408>
    80002900:	ee1fd0ef          	jal	800007e0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002904:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002908:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    8000290c:	85ce                	mv	a1,s3
    8000290e:	00005517          	auipc	a0,0x5
    80002912:	b1a50513          	addi	a0,a0,-1254 # 80007428 <etext+0x428>
    80002916:	be5fd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    8000291a:	00005517          	auipc	a0,0x5
    8000291e:	b3650513          	addi	a0,a0,-1226 # 80007450 <etext+0x450>
    80002922:	ebffd0ef          	jal	800007e0 <panic>
    if (which_dev == 2 && myproc() != 0)
    80002926:	80cff0ef          	jal	80001932 <myproc>
    8000292a:	d555                	beqz	a0,800028d6 <kerneltrap+0x34>
      yield();
    8000292c:	e3eff0ef          	jal	80001f6a <yield>
    80002930:	b75d                	j	800028d6 <kerneltrap+0x34>

0000000080002932 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002932:	1101                	addi	sp,sp,-32
    80002934:	ec06                	sd	ra,24(sp)
    80002936:	e822                	sd	s0,16(sp)
    80002938:	e426                	sd	s1,8(sp)
    8000293a:	1000                	addi	s0,sp,32
    8000293c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    8000293e:	ff5fe0ef          	jal	80001932 <myproc>
  switch (n) {
    80002942:	4795                	li	a5,5
    80002944:	0497e163          	bltu	a5,s1,80002986 <argraw+0x54>
    80002948:	048a                	slli	s1,s1,0x2
    8000294a:	00005717          	auipc	a4,0x5
    8000294e:	04670713          	addi	a4,a4,70 # 80007990 <states.0+0x30>
    80002952:	94ba                	add	s1,s1,a4
    80002954:	409c                	lw	a5,0(s1)
    80002956:	97ba                	add	a5,a5,a4
    80002958:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000295a:	6d3c                	ld	a5,88(a0)
    8000295c:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    8000295e:	60e2                	ld	ra,24(sp)
    80002960:	6442                	ld	s0,16(sp)
    80002962:	64a2                	ld	s1,8(sp)
    80002964:	6105                	addi	sp,sp,32
    80002966:	8082                	ret
    return p->trapframe->a1;
    80002968:	6d3c                	ld	a5,88(a0)
    8000296a:	7fa8                	ld	a0,120(a5)
    8000296c:	bfcd                	j	8000295e <argraw+0x2c>
    return p->trapframe->a2;
    8000296e:	6d3c                	ld	a5,88(a0)
    80002970:	63c8                	ld	a0,128(a5)
    80002972:	b7f5                	j	8000295e <argraw+0x2c>
    return p->trapframe->a3;
    80002974:	6d3c                	ld	a5,88(a0)
    80002976:	67c8                	ld	a0,136(a5)
    80002978:	b7dd                	j	8000295e <argraw+0x2c>
    return p->trapframe->a4;
    8000297a:	6d3c                	ld	a5,88(a0)
    8000297c:	6bc8                	ld	a0,144(a5)
    8000297e:	b7c5                	j	8000295e <argraw+0x2c>
    return p->trapframe->a5;
    80002980:	6d3c                	ld	a5,88(a0)
    80002982:	6fc8                	ld	a0,152(a5)
    80002984:	bfe9                	j	8000295e <argraw+0x2c>
  panic("argraw");
    80002986:	00005517          	auipc	a0,0x5
    8000298a:	ada50513          	addi	a0,a0,-1318 # 80007460 <etext+0x460>
    8000298e:	e53fd0ef          	jal	800007e0 <panic>

0000000080002992 <fetchaddr>:
{
    80002992:	1101                	addi	sp,sp,-32
    80002994:	ec06                	sd	ra,24(sp)
    80002996:	e822                	sd	s0,16(sp)
    80002998:	e426                	sd	s1,8(sp)
    8000299a:	e04a                	sd	s2,0(sp)
    8000299c:	1000                	addi	s0,sp,32
    8000299e:	84aa                	mv	s1,a0
    800029a0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800029a2:	f91fe0ef          	jal	80001932 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800029a6:	653c                	ld	a5,72(a0)
    800029a8:	02f4f663          	bgeu	s1,a5,800029d4 <fetchaddr+0x42>
    800029ac:	00848713          	addi	a4,s1,8
    800029b0:	02e7e463          	bltu	a5,a4,800029d8 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    800029b4:	46a1                	li	a3,8
    800029b6:	8626                	mv	a2,s1
    800029b8:	85ca                	mv	a1,s2
    800029ba:	6928                	ld	a0,80(a0)
    800029bc:	d0bfe0ef          	jal	800016c6 <copyin>
    800029c0:	00a03533          	snez	a0,a0
    800029c4:	40a00533          	neg	a0,a0
}
    800029c8:	60e2                	ld	ra,24(sp)
    800029ca:	6442                	ld	s0,16(sp)
    800029cc:	64a2                	ld	s1,8(sp)
    800029ce:	6902                	ld	s2,0(sp)
    800029d0:	6105                	addi	sp,sp,32
    800029d2:	8082                	ret
    return -1;
    800029d4:	557d                	li	a0,-1
    800029d6:	bfcd                	j	800029c8 <fetchaddr+0x36>
    800029d8:	557d                	li	a0,-1
    800029da:	b7fd                	j	800029c8 <fetchaddr+0x36>

00000000800029dc <fetchstr>:
{
    800029dc:	7179                	addi	sp,sp,-48
    800029de:	f406                	sd	ra,40(sp)
    800029e0:	f022                	sd	s0,32(sp)
    800029e2:	ec26                	sd	s1,24(sp)
    800029e4:	e84a                	sd	s2,16(sp)
    800029e6:	e44e                	sd	s3,8(sp)
    800029e8:	1800                	addi	s0,sp,48
    800029ea:	892a                	mv	s2,a0
    800029ec:	84ae                	mv	s1,a1
    800029ee:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800029f0:	f43fe0ef          	jal	80001932 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800029f4:	86ce                	mv	a3,s3
    800029f6:	864a                	mv	a2,s2
    800029f8:	85a6                	mv	a1,s1
    800029fa:	6928                	ld	a0,80(a0)
    800029fc:	a8dfe0ef          	jal	80001488 <copyinstr>
    80002a00:	00054c63          	bltz	a0,80002a18 <fetchstr+0x3c>
  return strlen(buf);
    80002a04:	8526                	mv	a0,s1
    80002a06:	c0cfe0ef          	jal	80000e12 <strlen>
}
    80002a0a:	70a2                	ld	ra,40(sp)
    80002a0c:	7402                	ld	s0,32(sp)
    80002a0e:	64e2                	ld	s1,24(sp)
    80002a10:	6942                	ld	s2,16(sp)
    80002a12:	69a2                	ld	s3,8(sp)
    80002a14:	6145                	addi	sp,sp,48
    80002a16:	8082                	ret
    return -1;
    80002a18:	557d                	li	a0,-1
    80002a1a:	bfc5                	j	80002a0a <fetchstr+0x2e>

0000000080002a1c <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002a1c:	1101                	addi	sp,sp,-32
    80002a1e:	ec06                	sd	ra,24(sp)
    80002a20:	e822                	sd	s0,16(sp)
    80002a22:	e426                	sd	s1,8(sp)
    80002a24:	1000                	addi	s0,sp,32
    80002a26:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a28:	f0bff0ef          	jal	80002932 <argraw>
    80002a2c:	c088                	sw	a0,0(s1)
}
    80002a2e:	60e2                	ld	ra,24(sp)
    80002a30:	6442                	ld	s0,16(sp)
    80002a32:	64a2                	ld	s1,8(sp)
    80002a34:	6105                	addi	sp,sp,32
    80002a36:	8082                	ret

0000000080002a38 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002a38:	1101                	addi	sp,sp,-32
    80002a3a:	ec06                	sd	ra,24(sp)
    80002a3c:	e822                	sd	s0,16(sp)
    80002a3e:	e426                	sd	s1,8(sp)
    80002a40:	1000                	addi	s0,sp,32
    80002a42:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a44:	eefff0ef          	jal	80002932 <argraw>
    80002a48:	e088                	sd	a0,0(s1)
}
    80002a4a:	60e2                	ld	ra,24(sp)
    80002a4c:	6442                	ld	s0,16(sp)
    80002a4e:	64a2                	ld	s1,8(sp)
    80002a50:	6105                	addi	sp,sp,32
    80002a52:	8082                	ret

0000000080002a54 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002a54:	7179                	addi	sp,sp,-48
    80002a56:	f406                	sd	ra,40(sp)
    80002a58:	f022                	sd	s0,32(sp)
    80002a5a:	ec26                	sd	s1,24(sp)
    80002a5c:	e84a                	sd	s2,16(sp)
    80002a5e:	1800                	addi	s0,sp,48
    80002a60:	84ae                	mv	s1,a1
    80002a62:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002a64:	fd840593          	addi	a1,s0,-40
    80002a68:	fd1ff0ef          	jal	80002a38 <argaddr>
  return fetchstr(addr, buf, max);
    80002a6c:	864a                	mv	a2,s2
    80002a6e:	85a6                	mv	a1,s1
    80002a70:	fd843503          	ld	a0,-40(s0)
    80002a74:	f69ff0ef          	jal	800029dc <fetchstr>
}
    80002a78:	70a2                	ld	ra,40(sp)
    80002a7a:	7402                	ld	s0,32(sp)
    80002a7c:	64e2                	ld	s1,24(sp)
    80002a7e:	6942                	ld	s2,16(sp)
    80002a80:	6145                	addi	sp,sp,48
    80002a82:	8082                	ret

0000000080002a84 <syscall>:
[SYS_wait] sys_wait,
};

void
syscall(void)
{
    80002a84:	1101                	addi	sp,sp,-32
    80002a86:	ec06                	sd	ra,24(sp)
    80002a88:	e822                	sd	s0,16(sp)
    80002a8a:	e426                	sd	s1,8(sp)
    80002a8c:	e04a                	sd	s2,0(sp)
    80002a8e:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002a90:	ea3fe0ef          	jal	80001932 <myproc>
    80002a94:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002a96:	05853903          	ld	s2,88(a0)
    80002a9a:	0a893783          	ld	a5,168(s2)
    80002a9e:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002aa2:	37fd                	addiw	a5,a5,-1
    80002aa4:	475d                	li	a4,23
    80002aa6:	00f76f63          	bltu	a4,a5,80002ac4 <syscall+0x40>
    80002aaa:	00369713          	slli	a4,a3,0x3
    80002aae:	00005797          	auipc	a5,0x5
    80002ab2:	efa78793          	addi	a5,a5,-262 # 800079a8 <syscalls>
    80002ab6:	97ba                	add	a5,a5,a4
    80002ab8:	639c                	ld	a5,0(a5)
    80002aba:	c789                	beqz	a5,80002ac4 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002abc:	9782                	jalr	a5
    80002abe:	06a93823          	sd	a0,112(s2)
    80002ac2:	a829                	j	80002adc <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002ac4:	15848613          	addi	a2,s1,344
    80002ac8:	588c                	lw	a1,48(s1)
    80002aca:	00005517          	auipc	a0,0x5
    80002ace:	99e50513          	addi	a0,a0,-1634 # 80007468 <etext+0x468>
    80002ad2:	a29fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002ad6:	6cbc                	ld	a5,88(s1)
    80002ad8:	577d                	li	a4,-1
    80002ada:	fbb8                	sd	a4,112(a5)
  }
}
    80002adc:	60e2                	ld	ra,24(sp)
    80002ade:	6442                	ld	s0,16(sp)
    80002ae0:	64a2                	ld	s1,8(sp)
    80002ae2:	6902                	ld	s2,0(sp)
    80002ae4:	6105                	addi	sp,sp,32
    80002ae6:	8082                	ret

0000000080002ae8 <sys_waitx>:

extern struct proc proc[NPROC];

uint64
sys_waitx(void)
{
    80002ae8:	7179                	addi	sp,sp,-48
    80002aea:	f406                	sd	ra,40(sp)
    80002aec:	f022                	sd	s0,32(sp)
    80002aee:	1800                	addi	s0,sp,48
  uint64 up_w, up_r, up_t;
  argaddr(0, &up_w);
    80002af0:	fe840593          	addi	a1,s0,-24
    80002af4:	4501                	li	a0,0
    80002af6:	f43ff0ef          	jal	80002a38 <argaddr>
  argaddr(1, &up_r);
    80002afa:	fe040593          	addi	a1,s0,-32
    80002afe:	4505                	li	a0,1
    80002b00:	f39ff0ef          	jal	80002a38 <argaddr>
  argaddr(2, &up_t);
    80002b04:	fd840593          	addi	a1,s0,-40
    80002b08:	4509                	li	a0,2
    80002b0a:	f2fff0ef          	jal	80002a38 <argaddr>
  return waitx(up_w, up_r, up_t);
    80002b0e:	fd843603          	ld	a2,-40(s0)
    80002b12:	fe043583          	ld	a1,-32(s0)
    80002b16:	fe843503          	ld	a0,-24(s0)
    80002b1a:	ef6ff0ef          	jal	80002210 <waitx>
}
    80002b1e:	70a2                	ld	ra,40(sp)
    80002b20:	7402                	ld	s0,32(sp)
    80002b22:	6145                	addi	sp,sp,48
    80002b24:	8082                	ret

0000000080002b26 <sys_getprocesstimes>:

uint64
sys_getprocesstimes(void)
{
    80002b26:	715d                	addi	sp,sp,-80
    80002b28:	e486                	sd	ra,72(sp)
    80002b2a:	e0a2                	sd	s0,64(sp)
    80002b2c:	fc26                	sd	s1,56(sp)
    80002b2e:	f84a                	sd	s2,48(sp)
    80002b30:	0880                	addi	s0,sp,80
  int pid;
  uint64 user_addr;
  struct proc *p;

  argint(0, &pid);
    80002b32:	fdc40593          	addi	a1,s0,-36
    80002b36:	4501                	li	a0,0
    80002b38:	ee5ff0ef          	jal	80002a1c <argint>
  argaddr(1, &user_addr);
    80002b3c:	fd040593          	addi	a1,s0,-48
    80002b40:	4505                	li	a0,1
    80002b42:	ef7ff0ef          	jal	80002a38 <argaddr>

  for(p = proc; p < &proc[NPROC]; p++){
    80002b46:	0000d497          	auipc	s1,0xd
    80002b4a:	4b248493          	addi	s1,s1,1202 # 8000fff8 <proc>
    80002b4e:	00013917          	auipc	s2,0x13
    80002b52:	2aa90913          	addi	s2,s2,682 # 80015df8 <tickslock>
    acquire(&p->lock);
    80002b56:	8526                	mv	a0,s1
    80002b58:	876fe0ef          	jal	80000bce <acquire>
    if(p->pid == pid){
    80002b5c:	5898                	lw	a4,48(s1)
    80002b5e:	fdc42783          	lw	a5,-36(s0)
    80002b62:	00f70b63          	beq	a4,a5,80002b78 <sys_getprocesstimes+0x52>

      if(copyout(myproc()->pagetable, user_addr, (char*)&t, sizeof(t)) < 0)
        return -1;
      return 0;
    }
    release(&p->lock);
    80002b66:	8526                	mv	a0,s1
    80002b68:	8fefe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002b6c:	17848493          	addi	s1,s1,376
    80002b70:	ff2493e3          	bne	s1,s2,80002b56 <sys_getprocesstimes+0x30>
  }
  return -1;
    80002b74:	557d                	li	a0,-1
    80002b76:	a81d                	j	80002bac <sys_getprocesstimes+0x86>
      t.creation_time = p->creation_time;
    80002b78:	1684e783          	lwu	a5,360(s1)
    80002b7c:	faf43c23          	sd	a5,-72(s0)
      t.start_time    = p->start_time;
    80002b80:	16c4e783          	lwu	a5,364(s1)
    80002b84:	fcf43023          	sd	a5,-64(s0)
      t.end_time      = p->end_time;
    80002b88:	1704e783          	lwu	a5,368(s1)
    80002b8c:	fcf43423          	sd	a5,-56(s0)
      release(&p->lock);
    80002b90:	8526                	mv	a0,s1
    80002b92:	8d4fe0ef          	jal	80000c66 <release>
      if(copyout(myproc()->pagetable, user_addr, (char*)&t, sizeof(t)) < 0)
    80002b96:	d9dfe0ef          	jal	80001932 <myproc>
    80002b9a:	46e1                	li	a3,24
    80002b9c:	fb840613          	addi	a2,s0,-72
    80002ba0:	fd043583          	ld	a1,-48(s0)
    80002ba4:	6928                	ld	a0,80(a0)
    80002ba6:	a3dfe0ef          	jal	800015e2 <copyout>
    80002baa:	957d                	srai	a0,a0,0x3f
}
    80002bac:	60a6                	ld	ra,72(sp)
    80002bae:	6406                	ld	s0,64(sp)
    80002bb0:	74e2                	ld	s1,56(sp)
    80002bb2:	7942                	ld	s2,48(sp)
    80002bb4:	6161                	addi	sp,sp,80
    80002bb6:	8082                	ret

0000000080002bb8 <sys_getreadcount>:

uint64
sys_getreadcount(void)
{
    80002bb8:	1141                	addi	sp,sp,-16
    80002bba:	e422                	sd	s0,8(sp)
    80002bbc:	0800                	addi	s0,sp,16
  return global_read_bytes;
}
    80002bbe:	00005517          	auipc	a0,0x5
    80002bc2:	f0253503          	ld	a0,-254(a0) # 80007ac0 <global_read_bytes>
    80002bc6:	6422                	ld	s0,8(sp)
    80002bc8:	0141                	addi	sp,sp,16
    80002bca:	8082                	ret

0000000080002bcc <sys_exit>:

uint64
sys_exit(void)
{
    80002bcc:	1101                	addi	sp,sp,-32
    80002bce:	ec06                	sd	ra,24(sp)
    80002bd0:	e822                	sd	s0,16(sp)
    80002bd2:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002bd4:	fec40593          	addi	a1,s0,-20
    80002bd8:	4501                	li	a0,0
    80002bda:	e43ff0ef          	jal	80002a1c <argint>
  kexit(n);
    80002bde:	fec42503          	lw	a0,-20(s0)
    80002be2:	cc0ff0ef          	jal	800020a2 <kexit>
  return 0;  // not reached
}
    80002be6:	4501                	li	a0,0
    80002be8:	60e2                	ld	ra,24(sp)
    80002bea:	6442                	ld	s0,16(sp)
    80002bec:	6105                	addi	sp,sp,32
    80002bee:	8082                	ret

0000000080002bf0 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002bf0:	1141                	addi	sp,sp,-16
    80002bf2:	e406                	sd	ra,8(sp)
    80002bf4:	e022                	sd	s0,0(sp)
    80002bf6:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002bf8:	d3bfe0ef          	jal	80001932 <myproc>
}
    80002bfc:	5908                	lw	a0,48(a0)
    80002bfe:	60a2                	ld	ra,8(sp)
    80002c00:	6402                	ld	s0,0(sp)
    80002c02:	0141                	addi	sp,sp,16
    80002c04:	8082                	ret

0000000080002c06 <sys_fork>:

uint64
sys_fork(void)
{
    80002c06:	1141                	addi	sp,sp,-16
    80002c08:	e406                	sd	ra,8(sp)
    80002c0a:	e022                	sd	s0,0(sp)
    80002c0c:	0800                	addi	s0,sp,16
  return kfork();
    80002c0e:	88aff0ef          	jal	80001c98 <kfork>
}
    80002c12:	60a2                	ld	ra,8(sp)
    80002c14:	6402                	ld	s0,0(sp)
    80002c16:	0141                	addi	sp,sp,16
    80002c18:	8082                	ret

0000000080002c1a <sys_wait>:

uint64
sys_wait(void)
{
    80002c1a:	1101                	addi	sp,sp,-32
    80002c1c:	ec06                	sd	ra,24(sp)
    80002c1e:	e822                	sd	s0,16(sp)
    80002c20:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002c22:	fe840593          	addi	a1,s0,-24
    80002c26:	4501                	li	a0,0
    80002c28:	e11ff0ef          	jal	80002a38 <argaddr>
  return kwait(p);
    80002c2c:	fe843503          	ld	a0,-24(s0)
    80002c30:	f64ff0ef          	jal	80002394 <kwait>
}
    80002c34:	60e2                	ld	ra,24(sp)
    80002c36:	6442                	ld	s0,16(sp)
    80002c38:	6105                	addi	sp,sp,32
    80002c3a:	8082                	ret

0000000080002c3c <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002c3c:	7179                	addi	sp,sp,-48
    80002c3e:	f406                	sd	ra,40(sp)
    80002c40:	f022                	sd	s0,32(sp)
    80002c42:	ec26                	sd	s1,24(sp)
    80002c44:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002c46:	fd840593          	addi	a1,s0,-40
    80002c4a:	4501                	li	a0,0
    80002c4c:	dd1ff0ef          	jal	80002a1c <argint>
  argint(1, &t);
    80002c50:	fdc40593          	addi	a1,s0,-36
    80002c54:	4505                	li	a0,1
    80002c56:	dc7ff0ef          	jal	80002a1c <argint>
  addr = myproc()->sz;
    80002c5a:	cd9fe0ef          	jal	80001932 <myproc>
    80002c5e:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002c60:	fdc42703          	lw	a4,-36(s0)
    80002c64:	4785                	li	a5,1
    80002c66:	02f70163          	beq	a4,a5,80002c88 <sys_sbrk+0x4c>
    80002c6a:	fd842783          	lw	a5,-40(s0)
    80002c6e:	0007cd63          	bltz	a5,80002c88 <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002c72:	97a6                	add	a5,a5,s1
    80002c74:	0297e863          	bltu	a5,s1,80002ca4 <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002c78:	cbbfe0ef          	jal	80001932 <myproc>
    80002c7c:	fd842703          	lw	a4,-40(s0)
    80002c80:	653c                	ld	a5,72(a0)
    80002c82:	97ba                	add	a5,a5,a4
    80002c84:	e53c                	sd	a5,72(a0)
    80002c86:	a039                	j	80002c94 <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002c88:	fd842503          	lw	a0,-40(s0)
    80002c8c:	fbdfe0ef          	jal	80001c48 <growproc>
    80002c90:	00054863          	bltz	a0,80002ca0 <sys_sbrk+0x64>
  }
  return addr;
}
    80002c94:	8526                	mv	a0,s1
    80002c96:	70a2                	ld	ra,40(sp)
    80002c98:	7402                	ld	s0,32(sp)
    80002c9a:	64e2                	ld	s1,24(sp)
    80002c9c:	6145                	addi	sp,sp,48
    80002c9e:	8082                	ret
      return -1;
    80002ca0:	54fd                	li	s1,-1
    80002ca2:	bfcd                	j	80002c94 <sys_sbrk+0x58>
      return -1;
    80002ca4:	54fd                	li	s1,-1
    80002ca6:	b7fd                	j	80002c94 <sys_sbrk+0x58>

0000000080002ca8 <sys_pause>:

uint64
sys_pause(void)
{
    80002ca8:	7139                	addi	sp,sp,-64
    80002caa:	fc06                	sd	ra,56(sp)
    80002cac:	f822                	sd	s0,48(sp)
    80002cae:	f04a                	sd	s2,32(sp)
    80002cb0:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002cb2:	fcc40593          	addi	a1,s0,-52
    80002cb6:	4501                	li	a0,0
    80002cb8:	d65ff0ef          	jal	80002a1c <argint>
  if(n < 0)
    80002cbc:	fcc42783          	lw	a5,-52(s0)
    80002cc0:	0607c763          	bltz	a5,80002d2e <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002cc4:	00013517          	auipc	a0,0x13
    80002cc8:	13450513          	addi	a0,a0,308 # 80015df8 <tickslock>
    80002ccc:	f03fd0ef          	jal	80000bce <acquire>
  ticks0 = ticks;
    80002cd0:	00005917          	auipc	s2,0x5
    80002cd4:	de892903          	lw	s2,-536(s2) # 80007ab8 <ticks>
  while(ticks - ticks0 < n){
    80002cd8:	fcc42783          	lw	a5,-52(s0)
    80002cdc:	cf8d                	beqz	a5,80002d16 <sys_pause+0x6e>
    80002cde:	f426                	sd	s1,40(sp)
    80002ce0:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002ce2:	00013997          	auipc	s3,0x13
    80002ce6:	11698993          	addi	s3,s3,278 # 80015df8 <tickslock>
    80002cea:	00005497          	auipc	s1,0x5
    80002cee:	dce48493          	addi	s1,s1,-562 # 80007ab8 <ticks>
    if(killed(myproc())){
    80002cf2:	c41fe0ef          	jal	80001932 <myproc>
    80002cf6:	cf0ff0ef          	jal	800021e6 <killed>
    80002cfa:	ed0d                	bnez	a0,80002d34 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002cfc:	85ce                	mv	a1,s3
    80002cfe:	8526                	mv	a0,s1
    80002d00:	a96ff0ef          	jal	80001f96 <sleep>
  while(ticks - ticks0 < n){
    80002d04:	409c                	lw	a5,0(s1)
    80002d06:	412787bb          	subw	a5,a5,s2
    80002d0a:	fcc42703          	lw	a4,-52(s0)
    80002d0e:	fee7e2e3          	bltu	a5,a4,80002cf2 <sys_pause+0x4a>
    80002d12:	74a2                	ld	s1,40(sp)
    80002d14:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002d16:	00013517          	auipc	a0,0x13
    80002d1a:	0e250513          	addi	a0,a0,226 # 80015df8 <tickslock>
    80002d1e:	f49fd0ef          	jal	80000c66 <release>
  return 0;
    80002d22:	4501                	li	a0,0
}
    80002d24:	70e2                	ld	ra,56(sp)
    80002d26:	7442                	ld	s0,48(sp)
    80002d28:	7902                	ld	s2,32(sp)
    80002d2a:	6121                	addi	sp,sp,64
    80002d2c:	8082                	ret
    n = 0;
    80002d2e:	fc042623          	sw	zero,-52(s0)
    80002d32:	bf49                	j	80002cc4 <sys_pause+0x1c>
      release(&tickslock);
    80002d34:	00013517          	auipc	a0,0x13
    80002d38:	0c450513          	addi	a0,a0,196 # 80015df8 <tickslock>
    80002d3c:	f2bfd0ef          	jal	80000c66 <release>
      return -1;
    80002d40:	557d                	li	a0,-1
    80002d42:	74a2                	ld	s1,40(sp)
    80002d44:	69e2                	ld	s3,24(sp)
    80002d46:	bff9                	j	80002d24 <sys_pause+0x7c>

0000000080002d48 <sys_kill>:

uint64
sys_kill(void)
{
    80002d48:	1101                	addi	sp,sp,-32
    80002d4a:	ec06                	sd	ra,24(sp)
    80002d4c:	e822                	sd	s0,16(sp)
    80002d4e:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002d50:	fec40593          	addi	a1,s0,-20
    80002d54:	4501                	li	a0,0
    80002d56:	cc7ff0ef          	jal	80002a1c <argint>
  return kkill(pid);
    80002d5a:	fec42503          	lw	a0,-20(s0)
    80002d5e:	bfeff0ef          	jal	8000215c <kkill>
}
    80002d62:	60e2                	ld	ra,24(sp)
    80002d64:	6442                	ld	s0,16(sp)
    80002d66:	6105                	addi	sp,sp,32
    80002d68:	8082                	ret

0000000080002d6a <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002d6a:	1101                	addi	sp,sp,-32
    80002d6c:	ec06                	sd	ra,24(sp)
    80002d6e:	e822                	sd	s0,16(sp)
    80002d70:	e426                	sd	s1,8(sp)
    80002d72:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002d74:	00013517          	auipc	a0,0x13
    80002d78:	08450513          	addi	a0,a0,132 # 80015df8 <tickslock>
    80002d7c:	e53fd0ef          	jal	80000bce <acquire>
  xticks = ticks;
    80002d80:	00005497          	auipc	s1,0x5
    80002d84:	d384a483          	lw	s1,-712(s1) # 80007ab8 <ticks>
  release(&tickslock);
    80002d88:	00013517          	auipc	a0,0x13
    80002d8c:	07050513          	addi	a0,a0,112 # 80015df8 <tickslock>
    80002d90:	ed7fd0ef          	jal	80000c66 <release>
  return xticks;
}
    80002d94:	02049513          	slli	a0,s1,0x20
    80002d98:	9101                	srli	a0,a0,0x20
    80002d9a:	60e2                	ld	ra,24(sp)
    80002d9c:	6442                	ld	s0,16(sp)
    80002d9e:	64a2                	ld	s1,8(sp)
    80002da0:	6105                	addi	sp,sp,32
    80002da2:	8082                	ret

0000000080002da4 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002da4:	7179                	addi	sp,sp,-48
    80002da6:	f406                	sd	ra,40(sp)
    80002da8:	f022                	sd	s0,32(sp)
    80002daa:	ec26                	sd	s1,24(sp)
    80002dac:	e84a                	sd	s2,16(sp)
    80002dae:	e44e                	sd	s3,8(sp)
    80002db0:	e052                	sd	s4,0(sp)
    80002db2:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002db4:	00004597          	auipc	a1,0x4
    80002db8:	6d458593          	addi	a1,a1,1748 # 80007488 <etext+0x488>
    80002dbc:	00013517          	auipc	a0,0x13
    80002dc0:	05450513          	addi	a0,a0,84 # 80015e10 <bcache>
    80002dc4:	d8bfd0ef          	jal	80000b4e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002dc8:	0001b797          	auipc	a5,0x1b
    80002dcc:	04878793          	addi	a5,a5,72 # 8001de10 <bcache+0x8000>
    80002dd0:	0001b717          	auipc	a4,0x1b
    80002dd4:	2a870713          	addi	a4,a4,680 # 8001e078 <bcache+0x8268>
    80002dd8:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002ddc:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002de0:	00013497          	auipc	s1,0x13
    80002de4:	04848493          	addi	s1,s1,72 # 80015e28 <bcache+0x18>
    b->next = bcache.head.next;
    80002de8:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002dea:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002dec:	00004a17          	auipc	s4,0x4
    80002df0:	6a4a0a13          	addi	s4,s4,1700 # 80007490 <etext+0x490>
    b->next = bcache.head.next;
    80002df4:	2b893783          	ld	a5,696(s2)
    80002df8:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002dfa:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002dfe:	85d2                	mv	a1,s4
    80002e00:	01048513          	addi	a0,s1,16
    80002e04:	322010ef          	jal	80004126 <initsleeplock>
    bcache.head.next->prev = b;
    80002e08:	2b893783          	ld	a5,696(s2)
    80002e0c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002e0e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002e12:	45848493          	addi	s1,s1,1112
    80002e16:	fd349fe3          	bne	s1,s3,80002df4 <binit+0x50>
  }
}
    80002e1a:	70a2                	ld	ra,40(sp)
    80002e1c:	7402                	ld	s0,32(sp)
    80002e1e:	64e2                	ld	s1,24(sp)
    80002e20:	6942                	ld	s2,16(sp)
    80002e22:	69a2                	ld	s3,8(sp)
    80002e24:	6a02                	ld	s4,0(sp)
    80002e26:	6145                	addi	sp,sp,48
    80002e28:	8082                	ret

0000000080002e2a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002e2a:	7179                	addi	sp,sp,-48
    80002e2c:	f406                	sd	ra,40(sp)
    80002e2e:	f022                	sd	s0,32(sp)
    80002e30:	ec26                	sd	s1,24(sp)
    80002e32:	e84a                	sd	s2,16(sp)
    80002e34:	e44e                	sd	s3,8(sp)
    80002e36:	1800                	addi	s0,sp,48
    80002e38:	892a                	mv	s2,a0
    80002e3a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002e3c:	00013517          	auipc	a0,0x13
    80002e40:	fd450513          	addi	a0,a0,-44 # 80015e10 <bcache>
    80002e44:	d8bfd0ef          	jal	80000bce <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002e48:	0001b497          	auipc	s1,0x1b
    80002e4c:	2804b483          	ld	s1,640(s1) # 8001e0c8 <bcache+0x82b8>
    80002e50:	0001b797          	auipc	a5,0x1b
    80002e54:	22878793          	addi	a5,a5,552 # 8001e078 <bcache+0x8268>
    80002e58:	02f48b63          	beq	s1,a5,80002e8e <bread+0x64>
    80002e5c:	873e                	mv	a4,a5
    80002e5e:	a021                	j	80002e66 <bread+0x3c>
    80002e60:	68a4                	ld	s1,80(s1)
    80002e62:	02e48663          	beq	s1,a4,80002e8e <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002e66:	449c                	lw	a5,8(s1)
    80002e68:	ff279ce3          	bne	a5,s2,80002e60 <bread+0x36>
    80002e6c:	44dc                	lw	a5,12(s1)
    80002e6e:	ff3799e3          	bne	a5,s3,80002e60 <bread+0x36>
      b->refcnt++;
    80002e72:	40bc                	lw	a5,64(s1)
    80002e74:	2785                	addiw	a5,a5,1
    80002e76:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e78:	00013517          	auipc	a0,0x13
    80002e7c:	f9850513          	addi	a0,a0,-104 # 80015e10 <bcache>
    80002e80:	de7fd0ef          	jal	80000c66 <release>
      acquiresleep(&b->lock);
    80002e84:	01048513          	addi	a0,s1,16
    80002e88:	2d4010ef          	jal	8000415c <acquiresleep>
      return b;
    80002e8c:	a889                	j	80002ede <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002e8e:	0001b497          	auipc	s1,0x1b
    80002e92:	2324b483          	ld	s1,562(s1) # 8001e0c0 <bcache+0x82b0>
    80002e96:	0001b797          	auipc	a5,0x1b
    80002e9a:	1e278793          	addi	a5,a5,482 # 8001e078 <bcache+0x8268>
    80002e9e:	00f48863          	beq	s1,a5,80002eae <bread+0x84>
    80002ea2:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002ea4:	40bc                	lw	a5,64(s1)
    80002ea6:	cb91                	beqz	a5,80002eba <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002ea8:	64a4                	ld	s1,72(s1)
    80002eaa:	fee49de3          	bne	s1,a4,80002ea4 <bread+0x7a>
  panic("bget: no buffers");
    80002eae:	00004517          	auipc	a0,0x4
    80002eb2:	5ea50513          	addi	a0,a0,1514 # 80007498 <etext+0x498>
    80002eb6:	92bfd0ef          	jal	800007e0 <panic>
      b->dev = dev;
    80002eba:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002ebe:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002ec2:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002ec6:	4785                	li	a5,1
    80002ec8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002eca:	00013517          	auipc	a0,0x13
    80002ece:	f4650513          	addi	a0,a0,-186 # 80015e10 <bcache>
    80002ed2:	d95fd0ef          	jal	80000c66 <release>
      acquiresleep(&b->lock);
    80002ed6:	01048513          	addi	a0,s1,16
    80002eda:	282010ef          	jal	8000415c <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002ede:	409c                	lw	a5,0(s1)
    80002ee0:	cb89                	beqz	a5,80002ef2 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ee2:	8526                	mv	a0,s1
    80002ee4:	70a2                	ld	ra,40(sp)
    80002ee6:	7402                	ld	s0,32(sp)
    80002ee8:	64e2                	ld	s1,24(sp)
    80002eea:	6942                	ld	s2,16(sp)
    80002eec:	69a2                	ld	s3,8(sp)
    80002eee:	6145                	addi	sp,sp,48
    80002ef0:	8082                	ret
    virtio_disk_rw(b, 0);
    80002ef2:	4581                	li	a1,0
    80002ef4:	8526                	mv	a0,s1
    80002ef6:	2db020ef          	jal	800059d0 <virtio_disk_rw>
    b->valid = 1;
    80002efa:	4785                	li	a5,1
    80002efc:	c09c                	sw	a5,0(s1)
  return b;
    80002efe:	b7d5                	j	80002ee2 <bread+0xb8>

0000000080002f00 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002f00:	1101                	addi	sp,sp,-32
    80002f02:	ec06                	sd	ra,24(sp)
    80002f04:	e822                	sd	s0,16(sp)
    80002f06:	e426                	sd	s1,8(sp)
    80002f08:	1000                	addi	s0,sp,32
    80002f0a:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002f0c:	0541                	addi	a0,a0,16
    80002f0e:	2cc010ef          	jal	800041da <holdingsleep>
    80002f12:	c911                	beqz	a0,80002f26 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002f14:	4585                	li	a1,1
    80002f16:	8526                	mv	a0,s1
    80002f18:	2b9020ef          	jal	800059d0 <virtio_disk_rw>
}
    80002f1c:	60e2                	ld	ra,24(sp)
    80002f1e:	6442                	ld	s0,16(sp)
    80002f20:	64a2                	ld	s1,8(sp)
    80002f22:	6105                	addi	sp,sp,32
    80002f24:	8082                	ret
    panic("bwrite");
    80002f26:	00004517          	auipc	a0,0x4
    80002f2a:	58a50513          	addi	a0,a0,1418 # 800074b0 <etext+0x4b0>
    80002f2e:	8b3fd0ef          	jal	800007e0 <panic>

0000000080002f32 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002f32:	1101                	addi	sp,sp,-32
    80002f34:	ec06                	sd	ra,24(sp)
    80002f36:	e822                	sd	s0,16(sp)
    80002f38:	e426                	sd	s1,8(sp)
    80002f3a:	e04a                	sd	s2,0(sp)
    80002f3c:	1000                	addi	s0,sp,32
    80002f3e:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002f40:	01050913          	addi	s2,a0,16
    80002f44:	854a                	mv	a0,s2
    80002f46:	294010ef          	jal	800041da <holdingsleep>
    80002f4a:	c135                	beqz	a0,80002fae <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002f4c:	854a                	mv	a0,s2
    80002f4e:	254010ef          	jal	800041a2 <releasesleep>

  acquire(&bcache.lock);
    80002f52:	00013517          	auipc	a0,0x13
    80002f56:	ebe50513          	addi	a0,a0,-322 # 80015e10 <bcache>
    80002f5a:	c75fd0ef          	jal	80000bce <acquire>
  b->refcnt--;
    80002f5e:	40bc                	lw	a5,64(s1)
    80002f60:	37fd                	addiw	a5,a5,-1
    80002f62:	0007871b          	sext.w	a4,a5
    80002f66:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002f68:	e71d                	bnez	a4,80002f96 <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002f6a:	68b8                	ld	a4,80(s1)
    80002f6c:	64bc                	ld	a5,72(s1)
    80002f6e:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002f70:	68b8                	ld	a4,80(s1)
    80002f72:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002f74:	0001b797          	auipc	a5,0x1b
    80002f78:	e9c78793          	addi	a5,a5,-356 # 8001de10 <bcache+0x8000>
    80002f7c:	2b87b703          	ld	a4,696(a5)
    80002f80:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002f82:	0001b717          	auipc	a4,0x1b
    80002f86:	0f670713          	addi	a4,a4,246 # 8001e078 <bcache+0x8268>
    80002f8a:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002f8c:	2b87b703          	ld	a4,696(a5)
    80002f90:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002f92:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002f96:	00013517          	auipc	a0,0x13
    80002f9a:	e7a50513          	addi	a0,a0,-390 # 80015e10 <bcache>
    80002f9e:	cc9fd0ef          	jal	80000c66 <release>
}
    80002fa2:	60e2                	ld	ra,24(sp)
    80002fa4:	6442                	ld	s0,16(sp)
    80002fa6:	64a2                	ld	s1,8(sp)
    80002fa8:	6902                	ld	s2,0(sp)
    80002faa:	6105                	addi	sp,sp,32
    80002fac:	8082                	ret
    panic("brelse");
    80002fae:	00004517          	auipc	a0,0x4
    80002fb2:	50a50513          	addi	a0,a0,1290 # 800074b8 <etext+0x4b8>
    80002fb6:	82bfd0ef          	jal	800007e0 <panic>

0000000080002fba <bpin>:

void
bpin(struct buf *b) {
    80002fba:	1101                	addi	sp,sp,-32
    80002fbc:	ec06                	sd	ra,24(sp)
    80002fbe:	e822                	sd	s0,16(sp)
    80002fc0:	e426                	sd	s1,8(sp)
    80002fc2:	1000                	addi	s0,sp,32
    80002fc4:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002fc6:	00013517          	auipc	a0,0x13
    80002fca:	e4a50513          	addi	a0,a0,-438 # 80015e10 <bcache>
    80002fce:	c01fd0ef          	jal	80000bce <acquire>
  b->refcnt++;
    80002fd2:	40bc                	lw	a5,64(s1)
    80002fd4:	2785                	addiw	a5,a5,1
    80002fd6:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002fd8:	00013517          	auipc	a0,0x13
    80002fdc:	e3850513          	addi	a0,a0,-456 # 80015e10 <bcache>
    80002fe0:	c87fd0ef          	jal	80000c66 <release>
}
    80002fe4:	60e2                	ld	ra,24(sp)
    80002fe6:	6442                	ld	s0,16(sp)
    80002fe8:	64a2                	ld	s1,8(sp)
    80002fea:	6105                	addi	sp,sp,32
    80002fec:	8082                	ret

0000000080002fee <bunpin>:

void
bunpin(struct buf *b) {
    80002fee:	1101                	addi	sp,sp,-32
    80002ff0:	ec06                	sd	ra,24(sp)
    80002ff2:	e822                	sd	s0,16(sp)
    80002ff4:	e426                	sd	s1,8(sp)
    80002ff6:	1000                	addi	s0,sp,32
    80002ff8:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002ffa:	00013517          	auipc	a0,0x13
    80002ffe:	e1650513          	addi	a0,a0,-490 # 80015e10 <bcache>
    80003002:	bcdfd0ef          	jal	80000bce <acquire>
  b->refcnt--;
    80003006:	40bc                	lw	a5,64(s1)
    80003008:	37fd                	addiw	a5,a5,-1
    8000300a:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000300c:	00013517          	auipc	a0,0x13
    80003010:	e0450513          	addi	a0,a0,-508 # 80015e10 <bcache>
    80003014:	c53fd0ef          	jal	80000c66 <release>
}
    80003018:	60e2                	ld	ra,24(sp)
    8000301a:	6442                	ld	s0,16(sp)
    8000301c:	64a2                	ld	s1,8(sp)
    8000301e:	6105                	addi	sp,sp,32
    80003020:	8082                	ret

0000000080003022 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003022:	1101                	addi	sp,sp,-32
    80003024:	ec06                	sd	ra,24(sp)
    80003026:	e822                	sd	s0,16(sp)
    80003028:	e426                	sd	s1,8(sp)
    8000302a:	e04a                	sd	s2,0(sp)
    8000302c:	1000                	addi	s0,sp,32
    8000302e:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003030:	00d5d59b          	srliw	a1,a1,0xd
    80003034:	0001b797          	auipc	a5,0x1b
    80003038:	4b87a783          	lw	a5,1208(a5) # 8001e4ec <sb+0x1c>
    8000303c:	9dbd                	addw	a1,a1,a5
    8000303e:	dedff0ef          	jal	80002e2a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003042:	0074f713          	andi	a4,s1,7
    80003046:	4785                	li	a5,1
    80003048:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000304c:	14ce                	slli	s1,s1,0x33
    8000304e:	90d9                	srli	s1,s1,0x36
    80003050:	00950733          	add	a4,a0,s1
    80003054:	05874703          	lbu	a4,88(a4)
    80003058:	00e7f6b3          	and	a3,a5,a4
    8000305c:	c29d                	beqz	a3,80003082 <bfree+0x60>
    8000305e:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003060:	94aa                	add	s1,s1,a0
    80003062:	fff7c793          	not	a5,a5
    80003066:	8f7d                	and	a4,a4,a5
    80003068:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000306c:	7f9000ef          	jal	80004064 <log_write>
  brelse(bp);
    80003070:	854a                	mv	a0,s2
    80003072:	ec1ff0ef          	jal	80002f32 <brelse>
}
    80003076:	60e2                	ld	ra,24(sp)
    80003078:	6442                	ld	s0,16(sp)
    8000307a:	64a2                	ld	s1,8(sp)
    8000307c:	6902                	ld	s2,0(sp)
    8000307e:	6105                	addi	sp,sp,32
    80003080:	8082                	ret
    panic("freeing free block");
    80003082:	00004517          	auipc	a0,0x4
    80003086:	43e50513          	addi	a0,a0,1086 # 800074c0 <etext+0x4c0>
    8000308a:	f56fd0ef          	jal	800007e0 <panic>

000000008000308e <balloc>:
{
    8000308e:	711d                	addi	sp,sp,-96
    80003090:	ec86                	sd	ra,88(sp)
    80003092:	e8a2                	sd	s0,80(sp)
    80003094:	e4a6                	sd	s1,72(sp)
    80003096:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80003098:	0001b797          	auipc	a5,0x1b
    8000309c:	43c7a783          	lw	a5,1084(a5) # 8001e4d4 <sb+0x4>
    800030a0:	0e078f63          	beqz	a5,8000319e <balloc+0x110>
    800030a4:	e0ca                	sd	s2,64(sp)
    800030a6:	fc4e                	sd	s3,56(sp)
    800030a8:	f852                	sd	s4,48(sp)
    800030aa:	f456                	sd	s5,40(sp)
    800030ac:	f05a                	sd	s6,32(sp)
    800030ae:	ec5e                	sd	s7,24(sp)
    800030b0:	e862                	sd	s8,16(sp)
    800030b2:	e466                	sd	s9,8(sp)
    800030b4:	8baa                	mv	s7,a0
    800030b6:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800030b8:	0001bb17          	auipc	s6,0x1b
    800030bc:	418b0b13          	addi	s6,s6,1048 # 8001e4d0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030c0:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    800030c2:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030c4:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800030c6:	6c89                	lui	s9,0x2
    800030c8:	a0b5                	j	80003134 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    800030ca:	97ca                	add	a5,a5,s2
    800030cc:	8e55                	or	a2,a2,a3
    800030ce:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800030d2:	854a                	mv	a0,s2
    800030d4:	791000ef          	jal	80004064 <log_write>
        brelse(bp);
    800030d8:	854a                	mv	a0,s2
    800030da:	e59ff0ef          	jal	80002f32 <brelse>
  bp = bread(dev, bno);
    800030de:	85a6                	mv	a1,s1
    800030e0:	855e                	mv	a0,s7
    800030e2:	d49ff0ef          	jal	80002e2a <bread>
    800030e6:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800030e8:	40000613          	li	a2,1024
    800030ec:	4581                	li	a1,0
    800030ee:	05850513          	addi	a0,a0,88
    800030f2:	bb1fd0ef          	jal	80000ca2 <memset>
  log_write(bp);
    800030f6:	854a                	mv	a0,s2
    800030f8:	76d000ef          	jal	80004064 <log_write>
  brelse(bp);
    800030fc:	854a                	mv	a0,s2
    800030fe:	e35ff0ef          	jal	80002f32 <brelse>
}
    80003102:	6906                	ld	s2,64(sp)
    80003104:	79e2                	ld	s3,56(sp)
    80003106:	7a42                	ld	s4,48(sp)
    80003108:	7aa2                	ld	s5,40(sp)
    8000310a:	7b02                	ld	s6,32(sp)
    8000310c:	6be2                	ld	s7,24(sp)
    8000310e:	6c42                	ld	s8,16(sp)
    80003110:	6ca2                	ld	s9,8(sp)
}
    80003112:	8526                	mv	a0,s1
    80003114:	60e6                	ld	ra,88(sp)
    80003116:	6446                	ld	s0,80(sp)
    80003118:	64a6                	ld	s1,72(sp)
    8000311a:	6125                	addi	sp,sp,96
    8000311c:	8082                	ret
    brelse(bp);
    8000311e:	854a                	mv	a0,s2
    80003120:	e13ff0ef          	jal	80002f32 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80003124:	015c87bb          	addw	a5,s9,s5
    80003128:	00078a9b          	sext.w	s5,a5
    8000312c:	004b2703          	lw	a4,4(s6)
    80003130:	04eaff63          	bgeu	s5,a4,8000318e <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80003134:	41fad79b          	sraiw	a5,s5,0x1f
    80003138:	0137d79b          	srliw	a5,a5,0x13
    8000313c:	015787bb          	addw	a5,a5,s5
    80003140:	40d7d79b          	sraiw	a5,a5,0xd
    80003144:	01cb2583          	lw	a1,28(s6)
    80003148:	9dbd                	addw	a1,a1,a5
    8000314a:	855e                	mv	a0,s7
    8000314c:	cdfff0ef          	jal	80002e2a <bread>
    80003150:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003152:	004b2503          	lw	a0,4(s6)
    80003156:	000a849b          	sext.w	s1,s5
    8000315a:	8762                	mv	a4,s8
    8000315c:	fca4f1e3          	bgeu	s1,a0,8000311e <balloc+0x90>
      m = 1 << (bi % 8);
    80003160:	00777693          	andi	a3,a4,7
    80003164:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80003168:	41f7579b          	sraiw	a5,a4,0x1f
    8000316c:	01d7d79b          	srliw	a5,a5,0x1d
    80003170:	9fb9                	addw	a5,a5,a4
    80003172:	4037d79b          	sraiw	a5,a5,0x3
    80003176:	00f90633          	add	a2,s2,a5
    8000317a:	05864603          	lbu	a2,88(a2)
    8000317e:	00c6f5b3          	and	a1,a3,a2
    80003182:	d5a1                	beqz	a1,800030ca <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003184:	2705                	addiw	a4,a4,1
    80003186:	2485                	addiw	s1,s1,1
    80003188:	fd471ae3          	bne	a4,s4,8000315c <balloc+0xce>
    8000318c:	bf49                	j	8000311e <balloc+0x90>
    8000318e:	6906                	ld	s2,64(sp)
    80003190:	79e2                	ld	s3,56(sp)
    80003192:	7a42                	ld	s4,48(sp)
    80003194:	7aa2                	ld	s5,40(sp)
    80003196:	7b02                	ld	s6,32(sp)
    80003198:	6be2                	ld	s7,24(sp)
    8000319a:	6c42                	ld	s8,16(sp)
    8000319c:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    8000319e:	00004517          	auipc	a0,0x4
    800031a2:	33a50513          	addi	a0,a0,826 # 800074d8 <etext+0x4d8>
    800031a6:	b54fd0ef          	jal	800004fa <printf>
  return 0;
    800031aa:	4481                	li	s1,0
    800031ac:	b79d                	j	80003112 <balloc+0x84>

00000000800031ae <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800031ae:	7179                	addi	sp,sp,-48
    800031b0:	f406                	sd	ra,40(sp)
    800031b2:	f022                	sd	s0,32(sp)
    800031b4:	ec26                	sd	s1,24(sp)
    800031b6:	e84a                	sd	s2,16(sp)
    800031b8:	e44e                	sd	s3,8(sp)
    800031ba:	1800                	addi	s0,sp,48
    800031bc:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800031be:	47ad                	li	a5,11
    800031c0:	02b7e663          	bltu	a5,a1,800031ec <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    800031c4:	02059793          	slli	a5,a1,0x20
    800031c8:	01e7d593          	srli	a1,a5,0x1e
    800031cc:	00b504b3          	add	s1,a0,a1
    800031d0:	0504a903          	lw	s2,80(s1)
    800031d4:	06091a63          	bnez	s2,80003248 <bmap+0x9a>
      addr = balloc(ip->dev);
    800031d8:	4108                	lw	a0,0(a0)
    800031da:	eb5ff0ef          	jal	8000308e <balloc>
    800031de:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800031e2:	06090363          	beqz	s2,80003248 <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    800031e6:	0524a823          	sw	s2,80(s1)
    800031ea:	a8b9                	j	80003248 <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800031ec:	ff45849b          	addiw	s1,a1,-12
    800031f0:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800031f4:	0ff00793          	li	a5,255
    800031f8:	06e7ee63          	bltu	a5,a4,80003274 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800031fc:	08052903          	lw	s2,128(a0)
    80003200:	00091d63          	bnez	s2,8000321a <bmap+0x6c>
      addr = balloc(ip->dev);
    80003204:	4108                	lw	a0,0(a0)
    80003206:	e89ff0ef          	jal	8000308e <balloc>
    8000320a:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    8000320e:	02090d63          	beqz	s2,80003248 <bmap+0x9a>
    80003212:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003214:	0929a023          	sw	s2,128(s3)
    80003218:	a011                	j	8000321c <bmap+0x6e>
    8000321a:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000321c:	85ca                	mv	a1,s2
    8000321e:	0009a503          	lw	a0,0(s3)
    80003222:	c09ff0ef          	jal	80002e2a <bread>
    80003226:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003228:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000322c:	02049713          	slli	a4,s1,0x20
    80003230:	01e75593          	srli	a1,a4,0x1e
    80003234:	00b784b3          	add	s1,a5,a1
    80003238:	0004a903          	lw	s2,0(s1)
    8000323c:	00090e63          	beqz	s2,80003258 <bmap+0xaa>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003240:	8552                	mv	a0,s4
    80003242:	cf1ff0ef          	jal	80002f32 <brelse>
    return addr;
    80003246:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003248:	854a                	mv	a0,s2
    8000324a:	70a2                	ld	ra,40(sp)
    8000324c:	7402                	ld	s0,32(sp)
    8000324e:	64e2                	ld	s1,24(sp)
    80003250:	6942                	ld	s2,16(sp)
    80003252:	69a2                	ld	s3,8(sp)
    80003254:	6145                	addi	sp,sp,48
    80003256:	8082                	ret
      addr = balloc(ip->dev);
    80003258:	0009a503          	lw	a0,0(s3)
    8000325c:	e33ff0ef          	jal	8000308e <balloc>
    80003260:	0005091b          	sext.w	s2,a0
      if(addr){
    80003264:	fc090ee3          	beqz	s2,80003240 <bmap+0x92>
        a[bn] = addr;
    80003268:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000326c:	8552                	mv	a0,s4
    8000326e:	5f7000ef          	jal	80004064 <log_write>
    80003272:	b7f9                	j	80003240 <bmap+0x92>
    80003274:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003276:	00004517          	auipc	a0,0x4
    8000327a:	27a50513          	addi	a0,a0,634 # 800074f0 <etext+0x4f0>
    8000327e:	d62fd0ef          	jal	800007e0 <panic>

0000000080003282 <iget>:
{
    80003282:	7179                	addi	sp,sp,-48
    80003284:	f406                	sd	ra,40(sp)
    80003286:	f022                	sd	s0,32(sp)
    80003288:	ec26                	sd	s1,24(sp)
    8000328a:	e84a                	sd	s2,16(sp)
    8000328c:	e44e                	sd	s3,8(sp)
    8000328e:	e052                	sd	s4,0(sp)
    80003290:	1800                	addi	s0,sp,48
    80003292:	89aa                	mv	s3,a0
    80003294:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003296:	0001b517          	auipc	a0,0x1b
    8000329a:	25a50513          	addi	a0,a0,602 # 8001e4f0 <itable>
    8000329e:	931fd0ef          	jal	80000bce <acquire>
  empty = 0;
    800032a2:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800032a4:	0001b497          	auipc	s1,0x1b
    800032a8:	26448493          	addi	s1,s1,612 # 8001e508 <itable+0x18>
    800032ac:	0001d697          	auipc	a3,0x1d
    800032b0:	cec68693          	addi	a3,a3,-788 # 8001ff98 <log>
    800032b4:	a039                	j	800032c2 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800032b6:	02090963          	beqz	s2,800032e8 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800032ba:	08848493          	addi	s1,s1,136
    800032be:	02d48863          	beq	s1,a3,800032ee <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800032c2:	449c                	lw	a5,8(s1)
    800032c4:	fef059e3          	blez	a5,800032b6 <iget+0x34>
    800032c8:	4098                	lw	a4,0(s1)
    800032ca:	ff3716e3          	bne	a4,s3,800032b6 <iget+0x34>
    800032ce:	40d8                	lw	a4,4(s1)
    800032d0:	ff4713e3          	bne	a4,s4,800032b6 <iget+0x34>
      ip->ref++;
    800032d4:	2785                	addiw	a5,a5,1
    800032d6:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800032d8:	0001b517          	auipc	a0,0x1b
    800032dc:	21850513          	addi	a0,a0,536 # 8001e4f0 <itable>
    800032e0:	987fd0ef          	jal	80000c66 <release>
      return ip;
    800032e4:	8926                	mv	s2,s1
    800032e6:	a02d                	j	80003310 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800032e8:	fbe9                	bnez	a5,800032ba <iget+0x38>
      empty = ip;
    800032ea:	8926                	mv	s2,s1
    800032ec:	b7f9                	j	800032ba <iget+0x38>
  if(empty == 0)
    800032ee:	02090a63          	beqz	s2,80003322 <iget+0xa0>
  ip->dev = dev;
    800032f2:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800032f6:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800032fa:	4785                	li	a5,1
    800032fc:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003300:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003304:	0001b517          	auipc	a0,0x1b
    80003308:	1ec50513          	addi	a0,a0,492 # 8001e4f0 <itable>
    8000330c:	95bfd0ef          	jal	80000c66 <release>
}
    80003310:	854a                	mv	a0,s2
    80003312:	70a2                	ld	ra,40(sp)
    80003314:	7402                	ld	s0,32(sp)
    80003316:	64e2                	ld	s1,24(sp)
    80003318:	6942                	ld	s2,16(sp)
    8000331a:	69a2                	ld	s3,8(sp)
    8000331c:	6a02                	ld	s4,0(sp)
    8000331e:	6145                	addi	sp,sp,48
    80003320:	8082                	ret
    panic("iget: no inodes");
    80003322:	00004517          	auipc	a0,0x4
    80003326:	1e650513          	addi	a0,a0,486 # 80007508 <etext+0x508>
    8000332a:	cb6fd0ef          	jal	800007e0 <panic>

000000008000332e <iinit>:
{
    8000332e:	7179                	addi	sp,sp,-48
    80003330:	f406                	sd	ra,40(sp)
    80003332:	f022                	sd	s0,32(sp)
    80003334:	ec26                	sd	s1,24(sp)
    80003336:	e84a                	sd	s2,16(sp)
    80003338:	e44e                	sd	s3,8(sp)
    8000333a:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000333c:	00004597          	auipc	a1,0x4
    80003340:	1dc58593          	addi	a1,a1,476 # 80007518 <etext+0x518>
    80003344:	0001b517          	auipc	a0,0x1b
    80003348:	1ac50513          	addi	a0,a0,428 # 8001e4f0 <itable>
    8000334c:	803fd0ef          	jal	80000b4e <initlock>
  for(i = 0; i < NINODE; i++) {
    80003350:	0001b497          	auipc	s1,0x1b
    80003354:	1c848493          	addi	s1,s1,456 # 8001e518 <itable+0x28>
    80003358:	0001d997          	auipc	s3,0x1d
    8000335c:	c5098993          	addi	s3,s3,-944 # 8001ffa8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003360:	00004917          	auipc	s2,0x4
    80003364:	1c090913          	addi	s2,s2,448 # 80007520 <etext+0x520>
    80003368:	85ca                	mv	a1,s2
    8000336a:	8526                	mv	a0,s1
    8000336c:	5bb000ef          	jal	80004126 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003370:	08848493          	addi	s1,s1,136
    80003374:	ff349ae3          	bne	s1,s3,80003368 <iinit+0x3a>
}
    80003378:	70a2                	ld	ra,40(sp)
    8000337a:	7402                	ld	s0,32(sp)
    8000337c:	64e2                	ld	s1,24(sp)
    8000337e:	6942                	ld	s2,16(sp)
    80003380:	69a2                	ld	s3,8(sp)
    80003382:	6145                	addi	sp,sp,48
    80003384:	8082                	ret

0000000080003386 <ialloc>:
{
    80003386:	7139                	addi	sp,sp,-64
    80003388:	fc06                	sd	ra,56(sp)
    8000338a:	f822                	sd	s0,48(sp)
    8000338c:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    8000338e:	0001b717          	auipc	a4,0x1b
    80003392:	14e72703          	lw	a4,334(a4) # 8001e4dc <sb+0xc>
    80003396:	4785                	li	a5,1
    80003398:	06e7f063          	bgeu	a5,a4,800033f8 <ialloc+0x72>
    8000339c:	f426                	sd	s1,40(sp)
    8000339e:	f04a                	sd	s2,32(sp)
    800033a0:	ec4e                	sd	s3,24(sp)
    800033a2:	e852                	sd	s4,16(sp)
    800033a4:	e456                	sd	s5,8(sp)
    800033a6:	e05a                	sd	s6,0(sp)
    800033a8:	8aaa                	mv	s5,a0
    800033aa:	8b2e                	mv	s6,a1
    800033ac:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    800033ae:	0001ba17          	auipc	s4,0x1b
    800033b2:	122a0a13          	addi	s4,s4,290 # 8001e4d0 <sb>
    800033b6:	00495593          	srli	a1,s2,0x4
    800033ba:	018a2783          	lw	a5,24(s4)
    800033be:	9dbd                	addw	a1,a1,a5
    800033c0:	8556                	mv	a0,s5
    800033c2:	a69ff0ef          	jal	80002e2a <bread>
    800033c6:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800033c8:	05850993          	addi	s3,a0,88
    800033cc:	00f97793          	andi	a5,s2,15
    800033d0:	079a                	slli	a5,a5,0x6
    800033d2:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800033d4:	00099783          	lh	a5,0(s3)
    800033d8:	cb9d                	beqz	a5,8000340e <ialloc+0x88>
    brelse(bp);
    800033da:	b59ff0ef          	jal	80002f32 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800033de:	0905                	addi	s2,s2,1
    800033e0:	00ca2703          	lw	a4,12(s4)
    800033e4:	0009079b          	sext.w	a5,s2
    800033e8:	fce7e7e3          	bltu	a5,a4,800033b6 <ialloc+0x30>
    800033ec:	74a2                	ld	s1,40(sp)
    800033ee:	7902                	ld	s2,32(sp)
    800033f0:	69e2                	ld	s3,24(sp)
    800033f2:	6a42                	ld	s4,16(sp)
    800033f4:	6aa2                	ld	s5,8(sp)
    800033f6:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800033f8:	00004517          	auipc	a0,0x4
    800033fc:	13050513          	addi	a0,a0,304 # 80007528 <etext+0x528>
    80003400:	8fafd0ef          	jal	800004fa <printf>
  return 0;
    80003404:	4501                	li	a0,0
}
    80003406:	70e2                	ld	ra,56(sp)
    80003408:	7442                	ld	s0,48(sp)
    8000340a:	6121                	addi	sp,sp,64
    8000340c:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000340e:	04000613          	li	a2,64
    80003412:	4581                	li	a1,0
    80003414:	854e                	mv	a0,s3
    80003416:	88dfd0ef          	jal	80000ca2 <memset>
      dip->type = type;
    8000341a:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    8000341e:	8526                	mv	a0,s1
    80003420:	445000ef          	jal	80004064 <log_write>
      brelse(bp);
    80003424:	8526                	mv	a0,s1
    80003426:	b0dff0ef          	jal	80002f32 <brelse>
      return iget(dev, inum);
    8000342a:	0009059b          	sext.w	a1,s2
    8000342e:	8556                	mv	a0,s5
    80003430:	e53ff0ef          	jal	80003282 <iget>
    80003434:	74a2                	ld	s1,40(sp)
    80003436:	7902                	ld	s2,32(sp)
    80003438:	69e2                	ld	s3,24(sp)
    8000343a:	6a42                	ld	s4,16(sp)
    8000343c:	6aa2                	ld	s5,8(sp)
    8000343e:	6b02                	ld	s6,0(sp)
    80003440:	b7d9                	j	80003406 <ialloc+0x80>

0000000080003442 <iupdate>:
{
    80003442:	1101                	addi	sp,sp,-32
    80003444:	ec06                	sd	ra,24(sp)
    80003446:	e822                	sd	s0,16(sp)
    80003448:	e426                	sd	s1,8(sp)
    8000344a:	e04a                	sd	s2,0(sp)
    8000344c:	1000                	addi	s0,sp,32
    8000344e:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003450:	415c                	lw	a5,4(a0)
    80003452:	0047d79b          	srliw	a5,a5,0x4
    80003456:	0001b597          	auipc	a1,0x1b
    8000345a:	0925a583          	lw	a1,146(a1) # 8001e4e8 <sb+0x18>
    8000345e:	9dbd                	addw	a1,a1,a5
    80003460:	4108                	lw	a0,0(a0)
    80003462:	9c9ff0ef          	jal	80002e2a <bread>
    80003466:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003468:	05850793          	addi	a5,a0,88
    8000346c:	40d8                	lw	a4,4(s1)
    8000346e:	8b3d                	andi	a4,a4,15
    80003470:	071a                	slli	a4,a4,0x6
    80003472:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003474:	04449703          	lh	a4,68(s1)
    80003478:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000347c:	04649703          	lh	a4,70(s1)
    80003480:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003484:	04849703          	lh	a4,72(s1)
    80003488:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000348c:	04a49703          	lh	a4,74(s1)
    80003490:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003494:	44f8                	lw	a4,76(s1)
    80003496:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003498:	03400613          	li	a2,52
    8000349c:	05048593          	addi	a1,s1,80
    800034a0:	00c78513          	addi	a0,a5,12
    800034a4:	85bfd0ef          	jal	80000cfe <memmove>
  log_write(bp);
    800034a8:	854a                	mv	a0,s2
    800034aa:	3bb000ef          	jal	80004064 <log_write>
  brelse(bp);
    800034ae:	854a                	mv	a0,s2
    800034b0:	a83ff0ef          	jal	80002f32 <brelse>
}
    800034b4:	60e2                	ld	ra,24(sp)
    800034b6:	6442                	ld	s0,16(sp)
    800034b8:	64a2                	ld	s1,8(sp)
    800034ba:	6902                	ld	s2,0(sp)
    800034bc:	6105                	addi	sp,sp,32
    800034be:	8082                	ret

00000000800034c0 <idup>:
{
    800034c0:	1101                	addi	sp,sp,-32
    800034c2:	ec06                	sd	ra,24(sp)
    800034c4:	e822                	sd	s0,16(sp)
    800034c6:	e426                	sd	s1,8(sp)
    800034c8:	1000                	addi	s0,sp,32
    800034ca:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034cc:	0001b517          	auipc	a0,0x1b
    800034d0:	02450513          	addi	a0,a0,36 # 8001e4f0 <itable>
    800034d4:	efafd0ef          	jal	80000bce <acquire>
  ip->ref++;
    800034d8:	449c                	lw	a5,8(s1)
    800034da:	2785                	addiw	a5,a5,1
    800034dc:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034de:	0001b517          	auipc	a0,0x1b
    800034e2:	01250513          	addi	a0,a0,18 # 8001e4f0 <itable>
    800034e6:	f80fd0ef          	jal	80000c66 <release>
}
    800034ea:	8526                	mv	a0,s1
    800034ec:	60e2                	ld	ra,24(sp)
    800034ee:	6442                	ld	s0,16(sp)
    800034f0:	64a2                	ld	s1,8(sp)
    800034f2:	6105                	addi	sp,sp,32
    800034f4:	8082                	ret

00000000800034f6 <ilock>:
{
    800034f6:	1101                	addi	sp,sp,-32
    800034f8:	ec06                	sd	ra,24(sp)
    800034fa:	e822                	sd	s0,16(sp)
    800034fc:	e426                	sd	s1,8(sp)
    800034fe:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003500:	cd19                	beqz	a0,8000351e <ilock+0x28>
    80003502:	84aa                	mv	s1,a0
    80003504:	451c                	lw	a5,8(a0)
    80003506:	00f05c63          	blez	a5,8000351e <ilock+0x28>
  acquiresleep(&ip->lock);
    8000350a:	0541                	addi	a0,a0,16
    8000350c:	451000ef          	jal	8000415c <acquiresleep>
  if(ip->valid == 0){
    80003510:	40bc                	lw	a5,64(s1)
    80003512:	cf89                	beqz	a5,8000352c <ilock+0x36>
}
    80003514:	60e2                	ld	ra,24(sp)
    80003516:	6442                	ld	s0,16(sp)
    80003518:	64a2                	ld	s1,8(sp)
    8000351a:	6105                	addi	sp,sp,32
    8000351c:	8082                	ret
    8000351e:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003520:	00004517          	auipc	a0,0x4
    80003524:	02050513          	addi	a0,a0,32 # 80007540 <etext+0x540>
    80003528:	ab8fd0ef          	jal	800007e0 <panic>
    8000352c:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000352e:	40dc                	lw	a5,4(s1)
    80003530:	0047d79b          	srliw	a5,a5,0x4
    80003534:	0001b597          	auipc	a1,0x1b
    80003538:	fb45a583          	lw	a1,-76(a1) # 8001e4e8 <sb+0x18>
    8000353c:	9dbd                	addw	a1,a1,a5
    8000353e:	4088                	lw	a0,0(s1)
    80003540:	8ebff0ef          	jal	80002e2a <bread>
    80003544:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003546:	05850593          	addi	a1,a0,88
    8000354a:	40dc                	lw	a5,4(s1)
    8000354c:	8bbd                	andi	a5,a5,15
    8000354e:	079a                	slli	a5,a5,0x6
    80003550:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003552:	00059783          	lh	a5,0(a1)
    80003556:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000355a:	00259783          	lh	a5,2(a1)
    8000355e:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003562:	00459783          	lh	a5,4(a1)
    80003566:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000356a:	00659783          	lh	a5,6(a1)
    8000356e:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003572:	459c                	lw	a5,8(a1)
    80003574:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003576:	03400613          	li	a2,52
    8000357a:	05b1                	addi	a1,a1,12
    8000357c:	05048513          	addi	a0,s1,80
    80003580:	f7efd0ef          	jal	80000cfe <memmove>
    brelse(bp);
    80003584:	854a                	mv	a0,s2
    80003586:	9adff0ef          	jal	80002f32 <brelse>
    ip->valid = 1;
    8000358a:	4785                	li	a5,1
    8000358c:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000358e:	04449783          	lh	a5,68(s1)
    80003592:	c399                	beqz	a5,80003598 <ilock+0xa2>
    80003594:	6902                	ld	s2,0(sp)
    80003596:	bfbd                	j	80003514 <ilock+0x1e>
      panic("ilock: no type");
    80003598:	00004517          	auipc	a0,0x4
    8000359c:	fb050513          	addi	a0,a0,-80 # 80007548 <etext+0x548>
    800035a0:	a40fd0ef          	jal	800007e0 <panic>

00000000800035a4 <iunlock>:
{
    800035a4:	1101                	addi	sp,sp,-32
    800035a6:	ec06                	sd	ra,24(sp)
    800035a8:	e822                	sd	s0,16(sp)
    800035aa:	e426                	sd	s1,8(sp)
    800035ac:	e04a                	sd	s2,0(sp)
    800035ae:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800035b0:	c505                	beqz	a0,800035d8 <iunlock+0x34>
    800035b2:	84aa                	mv	s1,a0
    800035b4:	01050913          	addi	s2,a0,16
    800035b8:	854a                	mv	a0,s2
    800035ba:	421000ef          	jal	800041da <holdingsleep>
    800035be:	cd09                	beqz	a0,800035d8 <iunlock+0x34>
    800035c0:	449c                	lw	a5,8(s1)
    800035c2:	00f05b63          	blez	a5,800035d8 <iunlock+0x34>
  releasesleep(&ip->lock);
    800035c6:	854a                	mv	a0,s2
    800035c8:	3db000ef          	jal	800041a2 <releasesleep>
}
    800035cc:	60e2                	ld	ra,24(sp)
    800035ce:	6442                	ld	s0,16(sp)
    800035d0:	64a2                	ld	s1,8(sp)
    800035d2:	6902                	ld	s2,0(sp)
    800035d4:	6105                	addi	sp,sp,32
    800035d6:	8082                	ret
    panic("iunlock");
    800035d8:	00004517          	auipc	a0,0x4
    800035dc:	f8050513          	addi	a0,a0,-128 # 80007558 <etext+0x558>
    800035e0:	a00fd0ef          	jal	800007e0 <panic>

00000000800035e4 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800035e4:	7179                	addi	sp,sp,-48
    800035e6:	f406                	sd	ra,40(sp)
    800035e8:	f022                	sd	s0,32(sp)
    800035ea:	ec26                	sd	s1,24(sp)
    800035ec:	e84a                	sd	s2,16(sp)
    800035ee:	e44e                	sd	s3,8(sp)
    800035f0:	1800                	addi	s0,sp,48
    800035f2:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800035f4:	05050493          	addi	s1,a0,80
    800035f8:	08050913          	addi	s2,a0,128
    800035fc:	a021                	j	80003604 <itrunc+0x20>
    800035fe:	0491                	addi	s1,s1,4
    80003600:	01248b63          	beq	s1,s2,80003616 <itrunc+0x32>
    if(ip->addrs[i]){
    80003604:	408c                	lw	a1,0(s1)
    80003606:	dde5                	beqz	a1,800035fe <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003608:	0009a503          	lw	a0,0(s3)
    8000360c:	a17ff0ef          	jal	80003022 <bfree>
      ip->addrs[i] = 0;
    80003610:	0004a023          	sw	zero,0(s1)
    80003614:	b7ed                	j	800035fe <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003616:	0809a583          	lw	a1,128(s3)
    8000361a:	ed89                	bnez	a1,80003634 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000361c:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003620:	854e                	mv	a0,s3
    80003622:	e21ff0ef          	jal	80003442 <iupdate>
}
    80003626:	70a2                	ld	ra,40(sp)
    80003628:	7402                	ld	s0,32(sp)
    8000362a:	64e2                	ld	s1,24(sp)
    8000362c:	6942                	ld	s2,16(sp)
    8000362e:	69a2                	ld	s3,8(sp)
    80003630:	6145                	addi	sp,sp,48
    80003632:	8082                	ret
    80003634:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003636:	0009a503          	lw	a0,0(s3)
    8000363a:	ff0ff0ef          	jal	80002e2a <bread>
    8000363e:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003640:	05850493          	addi	s1,a0,88
    80003644:	45850913          	addi	s2,a0,1112
    80003648:	a021                	j	80003650 <itrunc+0x6c>
    8000364a:	0491                	addi	s1,s1,4
    8000364c:	01248963          	beq	s1,s2,8000365e <itrunc+0x7a>
      if(a[j])
    80003650:	408c                	lw	a1,0(s1)
    80003652:	dde5                	beqz	a1,8000364a <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003654:	0009a503          	lw	a0,0(s3)
    80003658:	9cbff0ef          	jal	80003022 <bfree>
    8000365c:	b7fd                	j	8000364a <itrunc+0x66>
    brelse(bp);
    8000365e:	8552                	mv	a0,s4
    80003660:	8d3ff0ef          	jal	80002f32 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003664:	0809a583          	lw	a1,128(s3)
    80003668:	0009a503          	lw	a0,0(s3)
    8000366c:	9b7ff0ef          	jal	80003022 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003670:	0809a023          	sw	zero,128(s3)
    80003674:	6a02                	ld	s4,0(sp)
    80003676:	b75d                	j	8000361c <itrunc+0x38>

0000000080003678 <iput>:
{
    80003678:	1101                	addi	sp,sp,-32
    8000367a:	ec06                	sd	ra,24(sp)
    8000367c:	e822                	sd	s0,16(sp)
    8000367e:	e426                	sd	s1,8(sp)
    80003680:	1000                	addi	s0,sp,32
    80003682:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003684:	0001b517          	auipc	a0,0x1b
    80003688:	e6c50513          	addi	a0,a0,-404 # 8001e4f0 <itable>
    8000368c:	d42fd0ef          	jal	80000bce <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003690:	4498                	lw	a4,8(s1)
    80003692:	4785                	li	a5,1
    80003694:	02f70063          	beq	a4,a5,800036b4 <iput+0x3c>
  ip->ref--;
    80003698:	449c                	lw	a5,8(s1)
    8000369a:	37fd                	addiw	a5,a5,-1
    8000369c:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000369e:	0001b517          	auipc	a0,0x1b
    800036a2:	e5250513          	addi	a0,a0,-430 # 8001e4f0 <itable>
    800036a6:	dc0fd0ef          	jal	80000c66 <release>
}
    800036aa:	60e2                	ld	ra,24(sp)
    800036ac:	6442                	ld	s0,16(sp)
    800036ae:	64a2                	ld	s1,8(sp)
    800036b0:	6105                	addi	sp,sp,32
    800036b2:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800036b4:	40bc                	lw	a5,64(s1)
    800036b6:	d3ed                	beqz	a5,80003698 <iput+0x20>
    800036b8:	04a49783          	lh	a5,74(s1)
    800036bc:	fff1                	bnez	a5,80003698 <iput+0x20>
    800036be:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800036c0:	01048913          	addi	s2,s1,16
    800036c4:	854a                	mv	a0,s2
    800036c6:	297000ef          	jal	8000415c <acquiresleep>
    release(&itable.lock);
    800036ca:	0001b517          	auipc	a0,0x1b
    800036ce:	e2650513          	addi	a0,a0,-474 # 8001e4f0 <itable>
    800036d2:	d94fd0ef          	jal	80000c66 <release>
    itrunc(ip);
    800036d6:	8526                	mv	a0,s1
    800036d8:	f0dff0ef          	jal	800035e4 <itrunc>
    ip->type = 0;
    800036dc:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800036e0:	8526                	mv	a0,s1
    800036e2:	d61ff0ef          	jal	80003442 <iupdate>
    ip->valid = 0;
    800036e6:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800036ea:	854a                	mv	a0,s2
    800036ec:	2b7000ef          	jal	800041a2 <releasesleep>
    acquire(&itable.lock);
    800036f0:	0001b517          	auipc	a0,0x1b
    800036f4:	e0050513          	addi	a0,a0,-512 # 8001e4f0 <itable>
    800036f8:	cd6fd0ef          	jal	80000bce <acquire>
    800036fc:	6902                	ld	s2,0(sp)
    800036fe:	bf69                	j	80003698 <iput+0x20>

0000000080003700 <iunlockput>:
{
    80003700:	1101                	addi	sp,sp,-32
    80003702:	ec06                	sd	ra,24(sp)
    80003704:	e822                	sd	s0,16(sp)
    80003706:	e426                	sd	s1,8(sp)
    80003708:	1000                	addi	s0,sp,32
    8000370a:	84aa                	mv	s1,a0
  iunlock(ip);
    8000370c:	e99ff0ef          	jal	800035a4 <iunlock>
  iput(ip);
    80003710:	8526                	mv	a0,s1
    80003712:	f67ff0ef          	jal	80003678 <iput>
}
    80003716:	60e2                	ld	ra,24(sp)
    80003718:	6442                	ld	s0,16(sp)
    8000371a:	64a2                	ld	s1,8(sp)
    8000371c:	6105                	addi	sp,sp,32
    8000371e:	8082                	ret

0000000080003720 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003720:	0001b717          	auipc	a4,0x1b
    80003724:	dbc72703          	lw	a4,-580(a4) # 8001e4dc <sb+0xc>
    80003728:	4785                	li	a5,1
    8000372a:	0ae7ff63          	bgeu	a5,a4,800037e8 <ireclaim+0xc8>
{
    8000372e:	7139                	addi	sp,sp,-64
    80003730:	fc06                	sd	ra,56(sp)
    80003732:	f822                	sd	s0,48(sp)
    80003734:	f426                	sd	s1,40(sp)
    80003736:	f04a                	sd	s2,32(sp)
    80003738:	ec4e                	sd	s3,24(sp)
    8000373a:	e852                	sd	s4,16(sp)
    8000373c:	e456                	sd	s5,8(sp)
    8000373e:	e05a                	sd	s6,0(sp)
    80003740:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003742:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003744:	00050a1b          	sext.w	s4,a0
    80003748:	0001ba97          	auipc	s5,0x1b
    8000374c:	d88a8a93          	addi	s5,s5,-632 # 8001e4d0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003750:	00004b17          	auipc	s6,0x4
    80003754:	e10b0b13          	addi	s6,s6,-496 # 80007560 <etext+0x560>
    80003758:	a099                	j	8000379e <ireclaim+0x7e>
    8000375a:	85ce                	mv	a1,s3
    8000375c:	855a                	mv	a0,s6
    8000375e:	d9dfc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003762:	85ce                	mv	a1,s3
    80003764:	8552                	mv	a0,s4
    80003766:	b1dff0ef          	jal	80003282 <iget>
    8000376a:	89aa                	mv	s3,a0
    brelse(bp);
    8000376c:	854a                	mv	a0,s2
    8000376e:	fc4ff0ef          	jal	80002f32 <brelse>
    if (ip) {
    80003772:	00098f63          	beqz	s3,80003790 <ireclaim+0x70>
      begin_op();
    80003776:	76a000ef          	jal	80003ee0 <begin_op>
      ilock(ip);
    8000377a:	854e                	mv	a0,s3
    8000377c:	d7bff0ef          	jal	800034f6 <ilock>
      iunlock(ip);
    80003780:	854e                	mv	a0,s3
    80003782:	e23ff0ef          	jal	800035a4 <iunlock>
      iput(ip);
    80003786:	854e                	mv	a0,s3
    80003788:	ef1ff0ef          	jal	80003678 <iput>
      end_op();
    8000378c:	7be000ef          	jal	80003f4a <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003790:	0485                	addi	s1,s1,1
    80003792:	00caa703          	lw	a4,12(s5)
    80003796:	0004879b          	sext.w	a5,s1
    8000379a:	02e7fd63          	bgeu	a5,a4,800037d4 <ireclaim+0xb4>
    8000379e:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800037a2:	0044d593          	srli	a1,s1,0x4
    800037a6:	018aa783          	lw	a5,24(s5)
    800037aa:	9dbd                	addw	a1,a1,a5
    800037ac:	8552                	mv	a0,s4
    800037ae:	e7cff0ef          	jal	80002e2a <bread>
    800037b2:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800037b4:	05850793          	addi	a5,a0,88
    800037b8:	00f9f713          	andi	a4,s3,15
    800037bc:	071a                	slli	a4,a4,0x6
    800037be:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800037c0:	00079703          	lh	a4,0(a5)
    800037c4:	c701                	beqz	a4,800037cc <ireclaim+0xac>
    800037c6:	00679783          	lh	a5,6(a5)
    800037ca:	dbc1                	beqz	a5,8000375a <ireclaim+0x3a>
    brelse(bp);
    800037cc:	854a                	mv	a0,s2
    800037ce:	f64ff0ef          	jal	80002f32 <brelse>
    if (ip) {
    800037d2:	bf7d                	j	80003790 <ireclaim+0x70>
}
    800037d4:	70e2                	ld	ra,56(sp)
    800037d6:	7442                	ld	s0,48(sp)
    800037d8:	74a2                	ld	s1,40(sp)
    800037da:	7902                	ld	s2,32(sp)
    800037dc:	69e2                	ld	s3,24(sp)
    800037de:	6a42                	ld	s4,16(sp)
    800037e0:	6aa2                	ld	s5,8(sp)
    800037e2:	6b02                	ld	s6,0(sp)
    800037e4:	6121                	addi	sp,sp,64
    800037e6:	8082                	ret
    800037e8:	8082                	ret

00000000800037ea <fsinit>:
fsinit(int dev) {
    800037ea:	7179                	addi	sp,sp,-48
    800037ec:	f406                	sd	ra,40(sp)
    800037ee:	f022                	sd	s0,32(sp)
    800037f0:	ec26                	sd	s1,24(sp)
    800037f2:	e84a                	sd	s2,16(sp)
    800037f4:	e44e                	sd	s3,8(sp)
    800037f6:	1800                	addi	s0,sp,48
    800037f8:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    800037fa:	4585                	li	a1,1
    800037fc:	e2eff0ef          	jal	80002e2a <bread>
    80003800:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003802:	0001b997          	auipc	s3,0x1b
    80003806:	cce98993          	addi	s3,s3,-818 # 8001e4d0 <sb>
    8000380a:	02000613          	li	a2,32
    8000380e:	05850593          	addi	a1,a0,88
    80003812:	854e                	mv	a0,s3
    80003814:	ceafd0ef          	jal	80000cfe <memmove>
  brelse(bp);
    80003818:	854a                	mv	a0,s2
    8000381a:	f18ff0ef          	jal	80002f32 <brelse>
  if(sb.magic != FSMAGIC)
    8000381e:	0009a703          	lw	a4,0(s3)
    80003822:	102037b7          	lui	a5,0x10203
    80003826:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000382a:	02f71363          	bne	a4,a5,80003850 <fsinit+0x66>
  initlog(dev, &sb);
    8000382e:	0001b597          	auipc	a1,0x1b
    80003832:	ca258593          	addi	a1,a1,-862 # 8001e4d0 <sb>
    80003836:	8526                	mv	a0,s1
    80003838:	62a000ef          	jal	80003e62 <initlog>
  ireclaim(dev);
    8000383c:	8526                	mv	a0,s1
    8000383e:	ee3ff0ef          	jal	80003720 <ireclaim>
}
    80003842:	70a2                	ld	ra,40(sp)
    80003844:	7402                	ld	s0,32(sp)
    80003846:	64e2                	ld	s1,24(sp)
    80003848:	6942                	ld	s2,16(sp)
    8000384a:	69a2                	ld	s3,8(sp)
    8000384c:	6145                	addi	sp,sp,48
    8000384e:	8082                	ret
    panic("invalid file system");
    80003850:	00004517          	auipc	a0,0x4
    80003854:	d3050513          	addi	a0,a0,-720 # 80007580 <etext+0x580>
    80003858:	f89fc0ef          	jal	800007e0 <panic>

000000008000385c <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000385c:	1141                	addi	sp,sp,-16
    8000385e:	e422                	sd	s0,8(sp)
    80003860:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003862:	411c                	lw	a5,0(a0)
    80003864:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003866:	415c                	lw	a5,4(a0)
    80003868:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000386a:	04451783          	lh	a5,68(a0)
    8000386e:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003872:	04a51783          	lh	a5,74(a0)
    80003876:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000387a:	04c56783          	lwu	a5,76(a0)
    8000387e:	e99c                	sd	a5,16(a1)
}
    80003880:	6422                	ld	s0,8(sp)
    80003882:	0141                	addi	sp,sp,16
    80003884:	8082                	ret

0000000080003886 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003886:	457c                	lw	a5,76(a0)
    80003888:	0ed7eb63          	bltu	a5,a3,8000397e <readi+0xf8>
{
    8000388c:	7159                	addi	sp,sp,-112
    8000388e:	f486                	sd	ra,104(sp)
    80003890:	f0a2                	sd	s0,96(sp)
    80003892:	eca6                	sd	s1,88(sp)
    80003894:	e0d2                	sd	s4,64(sp)
    80003896:	fc56                	sd	s5,56(sp)
    80003898:	f85a                	sd	s6,48(sp)
    8000389a:	f45e                	sd	s7,40(sp)
    8000389c:	1880                	addi	s0,sp,112
    8000389e:	8b2a                	mv	s6,a0
    800038a0:	8bae                	mv	s7,a1
    800038a2:	8a32                	mv	s4,a2
    800038a4:	84b6                	mv	s1,a3
    800038a6:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800038a8:	9f35                	addw	a4,a4,a3
    return 0;
    800038aa:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800038ac:	0cd76063          	bltu	a4,a3,8000396c <readi+0xe6>
    800038b0:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800038b2:	00e7f463          	bgeu	a5,a4,800038ba <readi+0x34>
    n = ip->size - off;
    800038b6:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800038ba:	080a8f63          	beqz	s5,80003958 <readi+0xd2>
    800038be:	e8ca                	sd	s2,80(sp)
    800038c0:	f062                	sd	s8,32(sp)
    800038c2:	ec66                	sd	s9,24(sp)
    800038c4:	e86a                	sd	s10,16(sp)
    800038c6:	e46e                	sd	s11,8(sp)
    800038c8:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800038ca:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800038ce:	5c7d                	li	s8,-1
    800038d0:	a80d                	j	80003902 <readi+0x7c>
    800038d2:	020d1d93          	slli	s11,s10,0x20
    800038d6:	020ddd93          	srli	s11,s11,0x20
    800038da:	05890613          	addi	a2,s2,88
    800038de:	86ee                	mv	a3,s11
    800038e0:	963a                	add	a2,a2,a4
    800038e2:	85d2                	mv	a1,s4
    800038e4:	855e                	mv	a0,s7
    800038e6:	ba9fe0ef          	jal	8000248e <either_copyout>
    800038ea:	05850763          	beq	a0,s8,80003938 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800038ee:	854a                	mv	a0,s2
    800038f0:	e42ff0ef          	jal	80002f32 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800038f4:	013d09bb          	addw	s3,s10,s3
    800038f8:	009d04bb          	addw	s1,s10,s1
    800038fc:	9a6e                	add	s4,s4,s11
    800038fe:	0559f763          	bgeu	s3,s5,8000394c <readi+0xc6>
    uint addr = bmap(ip, off/BSIZE);
    80003902:	00a4d59b          	srliw	a1,s1,0xa
    80003906:	855a                	mv	a0,s6
    80003908:	8a7ff0ef          	jal	800031ae <bmap>
    8000390c:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003910:	c5b1                	beqz	a1,8000395c <readi+0xd6>
    bp = bread(ip->dev, addr);
    80003912:	000b2503          	lw	a0,0(s6)
    80003916:	d14ff0ef          	jal	80002e2a <bread>
    8000391a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000391c:	3ff4f713          	andi	a4,s1,1023
    80003920:	40ec87bb          	subw	a5,s9,a4
    80003924:	413a86bb          	subw	a3,s5,s3
    80003928:	8d3e                	mv	s10,a5
    8000392a:	2781                	sext.w	a5,a5
    8000392c:	0006861b          	sext.w	a2,a3
    80003930:	faf671e3          	bgeu	a2,a5,800038d2 <readi+0x4c>
    80003934:	8d36                	mv	s10,a3
    80003936:	bf71                	j	800038d2 <readi+0x4c>
      brelse(bp);
    80003938:	854a                	mv	a0,s2
    8000393a:	df8ff0ef          	jal	80002f32 <brelse>
      tot = -1;
    8000393e:	59fd                	li	s3,-1
      break;
    80003940:	6946                	ld	s2,80(sp)
    80003942:	7c02                	ld	s8,32(sp)
    80003944:	6ce2                	ld	s9,24(sp)
    80003946:	6d42                	ld	s10,16(sp)
    80003948:	6da2                	ld	s11,8(sp)
    8000394a:	a831                	j	80003966 <readi+0xe0>
    8000394c:	6946                	ld	s2,80(sp)
    8000394e:	7c02                	ld	s8,32(sp)
    80003950:	6ce2                	ld	s9,24(sp)
    80003952:	6d42                	ld	s10,16(sp)
    80003954:	6da2                	ld	s11,8(sp)
    80003956:	a801                	j	80003966 <readi+0xe0>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003958:	89d6                	mv	s3,s5
    8000395a:	a031                	j	80003966 <readi+0xe0>
    8000395c:	6946                	ld	s2,80(sp)
    8000395e:	7c02                	ld	s8,32(sp)
    80003960:	6ce2                	ld	s9,24(sp)
    80003962:	6d42                	ld	s10,16(sp)
    80003964:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003966:	0009851b          	sext.w	a0,s3
    8000396a:	69a6                	ld	s3,72(sp)
}
    8000396c:	70a6                	ld	ra,104(sp)
    8000396e:	7406                	ld	s0,96(sp)
    80003970:	64e6                	ld	s1,88(sp)
    80003972:	6a06                	ld	s4,64(sp)
    80003974:	7ae2                	ld	s5,56(sp)
    80003976:	7b42                	ld	s6,48(sp)
    80003978:	7ba2                	ld	s7,40(sp)
    8000397a:	6165                	addi	sp,sp,112
    8000397c:	8082                	ret
    return 0;
    8000397e:	4501                	li	a0,0
}
    80003980:	8082                	ret

0000000080003982 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003982:	457c                	lw	a5,76(a0)
    80003984:	10d7e063          	bltu	a5,a3,80003a84 <writei+0x102>
{
    80003988:	7159                	addi	sp,sp,-112
    8000398a:	f486                	sd	ra,104(sp)
    8000398c:	f0a2                	sd	s0,96(sp)
    8000398e:	e8ca                	sd	s2,80(sp)
    80003990:	e0d2                	sd	s4,64(sp)
    80003992:	fc56                	sd	s5,56(sp)
    80003994:	f85a                	sd	s6,48(sp)
    80003996:	f45e                	sd	s7,40(sp)
    80003998:	1880                	addi	s0,sp,112
    8000399a:	8aaa                	mv	s5,a0
    8000399c:	8bae                	mv	s7,a1
    8000399e:	8a32                	mv	s4,a2
    800039a0:	8936                	mv	s2,a3
    800039a2:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800039a4:	00e687bb          	addw	a5,a3,a4
    800039a8:	0ed7e063          	bltu	a5,a3,80003a88 <writei+0x106>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800039ac:	00043737          	lui	a4,0x43
    800039b0:	0cf76e63          	bltu	a4,a5,80003a8c <writei+0x10a>
    800039b4:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800039b6:	0a0b0f63          	beqz	s6,80003a74 <writei+0xf2>
    800039ba:	eca6                	sd	s1,88(sp)
    800039bc:	f062                	sd	s8,32(sp)
    800039be:	ec66                	sd	s9,24(sp)
    800039c0:	e86a                	sd	s10,16(sp)
    800039c2:	e46e                	sd	s11,8(sp)
    800039c4:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800039c6:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800039ca:	5c7d                	li	s8,-1
    800039cc:	a825                	j	80003a04 <writei+0x82>
    800039ce:	020d1d93          	slli	s11,s10,0x20
    800039d2:	020ddd93          	srli	s11,s11,0x20
    800039d6:	05848513          	addi	a0,s1,88
    800039da:	86ee                	mv	a3,s11
    800039dc:	8652                	mv	a2,s4
    800039de:	85de                	mv	a1,s7
    800039e0:	953a                	add	a0,a0,a4
    800039e2:	af7fe0ef          	jal	800024d8 <either_copyin>
    800039e6:	05850a63          	beq	a0,s8,80003a3a <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800039ea:	8526                	mv	a0,s1
    800039ec:	678000ef          	jal	80004064 <log_write>
    brelse(bp);
    800039f0:	8526                	mv	a0,s1
    800039f2:	d40ff0ef          	jal	80002f32 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800039f6:	013d09bb          	addw	s3,s10,s3
    800039fa:	012d093b          	addw	s2,s10,s2
    800039fe:	9a6e                	add	s4,s4,s11
    80003a00:	0569f063          	bgeu	s3,s6,80003a40 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003a04:	00a9559b          	srliw	a1,s2,0xa
    80003a08:	8556                	mv	a0,s5
    80003a0a:	fa4ff0ef          	jal	800031ae <bmap>
    80003a0e:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003a12:	c59d                	beqz	a1,80003a40 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80003a14:	000aa503          	lw	a0,0(s5)
    80003a18:	c12ff0ef          	jal	80002e2a <bread>
    80003a1c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a1e:	3ff97713          	andi	a4,s2,1023
    80003a22:	40ec87bb          	subw	a5,s9,a4
    80003a26:	413b06bb          	subw	a3,s6,s3
    80003a2a:	8d3e                	mv	s10,a5
    80003a2c:	2781                	sext.w	a5,a5
    80003a2e:	0006861b          	sext.w	a2,a3
    80003a32:	f8f67ee3          	bgeu	a2,a5,800039ce <writei+0x4c>
    80003a36:	8d36                	mv	s10,a3
    80003a38:	bf59                	j	800039ce <writei+0x4c>
      brelse(bp);
    80003a3a:	8526                	mv	a0,s1
    80003a3c:	cf6ff0ef          	jal	80002f32 <brelse>
  }

  if(off > ip->size)
    80003a40:	04caa783          	lw	a5,76(s5)
    80003a44:	0327fa63          	bgeu	a5,s2,80003a78 <writei+0xf6>
    ip->size = off;
    80003a48:	052aa623          	sw	s2,76(s5)
    80003a4c:	64e6                	ld	s1,88(sp)
    80003a4e:	7c02                	ld	s8,32(sp)
    80003a50:	6ce2                	ld	s9,24(sp)
    80003a52:	6d42                	ld	s10,16(sp)
    80003a54:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003a56:	8556                	mv	a0,s5
    80003a58:	9ebff0ef          	jal	80003442 <iupdate>

  return tot;
    80003a5c:	0009851b          	sext.w	a0,s3
    80003a60:	69a6                	ld	s3,72(sp)
}
    80003a62:	70a6                	ld	ra,104(sp)
    80003a64:	7406                	ld	s0,96(sp)
    80003a66:	6946                	ld	s2,80(sp)
    80003a68:	6a06                	ld	s4,64(sp)
    80003a6a:	7ae2                	ld	s5,56(sp)
    80003a6c:	7b42                	ld	s6,48(sp)
    80003a6e:	7ba2                	ld	s7,40(sp)
    80003a70:	6165                	addi	sp,sp,112
    80003a72:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003a74:	89da                	mv	s3,s6
    80003a76:	b7c5                	j	80003a56 <writei+0xd4>
    80003a78:	64e6                	ld	s1,88(sp)
    80003a7a:	7c02                	ld	s8,32(sp)
    80003a7c:	6ce2                	ld	s9,24(sp)
    80003a7e:	6d42                	ld	s10,16(sp)
    80003a80:	6da2                	ld	s11,8(sp)
    80003a82:	bfd1                	j	80003a56 <writei+0xd4>
    return -1;
    80003a84:	557d                	li	a0,-1
}
    80003a86:	8082                	ret
    return -1;
    80003a88:	557d                	li	a0,-1
    80003a8a:	bfe1                	j	80003a62 <writei+0xe0>
    return -1;
    80003a8c:	557d                	li	a0,-1
    80003a8e:	bfd1                	j	80003a62 <writei+0xe0>

0000000080003a90 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003a90:	1141                	addi	sp,sp,-16
    80003a92:	e406                	sd	ra,8(sp)
    80003a94:	e022                	sd	s0,0(sp)
    80003a96:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003a98:	4639                	li	a2,14
    80003a9a:	ad4fd0ef          	jal	80000d6e <strncmp>
}
    80003a9e:	60a2                	ld	ra,8(sp)
    80003aa0:	6402                	ld	s0,0(sp)
    80003aa2:	0141                	addi	sp,sp,16
    80003aa4:	8082                	ret

0000000080003aa6 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003aa6:	7139                	addi	sp,sp,-64
    80003aa8:	fc06                	sd	ra,56(sp)
    80003aaa:	f822                	sd	s0,48(sp)
    80003aac:	f426                	sd	s1,40(sp)
    80003aae:	f04a                	sd	s2,32(sp)
    80003ab0:	ec4e                	sd	s3,24(sp)
    80003ab2:	e852                	sd	s4,16(sp)
    80003ab4:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003ab6:	04451703          	lh	a4,68(a0)
    80003aba:	4785                	li	a5,1
    80003abc:	00f71a63          	bne	a4,a5,80003ad0 <dirlookup+0x2a>
    80003ac0:	892a                	mv	s2,a0
    80003ac2:	89ae                	mv	s3,a1
    80003ac4:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ac6:	457c                	lw	a5,76(a0)
    80003ac8:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003aca:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003acc:	e39d                	bnez	a5,80003af2 <dirlookup+0x4c>
    80003ace:	a095                	j	80003b32 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003ad0:	00004517          	auipc	a0,0x4
    80003ad4:	ac850513          	addi	a0,a0,-1336 # 80007598 <etext+0x598>
    80003ad8:	d09fc0ef          	jal	800007e0 <panic>
      panic("dirlookup read");
    80003adc:	00004517          	auipc	a0,0x4
    80003ae0:	ad450513          	addi	a0,a0,-1324 # 800075b0 <etext+0x5b0>
    80003ae4:	cfdfc0ef          	jal	800007e0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ae8:	24c1                	addiw	s1,s1,16
    80003aea:	04c92783          	lw	a5,76(s2)
    80003aee:	04f4f163          	bgeu	s1,a5,80003b30 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003af2:	4741                	li	a4,16
    80003af4:	86a6                	mv	a3,s1
    80003af6:	fc040613          	addi	a2,s0,-64
    80003afa:	4581                	li	a1,0
    80003afc:	854a                	mv	a0,s2
    80003afe:	d89ff0ef          	jal	80003886 <readi>
    80003b02:	47c1                	li	a5,16
    80003b04:	fcf51ce3          	bne	a0,a5,80003adc <dirlookup+0x36>
    if(de.inum == 0)
    80003b08:	fc045783          	lhu	a5,-64(s0)
    80003b0c:	dff1                	beqz	a5,80003ae8 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003b0e:	fc240593          	addi	a1,s0,-62
    80003b12:	854e                	mv	a0,s3
    80003b14:	f7dff0ef          	jal	80003a90 <namecmp>
    80003b18:	f961                	bnez	a0,80003ae8 <dirlookup+0x42>
      if(poff)
    80003b1a:	000a0463          	beqz	s4,80003b22 <dirlookup+0x7c>
        *poff = off;
    80003b1e:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003b22:	fc045583          	lhu	a1,-64(s0)
    80003b26:	00092503          	lw	a0,0(s2)
    80003b2a:	f58ff0ef          	jal	80003282 <iget>
    80003b2e:	a011                	j	80003b32 <dirlookup+0x8c>
  return 0;
    80003b30:	4501                	li	a0,0
}
    80003b32:	70e2                	ld	ra,56(sp)
    80003b34:	7442                	ld	s0,48(sp)
    80003b36:	74a2                	ld	s1,40(sp)
    80003b38:	7902                	ld	s2,32(sp)
    80003b3a:	69e2                	ld	s3,24(sp)
    80003b3c:	6a42                	ld	s4,16(sp)
    80003b3e:	6121                	addi	sp,sp,64
    80003b40:	8082                	ret

0000000080003b42 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003b42:	711d                	addi	sp,sp,-96
    80003b44:	ec86                	sd	ra,88(sp)
    80003b46:	e8a2                	sd	s0,80(sp)
    80003b48:	e4a6                	sd	s1,72(sp)
    80003b4a:	e0ca                	sd	s2,64(sp)
    80003b4c:	fc4e                	sd	s3,56(sp)
    80003b4e:	f852                	sd	s4,48(sp)
    80003b50:	f456                	sd	s5,40(sp)
    80003b52:	f05a                	sd	s6,32(sp)
    80003b54:	ec5e                	sd	s7,24(sp)
    80003b56:	e862                	sd	s8,16(sp)
    80003b58:	e466                	sd	s9,8(sp)
    80003b5a:	1080                	addi	s0,sp,96
    80003b5c:	84aa                	mv	s1,a0
    80003b5e:	8b2e                	mv	s6,a1
    80003b60:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003b62:	00054703          	lbu	a4,0(a0)
    80003b66:	02f00793          	li	a5,47
    80003b6a:	00f70e63          	beq	a4,a5,80003b86 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003b6e:	dc5fd0ef          	jal	80001932 <myproc>
    80003b72:	15053503          	ld	a0,336(a0)
    80003b76:	94bff0ef          	jal	800034c0 <idup>
    80003b7a:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003b7c:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003b80:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003b82:	4b85                	li	s7,1
    80003b84:	a871                	j	80003c20 <namex+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    80003b86:	4585                	li	a1,1
    80003b88:	4505                	li	a0,1
    80003b8a:	ef8ff0ef          	jal	80003282 <iget>
    80003b8e:	8a2a                	mv	s4,a0
    80003b90:	b7f5                	j	80003b7c <namex+0x3a>
      iunlockput(ip);
    80003b92:	8552                	mv	a0,s4
    80003b94:	b6dff0ef          	jal	80003700 <iunlockput>
      return 0;
    80003b98:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003b9a:	8552                	mv	a0,s4
    80003b9c:	60e6                	ld	ra,88(sp)
    80003b9e:	6446                	ld	s0,80(sp)
    80003ba0:	64a6                	ld	s1,72(sp)
    80003ba2:	6906                	ld	s2,64(sp)
    80003ba4:	79e2                	ld	s3,56(sp)
    80003ba6:	7a42                	ld	s4,48(sp)
    80003ba8:	7aa2                	ld	s5,40(sp)
    80003baa:	7b02                	ld	s6,32(sp)
    80003bac:	6be2                	ld	s7,24(sp)
    80003bae:	6c42                	ld	s8,16(sp)
    80003bb0:	6ca2                	ld	s9,8(sp)
    80003bb2:	6125                	addi	sp,sp,96
    80003bb4:	8082                	ret
      iunlock(ip);
    80003bb6:	8552                	mv	a0,s4
    80003bb8:	9edff0ef          	jal	800035a4 <iunlock>
      return ip;
    80003bbc:	bff9                	j	80003b9a <namex+0x58>
      iunlockput(ip);
    80003bbe:	8552                	mv	a0,s4
    80003bc0:	b41ff0ef          	jal	80003700 <iunlockput>
      return 0;
    80003bc4:	8a4e                	mv	s4,s3
    80003bc6:	bfd1                	j	80003b9a <namex+0x58>
  len = path - s;
    80003bc8:	40998633          	sub	a2,s3,s1
    80003bcc:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003bd0:	099c5063          	bge	s8,s9,80003c50 <namex+0x10e>
    memmove(name, s, DIRSIZ);
    80003bd4:	4639                	li	a2,14
    80003bd6:	85a6                	mv	a1,s1
    80003bd8:	8556                	mv	a0,s5
    80003bda:	924fd0ef          	jal	80000cfe <memmove>
    80003bde:	84ce                	mv	s1,s3
  while(*path == '/')
    80003be0:	0004c783          	lbu	a5,0(s1)
    80003be4:	01279763          	bne	a5,s2,80003bf2 <namex+0xb0>
    path++;
    80003be8:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003bea:	0004c783          	lbu	a5,0(s1)
    80003bee:	ff278de3          	beq	a5,s2,80003be8 <namex+0xa6>
    ilock(ip);
    80003bf2:	8552                	mv	a0,s4
    80003bf4:	903ff0ef          	jal	800034f6 <ilock>
    if(ip->type != T_DIR){
    80003bf8:	044a1783          	lh	a5,68(s4)
    80003bfc:	f9779be3          	bne	a5,s7,80003b92 <namex+0x50>
    if(nameiparent && *path == '\0'){
    80003c00:	000b0563          	beqz	s6,80003c0a <namex+0xc8>
    80003c04:	0004c783          	lbu	a5,0(s1)
    80003c08:	d7dd                	beqz	a5,80003bb6 <namex+0x74>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003c0a:	4601                	li	a2,0
    80003c0c:	85d6                	mv	a1,s5
    80003c0e:	8552                	mv	a0,s4
    80003c10:	e97ff0ef          	jal	80003aa6 <dirlookup>
    80003c14:	89aa                	mv	s3,a0
    80003c16:	d545                	beqz	a0,80003bbe <namex+0x7c>
    iunlockput(ip);
    80003c18:	8552                	mv	a0,s4
    80003c1a:	ae7ff0ef          	jal	80003700 <iunlockput>
    ip = next;
    80003c1e:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003c20:	0004c783          	lbu	a5,0(s1)
    80003c24:	01279763          	bne	a5,s2,80003c32 <namex+0xf0>
    path++;
    80003c28:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003c2a:	0004c783          	lbu	a5,0(s1)
    80003c2e:	ff278de3          	beq	a5,s2,80003c28 <namex+0xe6>
  if(*path == 0)
    80003c32:	cb8d                	beqz	a5,80003c64 <namex+0x122>
  while(*path != '/' && *path != 0)
    80003c34:	0004c783          	lbu	a5,0(s1)
    80003c38:	89a6                	mv	s3,s1
  len = path - s;
    80003c3a:	4c81                	li	s9,0
    80003c3c:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003c3e:	01278963          	beq	a5,s2,80003c50 <namex+0x10e>
    80003c42:	d3d9                	beqz	a5,80003bc8 <namex+0x86>
    path++;
    80003c44:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003c46:	0009c783          	lbu	a5,0(s3)
    80003c4a:	ff279ce3          	bne	a5,s2,80003c42 <namex+0x100>
    80003c4e:	bfad                	j	80003bc8 <namex+0x86>
    memmove(name, s, len);
    80003c50:	2601                	sext.w	a2,a2
    80003c52:	85a6                	mv	a1,s1
    80003c54:	8556                	mv	a0,s5
    80003c56:	8a8fd0ef          	jal	80000cfe <memmove>
    name[len] = 0;
    80003c5a:	9cd6                	add	s9,s9,s5
    80003c5c:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003c60:	84ce                	mv	s1,s3
    80003c62:	bfbd                	j	80003be0 <namex+0x9e>
  if(nameiparent){
    80003c64:	f20b0be3          	beqz	s6,80003b9a <namex+0x58>
    iput(ip);
    80003c68:	8552                	mv	a0,s4
    80003c6a:	a0fff0ef          	jal	80003678 <iput>
    return 0;
    80003c6e:	4a01                	li	s4,0
    80003c70:	b72d                	j	80003b9a <namex+0x58>

0000000080003c72 <dirlink>:
{
    80003c72:	7139                	addi	sp,sp,-64
    80003c74:	fc06                	sd	ra,56(sp)
    80003c76:	f822                	sd	s0,48(sp)
    80003c78:	f04a                	sd	s2,32(sp)
    80003c7a:	ec4e                	sd	s3,24(sp)
    80003c7c:	e852                	sd	s4,16(sp)
    80003c7e:	0080                	addi	s0,sp,64
    80003c80:	892a                	mv	s2,a0
    80003c82:	8a2e                	mv	s4,a1
    80003c84:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003c86:	4601                	li	a2,0
    80003c88:	e1fff0ef          	jal	80003aa6 <dirlookup>
    80003c8c:	e535                	bnez	a0,80003cf8 <dirlink+0x86>
    80003c8e:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c90:	04c92483          	lw	s1,76(s2)
    80003c94:	c48d                	beqz	s1,80003cbe <dirlink+0x4c>
    80003c96:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c98:	4741                	li	a4,16
    80003c9a:	86a6                	mv	a3,s1
    80003c9c:	fc040613          	addi	a2,s0,-64
    80003ca0:	4581                	li	a1,0
    80003ca2:	854a                	mv	a0,s2
    80003ca4:	be3ff0ef          	jal	80003886 <readi>
    80003ca8:	47c1                	li	a5,16
    80003caa:	04f51b63          	bne	a0,a5,80003d00 <dirlink+0x8e>
    if(de.inum == 0)
    80003cae:	fc045783          	lhu	a5,-64(s0)
    80003cb2:	c791                	beqz	a5,80003cbe <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cb4:	24c1                	addiw	s1,s1,16
    80003cb6:	04c92783          	lw	a5,76(s2)
    80003cba:	fcf4efe3          	bltu	s1,a5,80003c98 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003cbe:	4639                	li	a2,14
    80003cc0:	85d2                	mv	a1,s4
    80003cc2:	fc240513          	addi	a0,s0,-62
    80003cc6:	8defd0ef          	jal	80000da4 <strncpy>
  de.inum = inum;
    80003cca:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cce:	4741                	li	a4,16
    80003cd0:	86a6                	mv	a3,s1
    80003cd2:	fc040613          	addi	a2,s0,-64
    80003cd6:	4581                	li	a1,0
    80003cd8:	854a                	mv	a0,s2
    80003cda:	ca9ff0ef          	jal	80003982 <writei>
    80003cde:	1541                	addi	a0,a0,-16
    80003ce0:	00a03533          	snez	a0,a0
    80003ce4:	40a00533          	neg	a0,a0
    80003ce8:	74a2                	ld	s1,40(sp)
}
    80003cea:	70e2                	ld	ra,56(sp)
    80003cec:	7442                	ld	s0,48(sp)
    80003cee:	7902                	ld	s2,32(sp)
    80003cf0:	69e2                	ld	s3,24(sp)
    80003cf2:	6a42                	ld	s4,16(sp)
    80003cf4:	6121                	addi	sp,sp,64
    80003cf6:	8082                	ret
    iput(ip);
    80003cf8:	981ff0ef          	jal	80003678 <iput>
    return -1;
    80003cfc:	557d                	li	a0,-1
    80003cfe:	b7f5                	j	80003cea <dirlink+0x78>
      panic("dirlink read");
    80003d00:	00004517          	auipc	a0,0x4
    80003d04:	8c050513          	addi	a0,a0,-1856 # 800075c0 <etext+0x5c0>
    80003d08:	ad9fc0ef          	jal	800007e0 <panic>

0000000080003d0c <namei>:

struct inode*
namei(char *path)
{
    80003d0c:	1101                	addi	sp,sp,-32
    80003d0e:	ec06                	sd	ra,24(sp)
    80003d10:	e822                	sd	s0,16(sp)
    80003d12:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003d14:	fe040613          	addi	a2,s0,-32
    80003d18:	4581                	li	a1,0
    80003d1a:	e29ff0ef          	jal	80003b42 <namex>
}
    80003d1e:	60e2                	ld	ra,24(sp)
    80003d20:	6442                	ld	s0,16(sp)
    80003d22:	6105                	addi	sp,sp,32
    80003d24:	8082                	ret

0000000080003d26 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003d26:	1141                	addi	sp,sp,-16
    80003d28:	e406                	sd	ra,8(sp)
    80003d2a:	e022                	sd	s0,0(sp)
    80003d2c:	0800                	addi	s0,sp,16
    80003d2e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003d30:	4585                	li	a1,1
    80003d32:	e11ff0ef          	jal	80003b42 <namex>
}
    80003d36:	60a2                	ld	ra,8(sp)
    80003d38:	6402                	ld	s0,0(sp)
    80003d3a:	0141                	addi	sp,sp,16
    80003d3c:	8082                	ret

0000000080003d3e <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003d3e:	1101                	addi	sp,sp,-32
    80003d40:	ec06                	sd	ra,24(sp)
    80003d42:	e822                	sd	s0,16(sp)
    80003d44:	e426                	sd	s1,8(sp)
    80003d46:	e04a                	sd	s2,0(sp)
    80003d48:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003d4a:	0001c917          	auipc	s2,0x1c
    80003d4e:	24e90913          	addi	s2,s2,590 # 8001ff98 <log>
    80003d52:	01892583          	lw	a1,24(s2)
    80003d56:	02492503          	lw	a0,36(s2)
    80003d5a:	8d0ff0ef          	jal	80002e2a <bread>
    80003d5e:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003d60:	02892603          	lw	a2,40(s2)
    80003d64:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003d66:	00c05f63          	blez	a2,80003d84 <write_head+0x46>
    80003d6a:	0001c717          	auipc	a4,0x1c
    80003d6e:	25a70713          	addi	a4,a4,602 # 8001ffc4 <log+0x2c>
    80003d72:	87aa                	mv	a5,a0
    80003d74:	060a                	slli	a2,a2,0x2
    80003d76:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003d78:	4314                	lw	a3,0(a4)
    80003d7a:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003d7c:	0711                	addi	a4,a4,4
    80003d7e:	0791                	addi	a5,a5,4
    80003d80:	fec79ce3          	bne	a5,a2,80003d78 <write_head+0x3a>
  }
  bwrite(buf);
    80003d84:	8526                	mv	a0,s1
    80003d86:	97aff0ef          	jal	80002f00 <bwrite>
  brelse(buf);
    80003d8a:	8526                	mv	a0,s1
    80003d8c:	9a6ff0ef          	jal	80002f32 <brelse>
}
    80003d90:	60e2                	ld	ra,24(sp)
    80003d92:	6442                	ld	s0,16(sp)
    80003d94:	64a2                	ld	s1,8(sp)
    80003d96:	6902                	ld	s2,0(sp)
    80003d98:	6105                	addi	sp,sp,32
    80003d9a:	8082                	ret

0000000080003d9c <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d9c:	0001c797          	auipc	a5,0x1c
    80003da0:	2247a783          	lw	a5,548(a5) # 8001ffc0 <log+0x28>
    80003da4:	0af05e63          	blez	a5,80003e60 <install_trans+0xc4>
{
    80003da8:	715d                	addi	sp,sp,-80
    80003daa:	e486                	sd	ra,72(sp)
    80003dac:	e0a2                	sd	s0,64(sp)
    80003dae:	fc26                	sd	s1,56(sp)
    80003db0:	f84a                	sd	s2,48(sp)
    80003db2:	f44e                	sd	s3,40(sp)
    80003db4:	f052                	sd	s4,32(sp)
    80003db6:	ec56                	sd	s5,24(sp)
    80003db8:	e85a                	sd	s6,16(sp)
    80003dba:	e45e                	sd	s7,8(sp)
    80003dbc:	0880                	addi	s0,sp,80
    80003dbe:	8b2a                	mv	s6,a0
    80003dc0:	0001ca97          	auipc	s5,0x1c
    80003dc4:	204a8a93          	addi	s5,s5,516 # 8001ffc4 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003dc8:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003dca:	00004b97          	auipc	s7,0x4
    80003dce:	806b8b93          	addi	s7,s7,-2042 # 800075d0 <etext+0x5d0>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003dd2:	0001ca17          	auipc	s4,0x1c
    80003dd6:	1c6a0a13          	addi	s4,s4,454 # 8001ff98 <log>
    80003dda:	a025                	j	80003e02 <install_trans+0x66>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003ddc:	000aa603          	lw	a2,0(s5)
    80003de0:	85ce                	mv	a1,s3
    80003de2:	855e                	mv	a0,s7
    80003de4:	f16fc0ef          	jal	800004fa <printf>
    80003de8:	a839                	j	80003e06 <install_trans+0x6a>
    brelse(lbuf);
    80003dea:	854a                	mv	a0,s2
    80003dec:	946ff0ef          	jal	80002f32 <brelse>
    brelse(dbuf);
    80003df0:	8526                	mv	a0,s1
    80003df2:	940ff0ef          	jal	80002f32 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003df6:	2985                	addiw	s3,s3,1
    80003df8:	0a91                	addi	s5,s5,4
    80003dfa:	028a2783          	lw	a5,40(s4)
    80003dfe:	04f9d663          	bge	s3,a5,80003e4a <install_trans+0xae>
    if(recovering) {
    80003e02:	fc0b1de3          	bnez	s6,80003ddc <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003e06:	018a2583          	lw	a1,24(s4)
    80003e0a:	013585bb          	addw	a1,a1,s3
    80003e0e:	2585                	addiw	a1,a1,1
    80003e10:	024a2503          	lw	a0,36(s4)
    80003e14:	816ff0ef          	jal	80002e2a <bread>
    80003e18:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003e1a:	000aa583          	lw	a1,0(s5)
    80003e1e:	024a2503          	lw	a0,36(s4)
    80003e22:	808ff0ef          	jal	80002e2a <bread>
    80003e26:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003e28:	40000613          	li	a2,1024
    80003e2c:	05890593          	addi	a1,s2,88
    80003e30:	05850513          	addi	a0,a0,88
    80003e34:	ecbfc0ef          	jal	80000cfe <memmove>
    bwrite(dbuf);  // write dst to disk
    80003e38:	8526                	mv	a0,s1
    80003e3a:	8c6ff0ef          	jal	80002f00 <bwrite>
    if(recovering == 0)
    80003e3e:	fa0b16e3          	bnez	s6,80003dea <install_trans+0x4e>
      bunpin(dbuf);
    80003e42:	8526                	mv	a0,s1
    80003e44:	9aaff0ef          	jal	80002fee <bunpin>
    80003e48:	b74d                	j	80003dea <install_trans+0x4e>
}
    80003e4a:	60a6                	ld	ra,72(sp)
    80003e4c:	6406                	ld	s0,64(sp)
    80003e4e:	74e2                	ld	s1,56(sp)
    80003e50:	7942                	ld	s2,48(sp)
    80003e52:	79a2                	ld	s3,40(sp)
    80003e54:	7a02                	ld	s4,32(sp)
    80003e56:	6ae2                	ld	s5,24(sp)
    80003e58:	6b42                	ld	s6,16(sp)
    80003e5a:	6ba2                	ld	s7,8(sp)
    80003e5c:	6161                	addi	sp,sp,80
    80003e5e:	8082                	ret
    80003e60:	8082                	ret

0000000080003e62 <initlog>:
{
    80003e62:	7179                	addi	sp,sp,-48
    80003e64:	f406                	sd	ra,40(sp)
    80003e66:	f022                	sd	s0,32(sp)
    80003e68:	ec26                	sd	s1,24(sp)
    80003e6a:	e84a                	sd	s2,16(sp)
    80003e6c:	e44e                	sd	s3,8(sp)
    80003e6e:	1800                	addi	s0,sp,48
    80003e70:	892a                	mv	s2,a0
    80003e72:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003e74:	0001c497          	auipc	s1,0x1c
    80003e78:	12448493          	addi	s1,s1,292 # 8001ff98 <log>
    80003e7c:	00003597          	auipc	a1,0x3
    80003e80:	77458593          	addi	a1,a1,1908 # 800075f0 <etext+0x5f0>
    80003e84:	8526                	mv	a0,s1
    80003e86:	cc9fc0ef          	jal	80000b4e <initlock>
  log.start = sb->logstart;
    80003e8a:	0149a583          	lw	a1,20(s3)
    80003e8e:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003e90:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003e94:	854a                	mv	a0,s2
    80003e96:	f95fe0ef          	jal	80002e2a <bread>
  log.lh.n = lh->n;
    80003e9a:	4d30                	lw	a2,88(a0)
    80003e9c:	d490                	sw	a2,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003e9e:	00c05f63          	blez	a2,80003ebc <initlog+0x5a>
    80003ea2:	87aa                	mv	a5,a0
    80003ea4:	0001c717          	auipc	a4,0x1c
    80003ea8:	12070713          	addi	a4,a4,288 # 8001ffc4 <log+0x2c>
    80003eac:	060a                	slli	a2,a2,0x2
    80003eae:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003eb0:	4ff4                	lw	a3,92(a5)
    80003eb2:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003eb4:	0791                	addi	a5,a5,4
    80003eb6:	0711                	addi	a4,a4,4
    80003eb8:	fec79ce3          	bne	a5,a2,80003eb0 <initlog+0x4e>
  brelse(buf);
    80003ebc:	876ff0ef          	jal	80002f32 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003ec0:	4505                	li	a0,1
    80003ec2:	edbff0ef          	jal	80003d9c <install_trans>
  log.lh.n = 0;
    80003ec6:	0001c797          	auipc	a5,0x1c
    80003eca:	0e07ad23          	sw	zero,250(a5) # 8001ffc0 <log+0x28>
  write_head(); // clear the log
    80003ece:	e71ff0ef          	jal	80003d3e <write_head>
}
    80003ed2:	70a2                	ld	ra,40(sp)
    80003ed4:	7402                	ld	s0,32(sp)
    80003ed6:	64e2                	ld	s1,24(sp)
    80003ed8:	6942                	ld	s2,16(sp)
    80003eda:	69a2                	ld	s3,8(sp)
    80003edc:	6145                	addi	sp,sp,48
    80003ede:	8082                	ret

0000000080003ee0 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003ee0:	1101                	addi	sp,sp,-32
    80003ee2:	ec06                	sd	ra,24(sp)
    80003ee4:	e822                	sd	s0,16(sp)
    80003ee6:	e426                	sd	s1,8(sp)
    80003ee8:	e04a                	sd	s2,0(sp)
    80003eea:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003eec:	0001c517          	auipc	a0,0x1c
    80003ef0:	0ac50513          	addi	a0,a0,172 # 8001ff98 <log>
    80003ef4:	cdbfc0ef          	jal	80000bce <acquire>
  while(1){
    if(log.committing){
    80003ef8:	0001c497          	auipc	s1,0x1c
    80003efc:	0a048493          	addi	s1,s1,160 # 8001ff98 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003f00:	4979                	li	s2,30
    80003f02:	a029                	j	80003f0c <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003f04:	85a6                	mv	a1,s1
    80003f06:	8526                	mv	a0,s1
    80003f08:	88efe0ef          	jal	80001f96 <sleep>
    if(log.committing){
    80003f0c:	509c                	lw	a5,32(s1)
    80003f0e:	fbfd                	bnez	a5,80003f04 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003f10:	4cd8                	lw	a4,28(s1)
    80003f12:	2705                	addiw	a4,a4,1
    80003f14:	0027179b          	slliw	a5,a4,0x2
    80003f18:	9fb9                	addw	a5,a5,a4
    80003f1a:	0017979b          	slliw	a5,a5,0x1
    80003f1e:	5494                	lw	a3,40(s1)
    80003f20:	9fb5                	addw	a5,a5,a3
    80003f22:	00f95763          	bge	s2,a5,80003f30 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003f26:	85a6                	mv	a1,s1
    80003f28:	8526                	mv	a0,s1
    80003f2a:	86cfe0ef          	jal	80001f96 <sleep>
    80003f2e:	bff9                	j	80003f0c <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003f30:	0001c517          	auipc	a0,0x1c
    80003f34:	06850513          	addi	a0,a0,104 # 8001ff98 <log>
    80003f38:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003f3a:	d2dfc0ef          	jal	80000c66 <release>
      break;
    }
  }
}
    80003f3e:	60e2                	ld	ra,24(sp)
    80003f40:	6442                	ld	s0,16(sp)
    80003f42:	64a2                	ld	s1,8(sp)
    80003f44:	6902                	ld	s2,0(sp)
    80003f46:	6105                	addi	sp,sp,32
    80003f48:	8082                	ret

0000000080003f4a <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003f4a:	7139                	addi	sp,sp,-64
    80003f4c:	fc06                	sd	ra,56(sp)
    80003f4e:	f822                	sd	s0,48(sp)
    80003f50:	f426                	sd	s1,40(sp)
    80003f52:	f04a                	sd	s2,32(sp)
    80003f54:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003f56:	0001c497          	auipc	s1,0x1c
    80003f5a:	04248493          	addi	s1,s1,66 # 8001ff98 <log>
    80003f5e:	8526                	mv	a0,s1
    80003f60:	c6ffc0ef          	jal	80000bce <acquire>
  log.outstanding -= 1;
    80003f64:	4cdc                	lw	a5,28(s1)
    80003f66:	37fd                	addiw	a5,a5,-1
    80003f68:	0007891b          	sext.w	s2,a5
    80003f6c:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003f6e:	509c                	lw	a5,32(s1)
    80003f70:	ef9d                	bnez	a5,80003fae <end_op+0x64>
    panic("log.committing");
  if(log.outstanding == 0){
    80003f72:	04091763          	bnez	s2,80003fc0 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003f76:	0001c497          	auipc	s1,0x1c
    80003f7a:	02248493          	addi	s1,s1,34 # 8001ff98 <log>
    80003f7e:	4785                	li	a5,1
    80003f80:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003f82:	8526                	mv	a0,s1
    80003f84:	ce3fc0ef          	jal	80000c66 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003f88:	549c                	lw	a5,40(s1)
    80003f8a:	04f04b63          	bgtz	a5,80003fe0 <end_op+0x96>
    acquire(&log.lock);
    80003f8e:	0001c497          	auipc	s1,0x1c
    80003f92:	00a48493          	addi	s1,s1,10 # 8001ff98 <log>
    80003f96:	8526                	mv	a0,s1
    80003f98:	c37fc0ef          	jal	80000bce <acquire>
    log.committing = 0;
    80003f9c:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    80003fa0:	8526                	mv	a0,s1
    80003fa2:	840fe0ef          	jal	80001fe2 <wakeup>
    release(&log.lock);
    80003fa6:	8526                	mv	a0,s1
    80003fa8:	cbffc0ef          	jal	80000c66 <release>
}
    80003fac:	a025                	j	80003fd4 <end_op+0x8a>
    80003fae:	ec4e                	sd	s3,24(sp)
    80003fb0:	e852                	sd	s4,16(sp)
    80003fb2:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003fb4:	00003517          	auipc	a0,0x3
    80003fb8:	64450513          	addi	a0,a0,1604 # 800075f8 <etext+0x5f8>
    80003fbc:	825fc0ef          	jal	800007e0 <panic>
    wakeup(&log);
    80003fc0:	0001c497          	auipc	s1,0x1c
    80003fc4:	fd848493          	addi	s1,s1,-40 # 8001ff98 <log>
    80003fc8:	8526                	mv	a0,s1
    80003fca:	818fe0ef          	jal	80001fe2 <wakeup>
  release(&log.lock);
    80003fce:	8526                	mv	a0,s1
    80003fd0:	c97fc0ef          	jal	80000c66 <release>
}
    80003fd4:	70e2                	ld	ra,56(sp)
    80003fd6:	7442                	ld	s0,48(sp)
    80003fd8:	74a2                	ld	s1,40(sp)
    80003fda:	7902                	ld	s2,32(sp)
    80003fdc:	6121                	addi	sp,sp,64
    80003fde:	8082                	ret
    80003fe0:	ec4e                	sd	s3,24(sp)
    80003fe2:	e852                	sd	s4,16(sp)
    80003fe4:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fe6:	0001ca97          	auipc	s5,0x1c
    80003fea:	fdea8a93          	addi	s5,s5,-34 # 8001ffc4 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003fee:	0001ca17          	auipc	s4,0x1c
    80003ff2:	faaa0a13          	addi	s4,s4,-86 # 8001ff98 <log>
    80003ff6:	018a2583          	lw	a1,24(s4)
    80003ffa:	012585bb          	addw	a1,a1,s2
    80003ffe:	2585                	addiw	a1,a1,1
    80004000:	024a2503          	lw	a0,36(s4)
    80004004:	e27fe0ef          	jal	80002e2a <bread>
    80004008:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000400a:	000aa583          	lw	a1,0(s5)
    8000400e:	024a2503          	lw	a0,36(s4)
    80004012:	e19fe0ef          	jal	80002e2a <bread>
    80004016:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004018:	40000613          	li	a2,1024
    8000401c:	05850593          	addi	a1,a0,88
    80004020:	05848513          	addi	a0,s1,88
    80004024:	cdbfc0ef          	jal	80000cfe <memmove>
    bwrite(to);  // write the log
    80004028:	8526                	mv	a0,s1
    8000402a:	ed7fe0ef          	jal	80002f00 <bwrite>
    brelse(from);
    8000402e:	854e                	mv	a0,s3
    80004030:	f03fe0ef          	jal	80002f32 <brelse>
    brelse(to);
    80004034:	8526                	mv	a0,s1
    80004036:	efdfe0ef          	jal	80002f32 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000403a:	2905                	addiw	s2,s2,1
    8000403c:	0a91                	addi	s5,s5,4
    8000403e:	028a2783          	lw	a5,40(s4)
    80004042:	faf94ae3          	blt	s2,a5,80003ff6 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004046:	cf9ff0ef          	jal	80003d3e <write_head>
    install_trans(0); // Now install writes to home locations
    8000404a:	4501                	li	a0,0
    8000404c:	d51ff0ef          	jal	80003d9c <install_trans>
    log.lh.n = 0;
    80004050:	0001c797          	auipc	a5,0x1c
    80004054:	f607a823          	sw	zero,-144(a5) # 8001ffc0 <log+0x28>
    write_head();    // Erase the transaction from the log
    80004058:	ce7ff0ef          	jal	80003d3e <write_head>
    8000405c:	69e2                	ld	s3,24(sp)
    8000405e:	6a42                	ld	s4,16(sp)
    80004060:	6aa2                	ld	s5,8(sp)
    80004062:	b735                	j	80003f8e <end_op+0x44>

0000000080004064 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004064:	1101                	addi	sp,sp,-32
    80004066:	ec06                	sd	ra,24(sp)
    80004068:	e822                	sd	s0,16(sp)
    8000406a:	e426                	sd	s1,8(sp)
    8000406c:	e04a                	sd	s2,0(sp)
    8000406e:	1000                	addi	s0,sp,32
    80004070:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004072:	0001c917          	auipc	s2,0x1c
    80004076:	f2690913          	addi	s2,s2,-218 # 8001ff98 <log>
    8000407a:	854a                	mv	a0,s2
    8000407c:	b53fc0ef          	jal	80000bce <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004080:	02892603          	lw	a2,40(s2)
    80004084:	47f5                	li	a5,29
    80004086:	04c7cc63          	blt	a5,a2,800040de <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000408a:	0001c797          	auipc	a5,0x1c
    8000408e:	f2a7a783          	lw	a5,-214(a5) # 8001ffb4 <log+0x1c>
    80004092:	04f05c63          	blez	a5,800040ea <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004096:	4781                	li	a5,0
    80004098:	04c05f63          	blez	a2,800040f6 <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000409c:	44cc                	lw	a1,12(s1)
    8000409e:	0001c717          	auipc	a4,0x1c
    800040a2:	f2670713          	addi	a4,a4,-218 # 8001ffc4 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    800040a6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800040a8:	4314                	lw	a3,0(a4)
    800040aa:	04b68663          	beq	a3,a1,800040f6 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    800040ae:	2785                	addiw	a5,a5,1
    800040b0:	0711                	addi	a4,a4,4
    800040b2:	fef61be3          	bne	a2,a5,800040a8 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800040b6:	0621                	addi	a2,a2,8
    800040b8:	060a                	slli	a2,a2,0x2
    800040ba:	0001c797          	auipc	a5,0x1c
    800040be:	ede78793          	addi	a5,a5,-290 # 8001ff98 <log>
    800040c2:	97b2                	add	a5,a5,a2
    800040c4:	44d8                	lw	a4,12(s1)
    800040c6:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800040c8:	8526                	mv	a0,s1
    800040ca:	ef1fe0ef          	jal	80002fba <bpin>
    log.lh.n++;
    800040ce:	0001c717          	auipc	a4,0x1c
    800040d2:	eca70713          	addi	a4,a4,-310 # 8001ff98 <log>
    800040d6:	571c                	lw	a5,40(a4)
    800040d8:	2785                	addiw	a5,a5,1
    800040da:	d71c                	sw	a5,40(a4)
    800040dc:	a80d                	j	8000410e <log_write+0xaa>
    panic("too big a transaction");
    800040de:	00003517          	auipc	a0,0x3
    800040e2:	52a50513          	addi	a0,a0,1322 # 80007608 <etext+0x608>
    800040e6:	efafc0ef          	jal	800007e0 <panic>
    panic("log_write outside of trans");
    800040ea:	00003517          	auipc	a0,0x3
    800040ee:	53650513          	addi	a0,a0,1334 # 80007620 <etext+0x620>
    800040f2:	eeefc0ef          	jal	800007e0 <panic>
  log.lh.block[i] = b->blockno;
    800040f6:	00878693          	addi	a3,a5,8
    800040fa:	068a                	slli	a3,a3,0x2
    800040fc:	0001c717          	auipc	a4,0x1c
    80004100:	e9c70713          	addi	a4,a4,-356 # 8001ff98 <log>
    80004104:	9736                	add	a4,a4,a3
    80004106:	44d4                	lw	a3,12(s1)
    80004108:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000410a:	faf60fe3          	beq	a2,a5,800040c8 <log_write+0x64>
  }
  release(&log.lock);
    8000410e:	0001c517          	auipc	a0,0x1c
    80004112:	e8a50513          	addi	a0,a0,-374 # 8001ff98 <log>
    80004116:	b51fc0ef          	jal	80000c66 <release>
}
    8000411a:	60e2                	ld	ra,24(sp)
    8000411c:	6442                	ld	s0,16(sp)
    8000411e:	64a2                	ld	s1,8(sp)
    80004120:	6902                	ld	s2,0(sp)
    80004122:	6105                	addi	sp,sp,32
    80004124:	8082                	ret

0000000080004126 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004126:	1101                	addi	sp,sp,-32
    80004128:	ec06                	sd	ra,24(sp)
    8000412a:	e822                	sd	s0,16(sp)
    8000412c:	e426                	sd	s1,8(sp)
    8000412e:	e04a                	sd	s2,0(sp)
    80004130:	1000                	addi	s0,sp,32
    80004132:	84aa                	mv	s1,a0
    80004134:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004136:	00003597          	auipc	a1,0x3
    8000413a:	50a58593          	addi	a1,a1,1290 # 80007640 <etext+0x640>
    8000413e:	0521                	addi	a0,a0,8
    80004140:	a0ffc0ef          	jal	80000b4e <initlock>
  lk->name = name;
    80004144:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004148:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000414c:	0204a423          	sw	zero,40(s1)
}
    80004150:	60e2                	ld	ra,24(sp)
    80004152:	6442                	ld	s0,16(sp)
    80004154:	64a2                	ld	s1,8(sp)
    80004156:	6902                	ld	s2,0(sp)
    80004158:	6105                	addi	sp,sp,32
    8000415a:	8082                	ret

000000008000415c <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000415c:	1101                	addi	sp,sp,-32
    8000415e:	ec06                	sd	ra,24(sp)
    80004160:	e822                	sd	s0,16(sp)
    80004162:	e426                	sd	s1,8(sp)
    80004164:	e04a                	sd	s2,0(sp)
    80004166:	1000                	addi	s0,sp,32
    80004168:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000416a:	00850913          	addi	s2,a0,8
    8000416e:	854a                	mv	a0,s2
    80004170:	a5ffc0ef          	jal	80000bce <acquire>
  while (lk->locked) {
    80004174:	409c                	lw	a5,0(s1)
    80004176:	c799                	beqz	a5,80004184 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80004178:	85ca                	mv	a1,s2
    8000417a:	8526                	mv	a0,s1
    8000417c:	e1bfd0ef          	jal	80001f96 <sleep>
  while (lk->locked) {
    80004180:	409c                	lw	a5,0(s1)
    80004182:	fbfd                	bnez	a5,80004178 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004184:	4785                	li	a5,1
    80004186:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004188:	faafd0ef          	jal	80001932 <myproc>
    8000418c:	591c                	lw	a5,48(a0)
    8000418e:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004190:	854a                	mv	a0,s2
    80004192:	ad5fc0ef          	jal	80000c66 <release>
}
    80004196:	60e2                	ld	ra,24(sp)
    80004198:	6442                	ld	s0,16(sp)
    8000419a:	64a2                	ld	s1,8(sp)
    8000419c:	6902                	ld	s2,0(sp)
    8000419e:	6105                	addi	sp,sp,32
    800041a0:	8082                	ret

00000000800041a2 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800041a2:	1101                	addi	sp,sp,-32
    800041a4:	ec06                	sd	ra,24(sp)
    800041a6:	e822                	sd	s0,16(sp)
    800041a8:	e426                	sd	s1,8(sp)
    800041aa:	e04a                	sd	s2,0(sp)
    800041ac:	1000                	addi	s0,sp,32
    800041ae:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800041b0:	00850913          	addi	s2,a0,8
    800041b4:	854a                	mv	a0,s2
    800041b6:	a19fc0ef          	jal	80000bce <acquire>
  lk->locked = 0;
    800041ba:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800041be:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800041c2:	8526                	mv	a0,s1
    800041c4:	e1ffd0ef          	jal	80001fe2 <wakeup>
  release(&lk->lk);
    800041c8:	854a                	mv	a0,s2
    800041ca:	a9dfc0ef          	jal	80000c66 <release>
}
    800041ce:	60e2                	ld	ra,24(sp)
    800041d0:	6442                	ld	s0,16(sp)
    800041d2:	64a2                	ld	s1,8(sp)
    800041d4:	6902                	ld	s2,0(sp)
    800041d6:	6105                	addi	sp,sp,32
    800041d8:	8082                	ret

00000000800041da <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800041da:	7179                	addi	sp,sp,-48
    800041dc:	f406                	sd	ra,40(sp)
    800041de:	f022                	sd	s0,32(sp)
    800041e0:	ec26                	sd	s1,24(sp)
    800041e2:	e84a                	sd	s2,16(sp)
    800041e4:	1800                	addi	s0,sp,48
    800041e6:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800041e8:	00850913          	addi	s2,a0,8
    800041ec:	854a                	mv	a0,s2
    800041ee:	9e1fc0ef          	jal	80000bce <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800041f2:	409c                	lw	a5,0(s1)
    800041f4:	ef81                	bnez	a5,8000420c <holdingsleep+0x32>
    800041f6:	4481                	li	s1,0
  release(&lk->lk);
    800041f8:	854a                	mv	a0,s2
    800041fa:	a6dfc0ef          	jal	80000c66 <release>
  return r;
}
    800041fe:	8526                	mv	a0,s1
    80004200:	70a2                	ld	ra,40(sp)
    80004202:	7402                	ld	s0,32(sp)
    80004204:	64e2                	ld	s1,24(sp)
    80004206:	6942                	ld	s2,16(sp)
    80004208:	6145                	addi	sp,sp,48
    8000420a:	8082                	ret
    8000420c:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000420e:	0284a983          	lw	s3,40(s1)
    80004212:	f20fd0ef          	jal	80001932 <myproc>
    80004216:	5904                	lw	s1,48(a0)
    80004218:	413484b3          	sub	s1,s1,s3
    8000421c:	0014b493          	seqz	s1,s1
    80004220:	69a2                	ld	s3,8(sp)
    80004222:	bfd9                	j	800041f8 <holdingsleep+0x1e>

0000000080004224 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004224:	1141                	addi	sp,sp,-16
    80004226:	e406                	sd	ra,8(sp)
    80004228:	e022                	sd	s0,0(sp)
    8000422a:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000422c:	00003597          	auipc	a1,0x3
    80004230:	42458593          	addi	a1,a1,1060 # 80007650 <etext+0x650>
    80004234:	0001c517          	auipc	a0,0x1c
    80004238:	eac50513          	addi	a0,a0,-340 # 800200e0 <ftable>
    8000423c:	913fc0ef          	jal	80000b4e <initlock>
}
    80004240:	60a2                	ld	ra,8(sp)
    80004242:	6402                	ld	s0,0(sp)
    80004244:	0141                	addi	sp,sp,16
    80004246:	8082                	ret

0000000080004248 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004248:	1101                	addi	sp,sp,-32
    8000424a:	ec06                	sd	ra,24(sp)
    8000424c:	e822                	sd	s0,16(sp)
    8000424e:	e426                	sd	s1,8(sp)
    80004250:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004252:	0001c517          	auipc	a0,0x1c
    80004256:	e8e50513          	addi	a0,a0,-370 # 800200e0 <ftable>
    8000425a:	975fc0ef          	jal	80000bce <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000425e:	0001c497          	auipc	s1,0x1c
    80004262:	e9a48493          	addi	s1,s1,-358 # 800200f8 <ftable+0x18>
    80004266:	0001d717          	auipc	a4,0x1d
    8000426a:	e3270713          	addi	a4,a4,-462 # 80021098 <disk>
    if(f->ref == 0){
    8000426e:	40dc                	lw	a5,4(s1)
    80004270:	cf89                	beqz	a5,8000428a <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004272:	02848493          	addi	s1,s1,40
    80004276:	fee49ce3          	bne	s1,a4,8000426e <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000427a:	0001c517          	auipc	a0,0x1c
    8000427e:	e6650513          	addi	a0,a0,-410 # 800200e0 <ftable>
    80004282:	9e5fc0ef          	jal	80000c66 <release>
  return 0;
    80004286:	4481                	li	s1,0
    80004288:	a809                	j	8000429a <filealloc+0x52>
      f->ref = 1;
    8000428a:	4785                	li	a5,1
    8000428c:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000428e:	0001c517          	auipc	a0,0x1c
    80004292:	e5250513          	addi	a0,a0,-430 # 800200e0 <ftable>
    80004296:	9d1fc0ef          	jal	80000c66 <release>
}
    8000429a:	8526                	mv	a0,s1
    8000429c:	60e2                	ld	ra,24(sp)
    8000429e:	6442                	ld	s0,16(sp)
    800042a0:	64a2                	ld	s1,8(sp)
    800042a2:	6105                	addi	sp,sp,32
    800042a4:	8082                	ret

00000000800042a6 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800042a6:	1101                	addi	sp,sp,-32
    800042a8:	ec06                	sd	ra,24(sp)
    800042aa:	e822                	sd	s0,16(sp)
    800042ac:	e426                	sd	s1,8(sp)
    800042ae:	1000                	addi	s0,sp,32
    800042b0:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800042b2:	0001c517          	auipc	a0,0x1c
    800042b6:	e2e50513          	addi	a0,a0,-466 # 800200e0 <ftable>
    800042ba:	915fc0ef          	jal	80000bce <acquire>
  if(f->ref < 1)
    800042be:	40dc                	lw	a5,4(s1)
    800042c0:	02f05063          	blez	a5,800042e0 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800042c4:	2785                	addiw	a5,a5,1
    800042c6:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800042c8:	0001c517          	auipc	a0,0x1c
    800042cc:	e1850513          	addi	a0,a0,-488 # 800200e0 <ftable>
    800042d0:	997fc0ef          	jal	80000c66 <release>
  return f;
}
    800042d4:	8526                	mv	a0,s1
    800042d6:	60e2                	ld	ra,24(sp)
    800042d8:	6442                	ld	s0,16(sp)
    800042da:	64a2                	ld	s1,8(sp)
    800042dc:	6105                	addi	sp,sp,32
    800042de:	8082                	ret
    panic("filedup");
    800042e0:	00003517          	auipc	a0,0x3
    800042e4:	37850513          	addi	a0,a0,888 # 80007658 <etext+0x658>
    800042e8:	cf8fc0ef          	jal	800007e0 <panic>

00000000800042ec <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800042ec:	7139                	addi	sp,sp,-64
    800042ee:	fc06                	sd	ra,56(sp)
    800042f0:	f822                	sd	s0,48(sp)
    800042f2:	f426                	sd	s1,40(sp)
    800042f4:	0080                	addi	s0,sp,64
    800042f6:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800042f8:	0001c517          	auipc	a0,0x1c
    800042fc:	de850513          	addi	a0,a0,-536 # 800200e0 <ftable>
    80004300:	8cffc0ef          	jal	80000bce <acquire>
  if(f->ref < 1)
    80004304:	40dc                	lw	a5,4(s1)
    80004306:	04f05a63          	blez	a5,8000435a <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000430a:	37fd                	addiw	a5,a5,-1
    8000430c:	0007871b          	sext.w	a4,a5
    80004310:	c0dc                	sw	a5,4(s1)
    80004312:	04e04e63          	bgtz	a4,8000436e <fileclose+0x82>
    80004316:	f04a                	sd	s2,32(sp)
    80004318:	ec4e                	sd	s3,24(sp)
    8000431a:	e852                	sd	s4,16(sp)
    8000431c:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000431e:	0004a903          	lw	s2,0(s1)
    80004322:	0094ca83          	lbu	s5,9(s1)
    80004326:	0104ba03          	ld	s4,16(s1)
    8000432a:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000432e:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004332:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004336:	0001c517          	auipc	a0,0x1c
    8000433a:	daa50513          	addi	a0,a0,-598 # 800200e0 <ftable>
    8000433e:	929fc0ef          	jal	80000c66 <release>

  if(ff.type == FD_PIPE){
    80004342:	4785                	li	a5,1
    80004344:	04f90063          	beq	s2,a5,80004384 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004348:	3979                	addiw	s2,s2,-2
    8000434a:	4785                	li	a5,1
    8000434c:	0527f563          	bgeu	a5,s2,80004396 <fileclose+0xaa>
    80004350:	7902                	ld	s2,32(sp)
    80004352:	69e2                	ld	s3,24(sp)
    80004354:	6a42                	ld	s4,16(sp)
    80004356:	6aa2                	ld	s5,8(sp)
    80004358:	a00d                	j	8000437a <fileclose+0x8e>
    8000435a:	f04a                	sd	s2,32(sp)
    8000435c:	ec4e                	sd	s3,24(sp)
    8000435e:	e852                	sd	s4,16(sp)
    80004360:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004362:	00003517          	auipc	a0,0x3
    80004366:	2fe50513          	addi	a0,a0,766 # 80007660 <etext+0x660>
    8000436a:	c76fc0ef          	jal	800007e0 <panic>
    release(&ftable.lock);
    8000436e:	0001c517          	auipc	a0,0x1c
    80004372:	d7250513          	addi	a0,a0,-654 # 800200e0 <ftable>
    80004376:	8f1fc0ef          	jal	80000c66 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000437a:	70e2                	ld	ra,56(sp)
    8000437c:	7442                	ld	s0,48(sp)
    8000437e:	74a2                	ld	s1,40(sp)
    80004380:	6121                	addi	sp,sp,64
    80004382:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004384:	85d6                	mv	a1,s5
    80004386:	8552                	mv	a0,s4
    80004388:	336000ef          	jal	800046be <pipeclose>
    8000438c:	7902                	ld	s2,32(sp)
    8000438e:	69e2                	ld	s3,24(sp)
    80004390:	6a42                	ld	s4,16(sp)
    80004392:	6aa2                	ld	s5,8(sp)
    80004394:	b7dd                	j	8000437a <fileclose+0x8e>
    begin_op();
    80004396:	b4bff0ef          	jal	80003ee0 <begin_op>
    iput(ff.ip);
    8000439a:	854e                	mv	a0,s3
    8000439c:	adcff0ef          	jal	80003678 <iput>
    end_op();
    800043a0:	babff0ef          	jal	80003f4a <end_op>
    800043a4:	7902                	ld	s2,32(sp)
    800043a6:	69e2                	ld	s3,24(sp)
    800043a8:	6a42                	ld	s4,16(sp)
    800043aa:	6aa2                	ld	s5,8(sp)
    800043ac:	b7f9                	j	8000437a <fileclose+0x8e>

00000000800043ae <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800043ae:	715d                	addi	sp,sp,-80
    800043b0:	e486                	sd	ra,72(sp)
    800043b2:	e0a2                	sd	s0,64(sp)
    800043b4:	fc26                	sd	s1,56(sp)
    800043b6:	f44e                	sd	s3,40(sp)
    800043b8:	0880                	addi	s0,sp,80
    800043ba:	84aa                	mv	s1,a0
    800043bc:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800043be:	d74fd0ef          	jal	80001932 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800043c2:	409c                	lw	a5,0(s1)
    800043c4:	37f9                	addiw	a5,a5,-2
    800043c6:	4705                	li	a4,1
    800043c8:	04f76063          	bltu	a4,a5,80004408 <filestat+0x5a>
    800043cc:	f84a                	sd	s2,48(sp)
    800043ce:	892a                	mv	s2,a0
    ilock(f->ip);
    800043d0:	6c88                	ld	a0,24(s1)
    800043d2:	924ff0ef          	jal	800034f6 <ilock>
    stati(f->ip, &st);
    800043d6:	fb840593          	addi	a1,s0,-72
    800043da:	6c88                	ld	a0,24(s1)
    800043dc:	c80ff0ef          	jal	8000385c <stati>
    iunlock(f->ip);
    800043e0:	6c88                	ld	a0,24(s1)
    800043e2:	9c2ff0ef          	jal	800035a4 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800043e6:	46e1                	li	a3,24
    800043e8:	fb840613          	addi	a2,s0,-72
    800043ec:	85ce                	mv	a1,s3
    800043ee:	05093503          	ld	a0,80(s2)
    800043f2:	9f0fd0ef          	jal	800015e2 <copyout>
    800043f6:	41f5551b          	sraiw	a0,a0,0x1f
    800043fa:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800043fc:	60a6                	ld	ra,72(sp)
    800043fe:	6406                	ld	s0,64(sp)
    80004400:	74e2                	ld	s1,56(sp)
    80004402:	79a2                	ld	s3,40(sp)
    80004404:	6161                	addi	sp,sp,80
    80004406:	8082                	ret
  return -1;
    80004408:	557d                	li	a0,-1
    8000440a:	bfcd                	j	800043fc <filestat+0x4e>

000000008000440c <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000440c:	7179                	addi	sp,sp,-48
    8000440e:	f406                	sd	ra,40(sp)
    80004410:	f022                	sd	s0,32(sp)
    80004412:	e84a                	sd	s2,16(sp)
    80004414:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004416:	00854783          	lbu	a5,8(a0)
    8000441a:	cfd1                	beqz	a5,800044b6 <fileread+0xaa>
    8000441c:	ec26                	sd	s1,24(sp)
    8000441e:	e44e                	sd	s3,8(sp)
    80004420:	84aa                	mv	s1,a0
    80004422:	89ae                	mv	s3,a1
    80004424:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004426:	411c                	lw	a5,0(a0)
    80004428:	4705                	li	a4,1
    8000442a:	04e78363          	beq	a5,a4,80004470 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000442e:	470d                	li	a4,3
    80004430:	04e78763          	beq	a5,a4,8000447e <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004434:	4709                	li	a4,2
    80004436:	06e79a63          	bne	a5,a4,800044aa <fileread+0x9e>
    ilock(f->ip);
    8000443a:	6d08                	ld	a0,24(a0)
    8000443c:	8baff0ef          	jal	800034f6 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004440:	874a                	mv	a4,s2
    80004442:	5094                	lw	a3,32(s1)
    80004444:	864e                	mv	a2,s3
    80004446:	4585                	li	a1,1
    80004448:	6c88                	ld	a0,24(s1)
    8000444a:	c3cff0ef          	jal	80003886 <readi>
    8000444e:	892a                	mv	s2,a0
    80004450:	00a05563          	blez	a0,8000445a <fileread+0x4e>
      f->off += r;
    80004454:	509c                	lw	a5,32(s1)
    80004456:	9fa9                	addw	a5,a5,a0
    80004458:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000445a:	6c88                	ld	a0,24(s1)
    8000445c:	948ff0ef          	jal	800035a4 <iunlock>
    80004460:	64e2                	ld	s1,24(sp)
    80004462:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004464:	854a                	mv	a0,s2
    80004466:	70a2                	ld	ra,40(sp)
    80004468:	7402                	ld	s0,32(sp)
    8000446a:	6942                	ld	s2,16(sp)
    8000446c:	6145                	addi	sp,sp,48
    8000446e:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004470:	6908                	ld	a0,16(a0)
    80004472:	388000ef          	jal	800047fa <piperead>
    80004476:	892a                	mv	s2,a0
    80004478:	64e2                	ld	s1,24(sp)
    8000447a:	69a2                	ld	s3,8(sp)
    8000447c:	b7e5                	j	80004464 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000447e:	02451783          	lh	a5,36(a0)
    80004482:	03079693          	slli	a3,a5,0x30
    80004486:	92c1                	srli	a3,a3,0x30
    80004488:	4725                	li	a4,9
    8000448a:	02d76863          	bltu	a4,a3,800044ba <fileread+0xae>
    8000448e:	0792                	slli	a5,a5,0x4
    80004490:	0001c717          	auipc	a4,0x1c
    80004494:	bb070713          	addi	a4,a4,-1104 # 80020040 <devsw>
    80004498:	97ba                	add	a5,a5,a4
    8000449a:	639c                	ld	a5,0(a5)
    8000449c:	c39d                	beqz	a5,800044c2 <fileread+0xb6>
    r = devsw[f->major].read(1, addr, n);
    8000449e:	4505                	li	a0,1
    800044a0:	9782                	jalr	a5
    800044a2:	892a                	mv	s2,a0
    800044a4:	64e2                	ld	s1,24(sp)
    800044a6:	69a2                	ld	s3,8(sp)
    800044a8:	bf75                	j	80004464 <fileread+0x58>
    panic("fileread");
    800044aa:	00003517          	auipc	a0,0x3
    800044ae:	1c650513          	addi	a0,a0,454 # 80007670 <etext+0x670>
    800044b2:	b2efc0ef          	jal	800007e0 <panic>
    return -1;
    800044b6:	597d                	li	s2,-1
    800044b8:	b775                	j	80004464 <fileread+0x58>
      return -1;
    800044ba:	597d                	li	s2,-1
    800044bc:	64e2                	ld	s1,24(sp)
    800044be:	69a2                	ld	s3,8(sp)
    800044c0:	b755                	j	80004464 <fileread+0x58>
    800044c2:	597d                	li	s2,-1
    800044c4:	64e2                	ld	s1,24(sp)
    800044c6:	69a2                	ld	s3,8(sp)
    800044c8:	bf71                	j	80004464 <fileread+0x58>

00000000800044ca <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    800044ca:	00954783          	lbu	a5,9(a0)
    800044ce:	10078b63          	beqz	a5,800045e4 <filewrite+0x11a>
{
    800044d2:	715d                	addi	sp,sp,-80
    800044d4:	e486                	sd	ra,72(sp)
    800044d6:	e0a2                	sd	s0,64(sp)
    800044d8:	f84a                	sd	s2,48(sp)
    800044da:	f052                	sd	s4,32(sp)
    800044dc:	e85a                	sd	s6,16(sp)
    800044de:	0880                	addi	s0,sp,80
    800044e0:	892a                	mv	s2,a0
    800044e2:	8b2e                	mv	s6,a1
    800044e4:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800044e6:	411c                	lw	a5,0(a0)
    800044e8:	4705                	li	a4,1
    800044ea:	02e78763          	beq	a5,a4,80004518 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800044ee:	470d                	li	a4,3
    800044f0:	02e78863          	beq	a5,a4,80004520 <filewrite+0x56>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800044f4:	4709                	li	a4,2
    800044f6:	0ce79c63          	bne	a5,a4,800045ce <filewrite+0x104>
    800044fa:	f44e                	sd	s3,40(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800044fc:	0ac05863          	blez	a2,800045ac <filewrite+0xe2>
    80004500:	fc26                	sd	s1,56(sp)
    80004502:	ec56                	sd	s5,24(sp)
    80004504:	e45e                	sd	s7,8(sp)
    80004506:	e062                	sd	s8,0(sp)
    int i = 0;
    80004508:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    8000450a:	6b85                	lui	s7,0x1
    8000450c:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004510:	6c05                	lui	s8,0x1
    80004512:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    80004516:	a8b5                	j	80004592 <filewrite+0xc8>
    ret = pipewrite(f->pipe, addr, n);
    80004518:	6908                	ld	a0,16(a0)
    8000451a:	1fc000ef          	jal	80004716 <pipewrite>
    8000451e:	a04d                	j	800045c0 <filewrite+0xf6>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004520:	02451783          	lh	a5,36(a0)
    80004524:	03079693          	slli	a3,a5,0x30
    80004528:	92c1                	srli	a3,a3,0x30
    8000452a:	4725                	li	a4,9
    8000452c:	0ad76e63          	bltu	a4,a3,800045e8 <filewrite+0x11e>
    80004530:	0792                	slli	a5,a5,0x4
    80004532:	0001c717          	auipc	a4,0x1c
    80004536:	b0e70713          	addi	a4,a4,-1266 # 80020040 <devsw>
    8000453a:	97ba                	add	a5,a5,a4
    8000453c:	679c                	ld	a5,8(a5)
    8000453e:	c7dd                	beqz	a5,800045ec <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004540:	4505                	li	a0,1
    80004542:	9782                	jalr	a5
    80004544:	a8b5                	j	800045c0 <filewrite+0xf6>
      if(n1 > max)
    80004546:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    8000454a:	997ff0ef          	jal	80003ee0 <begin_op>
      ilock(f->ip);
    8000454e:	01893503          	ld	a0,24(s2)
    80004552:	fa5fe0ef          	jal	800034f6 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004556:	8756                	mv	a4,s5
    80004558:	02092683          	lw	a3,32(s2)
    8000455c:	01698633          	add	a2,s3,s6
    80004560:	4585                	li	a1,1
    80004562:	01893503          	ld	a0,24(s2)
    80004566:	c1cff0ef          	jal	80003982 <writei>
    8000456a:	84aa                	mv	s1,a0
    8000456c:	00a05763          	blez	a0,8000457a <filewrite+0xb0>
        f->off += r;
    80004570:	02092783          	lw	a5,32(s2)
    80004574:	9fa9                	addw	a5,a5,a0
    80004576:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000457a:	01893503          	ld	a0,24(s2)
    8000457e:	826ff0ef          	jal	800035a4 <iunlock>
      end_op();
    80004582:	9c9ff0ef          	jal	80003f4a <end_op>

      if(r != n1){
    80004586:	029a9563          	bne	s5,s1,800045b0 <filewrite+0xe6>
        // error from writei
        break;
      }
      i += r;
    8000458a:	013489bb          	addw	s3,s1,s3
    while(i < n){
    8000458e:	0149da63          	bge	s3,s4,800045a2 <filewrite+0xd8>
      int n1 = n - i;
    80004592:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80004596:	0004879b          	sext.w	a5,s1
    8000459a:	fafbd6e3          	bge	s7,a5,80004546 <filewrite+0x7c>
    8000459e:	84e2                	mv	s1,s8
    800045a0:	b75d                	j	80004546 <filewrite+0x7c>
    800045a2:	74e2                	ld	s1,56(sp)
    800045a4:	6ae2                	ld	s5,24(sp)
    800045a6:	6ba2                	ld	s7,8(sp)
    800045a8:	6c02                	ld	s8,0(sp)
    800045aa:	a039                	j	800045b8 <filewrite+0xee>
    int i = 0;
    800045ac:	4981                	li	s3,0
    800045ae:	a029                	j	800045b8 <filewrite+0xee>
    800045b0:	74e2                	ld	s1,56(sp)
    800045b2:	6ae2                	ld	s5,24(sp)
    800045b4:	6ba2                	ld	s7,8(sp)
    800045b6:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    800045b8:	033a1c63          	bne	s4,s3,800045f0 <filewrite+0x126>
    800045bc:	8552                	mv	a0,s4
    800045be:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800045c0:	60a6                	ld	ra,72(sp)
    800045c2:	6406                	ld	s0,64(sp)
    800045c4:	7942                	ld	s2,48(sp)
    800045c6:	7a02                	ld	s4,32(sp)
    800045c8:	6b42                	ld	s6,16(sp)
    800045ca:	6161                	addi	sp,sp,80
    800045cc:	8082                	ret
    800045ce:	fc26                	sd	s1,56(sp)
    800045d0:	f44e                	sd	s3,40(sp)
    800045d2:	ec56                	sd	s5,24(sp)
    800045d4:	e45e                	sd	s7,8(sp)
    800045d6:	e062                	sd	s8,0(sp)
    panic("filewrite");
    800045d8:	00003517          	auipc	a0,0x3
    800045dc:	0a850513          	addi	a0,a0,168 # 80007680 <etext+0x680>
    800045e0:	a00fc0ef          	jal	800007e0 <panic>
    return -1;
    800045e4:	557d                	li	a0,-1
}
    800045e6:	8082                	ret
      return -1;
    800045e8:	557d                	li	a0,-1
    800045ea:	bfd9                	j	800045c0 <filewrite+0xf6>
    800045ec:	557d                	li	a0,-1
    800045ee:	bfc9                	j	800045c0 <filewrite+0xf6>
    ret = (i == n ? n : -1);
    800045f0:	557d                	li	a0,-1
    800045f2:	79a2                	ld	s3,40(sp)
    800045f4:	b7f1                	j	800045c0 <filewrite+0xf6>

00000000800045f6 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800045f6:	7179                	addi	sp,sp,-48
    800045f8:	f406                	sd	ra,40(sp)
    800045fa:	f022                	sd	s0,32(sp)
    800045fc:	ec26                	sd	s1,24(sp)
    800045fe:	e052                	sd	s4,0(sp)
    80004600:	1800                	addi	s0,sp,48
    80004602:	84aa                	mv	s1,a0
    80004604:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004606:	0005b023          	sd	zero,0(a1)
    8000460a:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000460e:	c3bff0ef          	jal	80004248 <filealloc>
    80004612:	e088                	sd	a0,0(s1)
    80004614:	c549                	beqz	a0,8000469e <pipealloc+0xa8>
    80004616:	c33ff0ef          	jal	80004248 <filealloc>
    8000461a:	00aa3023          	sd	a0,0(s4)
    8000461e:	cd25                	beqz	a0,80004696 <pipealloc+0xa0>
    80004620:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004622:	cdcfc0ef          	jal	80000afe <kalloc>
    80004626:	892a                	mv	s2,a0
    80004628:	c12d                	beqz	a0,8000468a <pipealloc+0x94>
    8000462a:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000462c:	4985                	li	s3,1
    8000462e:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004632:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004636:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000463a:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000463e:	00003597          	auipc	a1,0x3
    80004642:	05258593          	addi	a1,a1,82 # 80007690 <etext+0x690>
    80004646:	d08fc0ef          	jal	80000b4e <initlock>
  (*f0)->type = FD_PIPE;
    8000464a:	609c                	ld	a5,0(s1)
    8000464c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004650:	609c                	ld	a5,0(s1)
    80004652:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004656:	609c                	ld	a5,0(s1)
    80004658:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000465c:	609c                	ld	a5,0(s1)
    8000465e:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004662:	000a3783          	ld	a5,0(s4)
    80004666:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000466a:	000a3783          	ld	a5,0(s4)
    8000466e:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004672:	000a3783          	ld	a5,0(s4)
    80004676:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000467a:	000a3783          	ld	a5,0(s4)
    8000467e:	0127b823          	sd	s2,16(a5)
  return 0;
    80004682:	4501                	li	a0,0
    80004684:	6942                	ld	s2,16(sp)
    80004686:	69a2                	ld	s3,8(sp)
    80004688:	a01d                	j	800046ae <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000468a:	6088                	ld	a0,0(s1)
    8000468c:	c119                	beqz	a0,80004692 <pipealloc+0x9c>
    8000468e:	6942                	ld	s2,16(sp)
    80004690:	a029                	j	8000469a <pipealloc+0xa4>
    80004692:	6942                	ld	s2,16(sp)
    80004694:	a029                	j	8000469e <pipealloc+0xa8>
    80004696:	6088                	ld	a0,0(s1)
    80004698:	c10d                	beqz	a0,800046ba <pipealloc+0xc4>
    fileclose(*f0);
    8000469a:	c53ff0ef          	jal	800042ec <fileclose>
  if(*f1)
    8000469e:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800046a2:	557d                	li	a0,-1
  if(*f1)
    800046a4:	c789                	beqz	a5,800046ae <pipealloc+0xb8>
    fileclose(*f1);
    800046a6:	853e                	mv	a0,a5
    800046a8:	c45ff0ef          	jal	800042ec <fileclose>
  return -1;
    800046ac:	557d                	li	a0,-1
}
    800046ae:	70a2                	ld	ra,40(sp)
    800046b0:	7402                	ld	s0,32(sp)
    800046b2:	64e2                	ld	s1,24(sp)
    800046b4:	6a02                	ld	s4,0(sp)
    800046b6:	6145                	addi	sp,sp,48
    800046b8:	8082                	ret
  return -1;
    800046ba:	557d                	li	a0,-1
    800046bc:	bfcd                	j	800046ae <pipealloc+0xb8>

00000000800046be <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800046be:	1101                	addi	sp,sp,-32
    800046c0:	ec06                	sd	ra,24(sp)
    800046c2:	e822                	sd	s0,16(sp)
    800046c4:	e426                	sd	s1,8(sp)
    800046c6:	e04a                	sd	s2,0(sp)
    800046c8:	1000                	addi	s0,sp,32
    800046ca:	84aa                	mv	s1,a0
    800046cc:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800046ce:	d00fc0ef          	jal	80000bce <acquire>
  if(writable){
    800046d2:	02090763          	beqz	s2,80004700 <pipeclose+0x42>
    pi->writeopen = 0;
    800046d6:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800046da:	21848513          	addi	a0,s1,536
    800046de:	905fd0ef          	jal	80001fe2 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800046e2:	2204b783          	ld	a5,544(s1)
    800046e6:	e785                	bnez	a5,8000470e <pipeclose+0x50>
    release(&pi->lock);
    800046e8:	8526                	mv	a0,s1
    800046ea:	d7cfc0ef          	jal	80000c66 <release>
    kfree((char*)pi);
    800046ee:	8526                	mv	a0,s1
    800046f0:	b2cfc0ef          	jal	80000a1c <kfree>
  } else
    release(&pi->lock);
}
    800046f4:	60e2                	ld	ra,24(sp)
    800046f6:	6442                	ld	s0,16(sp)
    800046f8:	64a2                	ld	s1,8(sp)
    800046fa:	6902                	ld	s2,0(sp)
    800046fc:	6105                	addi	sp,sp,32
    800046fe:	8082                	ret
    pi->readopen = 0;
    80004700:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004704:	21c48513          	addi	a0,s1,540
    80004708:	8dbfd0ef          	jal	80001fe2 <wakeup>
    8000470c:	bfd9                	j	800046e2 <pipeclose+0x24>
    release(&pi->lock);
    8000470e:	8526                	mv	a0,s1
    80004710:	d56fc0ef          	jal	80000c66 <release>
}
    80004714:	b7c5                	j	800046f4 <pipeclose+0x36>

0000000080004716 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004716:	711d                	addi	sp,sp,-96
    80004718:	ec86                	sd	ra,88(sp)
    8000471a:	e8a2                	sd	s0,80(sp)
    8000471c:	e4a6                	sd	s1,72(sp)
    8000471e:	e0ca                	sd	s2,64(sp)
    80004720:	fc4e                	sd	s3,56(sp)
    80004722:	f852                	sd	s4,48(sp)
    80004724:	f456                	sd	s5,40(sp)
    80004726:	1080                	addi	s0,sp,96
    80004728:	84aa                	mv	s1,a0
    8000472a:	8aae                	mv	s5,a1
    8000472c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000472e:	a04fd0ef          	jal	80001932 <myproc>
    80004732:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004734:	8526                	mv	a0,s1
    80004736:	c98fc0ef          	jal	80000bce <acquire>
  while(i < n){
    8000473a:	0b405a63          	blez	s4,800047ee <pipewrite+0xd8>
    8000473e:	f05a                	sd	s6,32(sp)
    80004740:	ec5e                	sd	s7,24(sp)
    80004742:	e862                	sd	s8,16(sp)
  int i = 0;
    80004744:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004746:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004748:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000474c:	21c48b93          	addi	s7,s1,540
    80004750:	a81d                	j	80004786 <pipewrite+0x70>
      release(&pi->lock);
    80004752:	8526                	mv	a0,s1
    80004754:	d12fc0ef          	jal	80000c66 <release>
      return -1;
    80004758:	597d                	li	s2,-1
    8000475a:	7b02                	ld	s6,32(sp)
    8000475c:	6be2                	ld	s7,24(sp)
    8000475e:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004760:	854a                	mv	a0,s2
    80004762:	60e6                	ld	ra,88(sp)
    80004764:	6446                	ld	s0,80(sp)
    80004766:	64a6                	ld	s1,72(sp)
    80004768:	6906                	ld	s2,64(sp)
    8000476a:	79e2                	ld	s3,56(sp)
    8000476c:	7a42                	ld	s4,48(sp)
    8000476e:	7aa2                	ld	s5,40(sp)
    80004770:	6125                	addi	sp,sp,96
    80004772:	8082                	ret
      wakeup(&pi->nread);
    80004774:	8562                	mv	a0,s8
    80004776:	86dfd0ef          	jal	80001fe2 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000477a:	85a6                	mv	a1,s1
    8000477c:	855e                	mv	a0,s7
    8000477e:	819fd0ef          	jal	80001f96 <sleep>
  while(i < n){
    80004782:	05495b63          	bge	s2,s4,800047d8 <pipewrite+0xc2>
    if(pi->readopen == 0 || killed(pr)){
    80004786:	2204a783          	lw	a5,544(s1)
    8000478a:	d7e1                	beqz	a5,80004752 <pipewrite+0x3c>
    8000478c:	854e                	mv	a0,s3
    8000478e:	a59fd0ef          	jal	800021e6 <killed>
    80004792:	f161                	bnez	a0,80004752 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004794:	2184a783          	lw	a5,536(s1)
    80004798:	21c4a703          	lw	a4,540(s1)
    8000479c:	2007879b          	addiw	a5,a5,512
    800047a0:	fcf70ae3          	beq	a4,a5,80004774 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800047a4:	4685                	li	a3,1
    800047a6:	01590633          	add	a2,s2,s5
    800047aa:	faf40593          	addi	a1,s0,-81
    800047ae:	0509b503          	ld	a0,80(s3)
    800047b2:	f15fc0ef          	jal	800016c6 <copyin>
    800047b6:	03650e63          	beq	a0,s6,800047f2 <pipewrite+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800047ba:	21c4a783          	lw	a5,540(s1)
    800047be:	0017871b          	addiw	a4,a5,1
    800047c2:	20e4ae23          	sw	a4,540(s1)
    800047c6:	1ff7f793          	andi	a5,a5,511
    800047ca:	97a6                	add	a5,a5,s1
    800047cc:	faf44703          	lbu	a4,-81(s0)
    800047d0:	00e78c23          	sb	a4,24(a5)
      i++;
    800047d4:	2905                	addiw	s2,s2,1
    800047d6:	b775                	j	80004782 <pipewrite+0x6c>
    800047d8:	7b02                	ld	s6,32(sp)
    800047da:	6be2                	ld	s7,24(sp)
    800047dc:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    800047de:	21848513          	addi	a0,s1,536
    800047e2:	801fd0ef          	jal	80001fe2 <wakeup>
  release(&pi->lock);
    800047e6:	8526                	mv	a0,s1
    800047e8:	c7efc0ef          	jal	80000c66 <release>
  return i;
    800047ec:	bf95                	j	80004760 <pipewrite+0x4a>
  int i = 0;
    800047ee:	4901                	li	s2,0
    800047f0:	b7fd                	j	800047de <pipewrite+0xc8>
    800047f2:	7b02                	ld	s6,32(sp)
    800047f4:	6be2                	ld	s7,24(sp)
    800047f6:	6c42                	ld	s8,16(sp)
    800047f8:	b7dd                	j	800047de <pipewrite+0xc8>

00000000800047fa <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800047fa:	715d                	addi	sp,sp,-80
    800047fc:	e486                	sd	ra,72(sp)
    800047fe:	e0a2                	sd	s0,64(sp)
    80004800:	fc26                	sd	s1,56(sp)
    80004802:	f84a                	sd	s2,48(sp)
    80004804:	f44e                	sd	s3,40(sp)
    80004806:	f052                	sd	s4,32(sp)
    80004808:	ec56                	sd	s5,24(sp)
    8000480a:	0880                	addi	s0,sp,80
    8000480c:	84aa                	mv	s1,a0
    8000480e:	892e                	mv	s2,a1
    80004810:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004812:	920fd0ef          	jal	80001932 <myproc>
    80004816:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004818:	8526                	mv	a0,s1
    8000481a:	bb4fc0ef          	jal	80000bce <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000481e:	2184a703          	lw	a4,536(s1)
    80004822:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004826:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000482a:	02f71563          	bne	a4,a5,80004854 <piperead+0x5a>
    8000482e:	2244a783          	lw	a5,548(s1)
    80004832:	cb85                	beqz	a5,80004862 <piperead+0x68>
    if(killed(pr)){
    80004834:	8552                	mv	a0,s4
    80004836:	9b1fd0ef          	jal	800021e6 <killed>
    8000483a:	ed19                	bnez	a0,80004858 <piperead+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000483c:	85a6                	mv	a1,s1
    8000483e:	854e                	mv	a0,s3
    80004840:	f56fd0ef          	jal	80001f96 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004844:	2184a703          	lw	a4,536(s1)
    80004848:	21c4a783          	lw	a5,540(s1)
    8000484c:	fef701e3          	beq	a4,a5,8000482e <piperead+0x34>
    80004850:	e85a                	sd	s6,16(sp)
    80004852:	a809                	j	80004864 <piperead+0x6a>
    80004854:	e85a                	sd	s6,16(sp)
    80004856:	a039                	j	80004864 <piperead+0x6a>
      release(&pi->lock);
    80004858:	8526                	mv	a0,s1
    8000485a:	c0cfc0ef          	jal	80000c66 <release>
      return -1;
    8000485e:	59fd                	li	s3,-1
    80004860:	a8b1                	j	800048bc <piperead+0xc2>
    80004862:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004864:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004866:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004868:	05505263          	blez	s5,800048ac <piperead+0xb2>
    if(pi->nread == pi->nwrite)
    8000486c:	2184a783          	lw	a5,536(s1)
    80004870:	21c4a703          	lw	a4,540(s1)
    80004874:	02f70c63          	beq	a4,a5,800048ac <piperead+0xb2>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004878:	0017871b          	addiw	a4,a5,1
    8000487c:	20e4ac23          	sw	a4,536(s1)
    80004880:	1ff7f793          	andi	a5,a5,511
    80004884:	97a6                	add	a5,a5,s1
    80004886:	0187c783          	lbu	a5,24(a5)
    8000488a:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000488e:	4685                	li	a3,1
    80004890:	fbf40613          	addi	a2,s0,-65
    80004894:	85ca                	mv	a1,s2
    80004896:	050a3503          	ld	a0,80(s4)
    8000489a:	d49fc0ef          	jal	800015e2 <copyout>
    8000489e:	01650763          	beq	a0,s6,800048ac <piperead+0xb2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800048a2:	2985                	addiw	s3,s3,1
    800048a4:	0905                	addi	s2,s2,1
    800048a6:	fd3a93e3          	bne	s5,s3,8000486c <piperead+0x72>
    800048aa:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800048ac:	21c48513          	addi	a0,s1,540
    800048b0:	f32fd0ef          	jal	80001fe2 <wakeup>
  release(&pi->lock);
    800048b4:	8526                	mv	a0,s1
    800048b6:	bb0fc0ef          	jal	80000c66 <release>
    800048ba:	6b42                	ld	s6,16(sp)
  return i;
}
    800048bc:	854e                	mv	a0,s3
    800048be:	60a6                	ld	ra,72(sp)
    800048c0:	6406                	ld	s0,64(sp)
    800048c2:	74e2                	ld	s1,56(sp)
    800048c4:	7942                	ld	s2,48(sp)
    800048c6:	79a2                	ld	s3,40(sp)
    800048c8:	7a02                	ld	s4,32(sp)
    800048ca:	6ae2                	ld	s5,24(sp)
    800048cc:	6161                	addi	sp,sp,80
    800048ce:	8082                	ret

00000000800048d0 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800048d0:	1141                	addi	sp,sp,-16
    800048d2:	e422                	sd	s0,8(sp)
    800048d4:	0800                	addi	s0,sp,16
    800048d6:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800048d8:	8905                	andi	a0,a0,1
    800048da:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    800048dc:	8b89                	andi	a5,a5,2
    800048de:	c399                	beqz	a5,800048e4 <flags2perm+0x14>
      perm |= PTE_W;
    800048e0:	00456513          	ori	a0,a0,4
    return perm;
}
    800048e4:	6422                	ld	s0,8(sp)
    800048e6:	0141                	addi	sp,sp,16
    800048e8:	8082                	ret

00000000800048ea <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800048ea:	df010113          	addi	sp,sp,-528
    800048ee:	20113423          	sd	ra,520(sp)
    800048f2:	20813023          	sd	s0,512(sp)
    800048f6:	ffa6                	sd	s1,504(sp)
    800048f8:	fbca                	sd	s2,496(sp)
    800048fa:	0c00                	addi	s0,sp,528
    800048fc:	892a                	mv	s2,a0
    800048fe:	dea43c23          	sd	a0,-520(s0)
    80004902:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004906:	82cfd0ef          	jal	80001932 <myproc>
    8000490a:	84aa                	mv	s1,a0

  begin_op();
    8000490c:	dd4ff0ef          	jal	80003ee0 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004910:	854a                	mv	a0,s2
    80004912:	bfaff0ef          	jal	80003d0c <namei>
    80004916:	c931                	beqz	a0,8000496a <kexec+0x80>
    80004918:	f3d2                	sd	s4,480(sp)
    8000491a:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000491c:	bdbfe0ef          	jal	800034f6 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004920:	04000713          	li	a4,64
    80004924:	4681                	li	a3,0
    80004926:	e5040613          	addi	a2,s0,-432
    8000492a:	4581                	li	a1,0
    8000492c:	8552                	mv	a0,s4
    8000492e:	f59fe0ef          	jal	80003886 <readi>
    80004932:	04000793          	li	a5,64
    80004936:	00f51a63          	bne	a0,a5,8000494a <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    8000493a:	e5042703          	lw	a4,-432(s0)
    8000493e:	464c47b7          	lui	a5,0x464c4
    80004942:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004946:	02f70663          	beq	a4,a5,80004972 <kexec+0x88>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000494a:	8552                	mv	a0,s4
    8000494c:	db5fe0ef          	jal	80003700 <iunlockput>
    end_op();
    80004950:	dfaff0ef          	jal	80003f4a <end_op>
  }
  return -1;
    80004954:	557d                	li	a0,-1
    80004956:	7a1e                	ld	s4,480(sp)
}
    80004958:	20813083          	ld	ra,520(sp)
    8000495c:	20013403          	ld	s0,512(sp)
    80004960:	74fe                	ld	s1,504(sp)
    80004962:	795e                	ld	s2,496(sp)
    80004964:	21010113          	addi	sp,sp,528
    80004968:	8082                	ret
    end_op();
    8000496a:	de0ff0ef          	jal	80003f4a <end_op>
    return -1;
    8000496e:	557d                	li	a0,-1
    80004970:	b7e5                	j	80004958 <kexec+0x6e>
    80004972:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004974:	8526                	mv	a0,s1
    80004976:	8c2fd0ef          	jal	80001a38 <proc_pagetable>
    8000497a:	8b2a                	mv	s6,a0
    8000497c:	2c050b63          	beqz	a0,80004c52 <kexec+0x368>
    80004980:	f7ce                	sd	s3,488(sp)
    80004982:	efd6                	sd	s5,472(sp)
    80004984:	e7de                	sd	s7,456(sp)
    80004986:	e3e2                	sd	s8,448(sp)
    80004988:	ff66                	sd	s9,440(sp)
    8000498a:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000498c:	e7042d03          	lw	s10,-400(s0)
    80004990:	e8845783          	lhu	a5,-376(s0)
    80004994:	12078963          	beqz	a5,80004ac6 <kexec+0x1dc>
    80004998:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000499a:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000499c:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    8000499e:	6c85                	lui	s9,0x1
    800049a0:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800049a4:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800049a8:	6a85                	lui	s5,0x1
    800049aa:	a085                	j	80004a0a <kexec+0x120>
      panic("loadseg: address should exist");
    800049ac:	00003517          	auipc	a0,0x3
    800049b0:	cec50513          	addi	a0,a0,-788 # 80007698 <etext+0x698>
    800049b4:	e2dfb0ef          	jal	800007e0 <panic>
    if(sz - i < PGSIZE)
    800049b8:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800049ba:	8726                	mv	a4,s1
    800049bc:	012c06bb          	addw	a3,s8,s2
    800049c0:	4581                	li	a1,0
    800049c2:	8552                	mv	a0,s4
    800049c4:	ec3fe0ef          	jal	80003886 <readi>
    800049c8:	2501                	sext.w	a0,a0
    800049ca:	24a49a63          	bne	s1,a0,80004c1e <kexec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    800049ce:	012a893b          	addw	s2,s5,s2
    800049d2:	03397363          	bgeu	s2,s3,800049f8 <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    800049d6:	02091593          	slli	a1,s2,0x20
    800049da:	9181                	srli	a1,a1,0x20
    800049dc:	95de                	add	a1,a1,s7
    800049de:	855a                	mv	a0,s6
    800049e0:	dd0fc0ef          	jal	80000fb0 <walkaddr>
    800049e4:	862a                	mv	a2,a0
    if(pa == 0)
    800049e6:	d179                	beqz	a0,800049ac <kexec+0xc2>
    if(sz - i < PGSIZE)
    800049e8:	412984bb          	subw	s1,s3,s2
    800049ec:	0004879b          	sext.w	a5,s1
    800049f0:	fcfcf4e3          	bgeu	s9,a5,800049b8 <kexec+0xce>
    800049f4:	84d6                	mv	s1,s5
    800049f6:	b7c9                	j	800049b8 <kexec+0xce>
    sz = sz1;
    800049f8:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800049fc:	2d85                	addiw	s11,s11,1
    800049fe:	038d0d1b          	addiw	s10,s10,56
    80004a02:	e8845783          	lhu	a5,-376(s0)
    80004a06:	08fdd063          	bge	s11,a5,80004a86 <kexec+0x19c>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a0a:	2d01                	sext.w	s10,s10
    80004a0c:	03800713          	li	a4,56
    80004a10:	86ea                	mv	a3,s10
    80004a12:	e1840613          	addi	a2,s0,-488
    80004a16:	4581                	li	a1,0
    80004a18:	8552                	mv	a0,s4
    80004a1a:	e6dfe0ef          	jal	80003886 <readi>
    80004a1e:	03800793          	li	a5,56
    80004a22:	1cf51663          	bne	a0,a5,80004bee <kexec+0x304>
    if(ph.type != ELF_PROG_LOAD)
    80004a26:	e1842783          	lw	a5,-488(s0)
    80004a2a:	4705                	li	a4,1
    80004a2c:	fce798e3          	bne	a5,a4,800049fc <kexec+0x112>
    if(ph.memsz < ph.filesz)
    80004a30:	e4043483          	ld	s1,-448(s0)
    80004a34:	e3843783          	ld	a5,-456(s0)
    80004a38:	1af4ef63          	bltu	s1,a5,80004bf6 <kexec+0x30c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004a3c:	e2843783          	ld	a5,-472(s0)
    80004a40:	94be                	add	s1,s1,a5
    80004a42:	1af4ee63          	bltu	s1,a5,80004bfe <kexec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    80004a46:	df043703          	ld	a4,-528(s0)
    80004a4a:	8ff9                	and	a5,a5,a4
    80004a4c:	1a079d63          	bnez	a5,80004c06 <kexec+0x31c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004a50:	e1c42503          	lw	a0,-484(s0)
    80004a54:	e7dff0ef          	jal	800048d0 <flags2perm>
    80004a58:	86aa                	mv	a3,a0
    80004a5a:	8626                	mv	a2,s1
    80004a5c:	85ca                	mv	a1,s2
    80004a5e:	855a                	mv	a0,s6
    80004a60:	829fc0ef          	jal	80001288 <uvmalloc>
    80004a64:	e0a43423          	sd	a0,-504(s0)
    80004a68:	1a050363          	beqz	a0,80004c0e <kexec+0x324>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a6c:	e2843b83          	ld	s7,-472(s0)
    80004a70:	e2042c03          	lw	s8,-480(s0)
    80004a74:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004a78:	00098463          	beqz	s3,80004a80 <kexec+0x196>
    80004a7c:	4901                	li	s2,0
    80004a7e:	bfa1                	j	800049d6 <kexec+0xec>
    sz = sz1;
    80004a80:	e0843903          	ld	s2,-504(s0)
    80004a84:	bfa5                	j	800049fc <kexec+0x112>
    80004a86:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004a88:	8552                	mv	a0,s4
    80004a8a:	c77fe0ef          	jal	80003700 <iunlockput>
  end_op();
    80004a8e:	cbcff0ef          	jal	80003f4a <end_op>
  p = myproc();
    80004a92:	ea1fc0ef          	jal	80001932 <myproc>
    80004a96:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004a98:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004a9c:	6985                	lui	s3,0x1
    80004a9e:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004aa0:	99ca                	add	s3,s3,s2
    80004aa2:	77fd                	lui	a5,0xfffff
    80004aa4:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004aa8:	4691                	li	a3,4
    80004aaa:	6609                	lui	a2,0x2
    80004aac:	964e                	add	a2,a2,s3
    80004aae:	85ce                	mv	a1,s3
    80004ab0:	855a                	mv	a0,s6
    80004ab2:	fd6fc0ef          	jal	80001288 <uvmalloc>
    80004ab6:	892a                	mv	s2,a0
    80004ab8:	e0a43423          	sd	a0,-504(s0)
    80004abc:	e519                	bnez	a0,80004aca <kexec+0x1e0>
  if(pagetable)
    80004abe:	e1343423          	sd	s3,-504(s0)
    80004ac2:	4a01                	li	s4,0
    80004ac4:	aab1                	j	80004c20 <kexec+0x336>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004ac6:	4901                	li	s2,0
    80004ac8:	b7c1                	j	80004a88 <kexec+0x19e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004aca:	75f9                	lui	a1,0xffffe
    80004acc:	95aa                	add	a1,a1,a0
    80004ace:	855a                	mv	a0,s6
    80004ad0:	98ffc0ef          	jal	8000145e <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004ad4:	7bfd                	lui	s7,0xfffff
    80004ad6:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    80004ad8:	e0043783          	ld	a5,-512(s0)
    80004adc:	6388                	ld	a0,0(a5)
    80004ade:	cd39                	beqz	a0,80004b3c <kexec+0x252>
    80004ae0:	e9040993          	addi	s3,s0,-368
    80004ae4:	f9040c13          	addi	s8,s0,-112
    80004ae8:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004aea:	b28fc0ef          	jal	80000e12 <strlen>
    80004aee:	0015079b          	addiw	a5,a0,1
    80004af2:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004af6:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004afa:	11796e63          	bltu	s2,s7,80004c16 <kexec+0x32c>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004afe:	e0043d03          	ld	s10,-512(s0)
    80004b02:	000d3a03          	ld	s4,0(s10)
    80004b06:	8552                	mv	a0,s4
    80004b08:	b0afc0ef          	jal	80000e12 <strlen>
    80004b0c:	0015069b          	addiw	a3,a0,1
    80004b10:	8652                	mv	a2,s4
    80004b12:	85ca                	mv	a1,s2
    80004b14:	855a                	mv	a0,s6
    80004b16:	acdfc0ef          	jal	800015e2 <copyout>
    80004b1a:	10054063          	bltz	a0,80004c1a <kexec+0x330>
    ustack[argc] = sp;
    80004b1e:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004b22:	0485                	addi	s1,s1,1
    80004b24:	008d0793          	addi	a5,s10,8
    80004b28:	e0f43023          	sd	a5,-512(s0)
    80004b2c:	008d3503          	ld	a0,8(s10)
    80004b30:	c909                	beqz	a0,80004b42 <kexec+0x258>
    if(argc >= MAXARG)
    80004b32:	09a1                	addi	s3,s3,8
    80004b34:	fb899be3          	bne	s3,s8,80004aea <kexec+0x200>
  ip = 0;
    80004b38:	4a01                	li	s4,0
    80004b3a:	a0dd                	j	80004c20 <kexec+0x336>
  sp = sz;
    80004b3c:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    80004b40:	4481                	li	s1,0
  ustack[argc] = 0;
    80004b42:	00349793          	slli	a5,s1,0x3
    80004b46:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffdddb8>
    80004b4a:	97a2                	add	a5,a5,s0
    80004b4c:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004b50:	00148693          	addi	a3,s1,1
    80004b54:	068e                	slli	a3,a3,0x3
    80004b56:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004b5a:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004b5e:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004b62:	f5796ee3          	bltu	s2,s7,80004abe <kexec+0x1d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004b66:	e9040613          	addi	a2,s0,-368
    80004b6a:	85ca                	mv	a1,s2
    80004b6c:	855a                	mv	a0,s6
    80004b6e:	a75fc0ef          	jal	800015e2 <copyout>
    80004b72:	0e054263          	bltz	a0,80004c56 <kexec+0x36c>
  p->trapframe->a1 = sp;
    80004b76:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004b7a:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004b7e:	df843783          	ld	a5,-520(s0)
    80004b82:	0007c703          	lbu	a4,0(a5)
    80004b86:	cf11                	beqz	a4,80004ba2 <kexec+0x2b8>
    80004b88:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004b8a:	02f00693          	li	a3,47
    80004b8e:	a039                	j	80004b9c <kexec+0x2b2>
      last = s+1;
    80004b90:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004b94:	0785                	addi	a5,a5,1
    80004b96:	fff7c703          	lbu	a4,-1(a5)
    80004b9a:	c701                	beqz	a4,80004ba2 <kexec+0x2b8>
    if(*s == '/')
    80004b9c:	fed71ce3          	bne	a4,a3,80004b94 <kexec+0x2aa>
    80004ba0:	bfc5                	j	80004b90 <kexec+0x2a6>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ba2:	4641                	li	a2,16
    80004ba4:	df843583          	ld	a1,-520(s0)
    80004ba8:	158a8513          	addi	a0,s5,344
    80004bac:	a34fc0ef          	jal	80000de0 <safestrcpy>
  oldpagetable = p->pagetable;
    80004bb0:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004bb4:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004bb8:	e0843783          	ld	a5,-504(s0)
    80004bbc:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80004bc0:	058ab783          	ld	a5,88(s5)
    80004bc4:	e6843703          	ld	a4,-408(s0)
    80004bc8:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004bca:	058ab783          	ld	a5,88(s5)
    80004bce:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004bd2:	85e6                	mv	a1,s9
    80004bd4:	ee9fc0ef          	jal	80001abc <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004bd8:	0004851b          	sext.w	a0,s1
    80004bdc:	79be                	ld	s3,488(sp)
    80004bde:	7a1e                	ld	s4,480(sp)
    80004be0:	6afe                	ld	s5,472(sp)
    80004be2:	6b5e                	ld	s6,464(sp)
    80004be4:	6bbe                	ld	s7,456(sp)
    80004be6:	6c1e                	ld	s8,448(sp)
    80004be8:	7cfa                	ld	s9,440(sp)
    80004bea:	7d5a                	ld	s10,432(sp)
    80004bec:	b3b5                	j	80004958 <kexec+0x6e>
    80004bee:	e1243423          	sd	s2,-504(s0)
    80004bf2:	7dba                	ld	s11,424(sp)
    80004bf4:	a035                	j	80004c20 <kexec+0x336>
    80004bf6:	e1243423          	sd	s2,-504(s0)
    80004bfa:	7dba                	ld	s11,424(sp)
    80004bfc:	a015                	j	80004c20 <kexec+0x336>
    80004bfe:	e1243423          	sd	s2,-504(s0)
    80004c02:	7dba                	ld	s11,424(sp)
    80004c04:	a831                	j	80004c20 <kexec+0x336>
    80004c06:	e1243423          	sd	s2,-504(s0)
    80004c0a:	7dba                	ld	s11,424(sp)
    80004c0c:	a811                	j	80004c20 <kexec+0x336>
    80004c0e:	e1243423          	sd	s2,-504(s0)
    80004c12:	7dba                	ld	s11,424(sp)
    80004c14:	a031                	j	80004c20 <kexec+0x336>
  ip = 0;
    80004c16:	4a01                	li	s4,0
    80004c18:	a021                	j	80004c20 <kexec+0x336>
    80004c1a:	4a01                	li	s4,0
  if(pagetable)
    80004c1c:	a011                	j	80004c20 <kexec+0x336>
    80004c1e:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004c20:	e0843583          	ld	a1,-504(s0)
    80004c24:	855a                	mv	a0,s6
    80004c26:	e97fc0ef          	jal	80001abc <proc_freepagetable>
  return -1;
    80004c2a:	557d                	li	a0,-1
  if(ip){
    80004c2c:	000a1b63          	bnez	s4,80004c42 <kexec+0x358>
    80004c30:	79be                	ld	s3,488(sp)
    80004c32:	7a1e                	ld	s4,480(sp)
    80004c34:	6afe                	ld	s5,472(sp)
    80004c36:	6b5e                	ld	s6,464(sp)
    80004c38:	6bbe                	ld	s7,456(sp)
    80004c3a:	6c1e                	ld	s8,448(sp)
    80004c3c:	7cfa                	ld	s9,440(sp)
    80004c3e:	7d5a                	ld	s10,432(sp)
    80004c40:	bb21                	j	80004958 <kexec+0x6e>
    80004c42:	79be                	ld	s3,488(sp)
    80004c44:	6afe                	ld	s5,472(sp)
    80004c46:	6b5e                	ld	s6,464(sp)
    80004c48:	6bbe                	ld	s7,456(sp)
    80004c4a:	6c1e                	ld	s8,448(sp)
    80004c4c:	7cfa                	ld	s9,440(sp)
    80004c4e:	7d5a                	ld	s10,432(sp)
    80004c50:	b9ed                	j	8000494a <kexec+0x60>
    80004c52:	6b5e                	ld	s6,464(sp)
    80004c54:	b9dd                	j	8000494a <kexec+0x60>
  sz = sz1;
    80004c56:	e0843983          	ld	s3,-504(s0)
    80004c5a:	b595                	j	80004abe <kexec+0x1d4>

0000000080004c5c <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004c5c:	7179                	addi	sp,sp,-48
    80004c5e:	f406                	sd	ra,40(sp)
    80004c60:	f022                	sd	s0,32(sp)
    80004c62:	ec26                	sd	s1,24(sp)
    80004c64:	e84a                	sd	s2,16(sp)
    80004c66:	1800                	addi	s0,sp,48
    80004c68:	892e                	mv	s2,a1
    80004c6a:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004c6c:	fdc40593          	addi	a1,s0,-36
    80004c70:	dadfd0ef          	jal	80002a1c <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004c74:	fdc42703          	lw	a4,-36(s0)
    80004c78:	47bd                	li	a5,15
    80004c7a:	02e7e963          	bltu	a5,a4,80004cac <argfd+0x50>
    80004c7e:	cb5fc0ef          	jal	80001932 <myproc>
    80004c82:	fdc42703          	lw	a4,-36(s0)
    80004c86:	01a70793          	addi	a5,a4,26
    80004c8a:	078e                	slli	a5,a5,0x3
    80004c8c:	953e                	add	a0,a0,a5
    80004c8e:	611c                	ld	a5,0(a0)
    80004c90:	c385                	beqz	a5,80004cb0 <argfd+0x54>
    return -1;
  if(pfd)
    80004c92:	00090463          	beqz	s2,80004c9a <argfd+0x3e>
    *pfd = fd;
    80004c96:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004c9a:	4501                	li	a0,0
  if(pf)
    80004c9c:	c091                	beqz	s1,80004ca0 <argfd+0x44>
    *pf = f;
    80004c9e:	e09c                	sd	a5,0(s1)
}
    80004ca0:	70a2                	ld	ra,40(sp)
    80004ca2:	7402                	ld	s0,32(sp)
    80004ca4:	64e2                	ld	s1,24(sp)
    80004ca6:	6942                	ld	s2,16(sp)
    80004ca8:	6145                	addi	sp,sp,48
    80004caa:	8082                	ret
    return -1;
    80004cac:	557d                	li	a0,-1
    80004cae:	bfcd                	j	80004ca0 <argfd+0x44>
    80004cb0:	557d                	li	a0,-1
    80004cb2:	b7fd                	j	80004ca0 <argfd+0x44>

0000000080004cb4 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004cb4:	1101                	addi	sp,sp,-32
    80004cb6:	ec06                	sd	ra,24(sp)
    80004cb8:	e822                	sd	s0,16(sp)
    80004cba:	e426                	sd	s1,8(sp)
    80004cbc:	1000                	addi	s0,sp,32
    80004cbe:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004cc0:	c73fc0ef          	jal	80001932 <myproc>
    80004cc4:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004cc6:	0d050793          	addi	a5,a0,208
    80004cca:	4501                	li	a0,0
    80004ccc:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004cce:	6398                	ld	a4,0(a5)
    80004cd0:	cb19                	beqz	a4,80004ce6 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004cd2:	2505                	addiw	a0,a0,1
    80004cd4:	07a1                	addi	a5,a5,8
    80004cd6:	fed51ce3          	bne	a0,a3,80004cce <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004cda:	557d                	li	a0,-1
}
    80004cdc:	60e2                	ld	ra,24(sp)
    80004cde:	6442                	ld	s0,16(sp)
    80004ce0:	64a2                	ld	s1,8(sp)
    80004ce2:	6105                	addi	sp,sp,32
    80004ce4:	8082                	ret
      p->ofile[fd] = f;
    80004ce6:	01a50793          	addi	a5,a0,26
    80004cea:	078e                	slli	a5,a5,0x3
    80004cec:	963e                	add	a2,a2,a5
    80004cee:	e204                	sd	s1,0(a2)
      return fd;
    80004cf0:	b7f5                	j	80004cdc <fdalloc+0x28>

0000000080004cf2 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004cf2:	715d                	addi	sp,sp,-80
    80004cf4:	e486                	sd	ra,72(sp)
    80004cf6:	e0a2                	sd	s0,64(sp)
    80004cf8:	fc26                	sd	s1,56(sp)
    80004cfa:	f84a                	sd	s2,48(sp)
    80004cfc:	f44e                	sd	s3,40(sp)
    80004cfe:	ec56                	sd	s5,24(sp)
    80004d00:	e85a                	sd	s6,16(sp)
    80004d02:	0880                	addi	s0,sp,80
    80004d04:	8b2e                	mv	s6,a1
    80004d06:	89b2                	mv	s3,a2
    80004d08:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004d0a:	fb040593          	addi	a1,s0,-80
    80004d0e:	818ff0ef          	jal	80003d26 <nameiparent>
    80004d12:	84aa                	mv	s1,a0
    80004d14:	10050a63          	beqz	a0,80004e28 <create+0x136>
    return 0;

  ilock(dp);
    80004d18:	fdefe0ef          	jal	800034f6 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004d1c:	4601                	li	a2,0
    80004d1e:	fb040593          	addi	a1,s0,-80
    80004d22:	8526                	mv	a0,s1
    80004d24:	d83fe0ef          	jal	80003aa6 <dirlookup>
    80004d28:	8aaa                	mv	s5,a0
    80004d2a:	c129                	beqz	a0,80004d6c <create+0x7a>
    iunlockput(dp);
    80004d2c:	8526                	mv	a0,s1
    80004d2e:	9d3fe0ef          	jal	80003700 <iunlockput>
    ilock(ip);
    80004d32:	8556                	mv	a0,s5
    80004d34:	fc2fe0ef          	jal	800034f6 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004d38:	4789                	li	a5,2
    80004d3a:	02fb1463          	bne	s6,a5,80004d62 <create+0x70>
    80004d3e:	044ad783          	lhu	a5,68(s5)
    80004d42:	37f9                	addiw	a5,a5,-2
    80004d44:	17c2                	slli	a5,a5,0x30
    80004d46:	93c1                	srli	a5,a5,0x30
    80004d48:	4705                	li	a4,1
    80004d4a:	00f76c63          	bltu	a4,a5,80004d62 <create+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d4e:	8556                	mv	a0,s5
    80004d50:	60a6                	ld	ra,72(sp)
    80004d52:	6406                	ld	s0,64(sp)
    80004d54:	74e2                	ld	s1,56(sp)
    80004d56:	7942                	ld	s2,48(sp)
    80004d58:	79a2                	ld	s3,40(sp)
    80004d5a:	6ae2                	ld	s5,24(sp)
    80004d5c:	6b42                	ld	s6,16(sp)
    80004d5e:	6161                	addi	sp,sp,80
    80004d60:	8082                	ret
    iunlockput(ip);
    80004d62:	8556                	mv	a0,s5
    80004d64:	99dfe0ef          	jal	80003700 <iunlockput>
    return 0;
    80004d68:	4a81                	li	s5,0
    80004d6a:	b7d5                	j	80004d4e <create+0x5c>
    80004d6c:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004d6e:	85da                	mv	a1,s6
    80004d70:	4088                	lw	a0,0(s1)
    80004d72:	e14fe0ef          	jal	80003386 <ialloc>
    80004d76:	8a2a                	mv	s4,a0
    80004d78:	cd15                	beqz	a0,80004db4 <create+0xc2>
  ilock(ip);
    80004d7a:	f7cfe0ef          	jal	800034f6 <ilock>
  ip->major = major;
    80004d7e:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004d82:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004d86:	4905                	li	s2,1
    80004d88:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004d8c:	8552                	mv	a0,s4
    80004d8e:	eb4fe0ef          	jal	80003442 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004d92:	032b0763          	beq	s6,s2,80004dc0 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004d96:	004a2603          	lw	a2,4(s4)
    80004d9a:	fb040593          	addi	a1,s0,-80
    80004d9e:	8526                	mv	a0,s1
    80004da0:	ed3fe0ef          	jal	80003c72 <dirlink>
    80004da4:	06054563          	bltz	a0,80004e0e <create+0x11c>
  iunlockput(dp);
    80004da8:	8526                	mv	a0,s1
    80004daa:	957fe0ef          	jal	80003700 <iunlockput>
  return ip;
    80004dae:	8ad2                	mv	s5,s4
    80004db0:	7a02                	ld	s4,32(sp)
    80004db2:	bf71                	j	80004d4e <create+0x5c>
    iunlockput(dp);
    80004db4:	8526                	mv	a0,s1
    80004db6:	94bfe0ef          	jal	80003700 <iunlockput>
    return 0;
    80004dba:	8ad2                	mv	s5,s4
    80004dbc:	7a02                	ld	s4,32(sp)
    80004dbe:	bf41                	j	80004d4e <create+0x5c>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004dc0:	004a2603          	lw	a2,4(s4)
    80004dc4:	00003597          	auipc	a1,0x3
    80004dc8:	8f458593          	addi	a1,a1,-1804 # 800076b8 <etext+0x6b8>
    80004dcc:	8552                	mv	a0,s4
    80004dce:	ea5fe0ef          	jal	80003c72 <dirlink>
    80004dd2:	02054e63          	bltz	a0,80004e0e <create+0x11c>
    80004dd6:	40d0                	lw	a2,4(s1)
    80004dd8:	00003597          	auipc	a1,0x3
    80004ddc:	8e858593          	addi	a1,a1,-1816 # 800076c0 <etext+0x6c0>
    80004de0:	8552                	mv	a0,s4
    80004de2:	e91fe0ef          	jal	80003c72 <dirlink>
    80004de6:	02054463          	bltz	a0,80004e0e <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004dea:	004a2603          	lw	a2,4(s4)
    80004dee:	fb040593          	addi	a1,s0,-80
    80004df2:	8526                	mv	a0,s1
    80004df4:	e7ffe0ef          	jal	80003c72 <dirlink>
    80004df8:	00054b63          	bltz	a0,80004e0e <create+0x11c>
    dp->nlink++;  // for ".."
    80004dfc:	04a4d783          	lhu	a5,74(s1)
    80004e00:	2785                	addiw	a5,a5,1
    80004e02:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004e06:	8526                	mv	a0,s1
    80004e08:	e3afe0ef          	jal	80003442 <iupdate>
    80004e0c:	bf71                	j	80004da8 <create+0xb6>
  ip->nlink = 0;
    80004e0e:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004e12:	8552                	mv	a0,s4
    80004e14:	e2efe0ef          	jal	80003442 <iupdate>
  iunlockput(ip);
    80004e18:	8552                	mv	a0,s4
    80004e1a:	8e7fe0ef          	jal	80003700 <iunlockput>
  iunlockput(dp);
    80004e1e:	8526                	mv	a0,s1
    80004e20:	8e1fe0ef          	jal	80003700 <iunlockput>
  return 0;
    80004e24:	7a02                	ld	s4,32(sp)
    80004e26:	b725                	j	80004d4e <create+0x5c>
    return 0;
    80004e28:	8aaa                	mv	s5,a0
    80004e2a:	b715                	j	80004d4e <create+0x5c>

0000000080004e2c <sys_dup>:
{
    80004e2c:	7179                	addi	sp,sp,-48
    80004e2e:	f406                	sd	ra,40(sp)
    80004e30:	f022                	sd	s0,32(sp)
    80004e32:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004e34:	fd840613          	addi	a2,s0,-40
    80004e38:	4581                	li	a1,0
    80004e3a:	4501                	li	a0,0
    80004e3c:	e21ff0ef          	jal	80004c5c <argfd>
    return -1;
    80004e40:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004e42:	02054363          	bltz	a0,80004e68 <sys_dup+0x3c>
    80004e46:	ec26                	sd	s1,24(sp)
    80004e48:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004e4a:	fd843903          	ld	s2,-40(s0)
    80004e4e:	854a                	mv	a0,s2
    80004e50:	e65ff0ef          	jal	80004cb4 <fdalloc>
    80004e54:	84aa                	mv	s1,a0
    return -1;
    80004e56:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004e58:	00054d63          	bltz	a0,80004e72 <sys_dup+0x46>
  filedup(f);
    80004e5c:	854a                	mv	a0,s2
    80004e5e:	c48ff0ef          	jal	800042a6 <filedup>
  return fd;
    80004e62:	87a6                	mv	a5,s1
    80004e64:	64e2                	ld	s1,24(sp)
    80004e66:	6942                	ld	s2,16(sp)
}
    80004e68:	853e                	mv	a0,a5
    80004e6a:	70a2                	ld	ra,40(sp)
    80004e6c:	7402                	ld	s0,32(sp)
    80004e6e:	6145                	addi	sp,sp,48
    80004e70:	8082                	ret
    80004e72:	64e2                	ld	s1,24(sp)
    80004e74:	6942                	ld	s2,16(sp)
    80004e76:	bfcd                	j	80004e68 <sys_dup+0x3c>

0000000080004e78 <sys_read>:
{
    80004e78:	7139                	addi	sp,sp,-64
    80004e7a:	fc06                	sd	ra,56(sp)
    80004e7c:	f822                	sd	s0,48(sp)
    80004e7e:	0080                	addi	s0,sp,64
  argaddr(1, &p);
    80004e80:	fc840593          	addi	a1,s0,-56
    80004e84:	4505                	li	a0,1
    80004e86:	bb3fd0ef          	jal	80002a38 <argaddr>
  argint(2, &n);
    80004e8a:	fd440593          	addi	a1,s0,-44
    80004e8e:	4509                	li	a0,2
    80004e90:	b8dfd0ef          	jal	80002a1c <argint>
  if(argfd(0, 0, &f) < 0)
    80004e94:	fd840613          	addi	a2,s0,-40
    80004e98:	4581                	li	a1,0
    80004e9a:	4501                	li	a0,0
    80004e9c:	dc1ff0ef          	jal	80004c5c <argfd>
    80004ea0:	87aa                	mv	a5,a0
    return -1;
    80004ea2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004ea4:	0207c063          	bltz	a5,80004ec4 <sys_read+0x4c>
    80004ea8:	f426                	sd	s1,40(sp)
  int ret = fileread(f, p, n); 
    80004eaa:	fd442603          	lw	a2,-44(s0)
    80004eae:	fc843583          	ld	a1,-56(s0)
    80004eb2:	fd843503          	ld	a0,-40(s0)
    80004eb6:	d56ff0ef          	jal	8000440c <fileread>
    80004eba:	84aa                	mv	s1,a0
  if(ret > 0){
    80004ebc:	00a04863          	bgtz	a0,80004ecc <sys_read+0x54>
  return ret;
    80004ec0:	8526                	mv	a0,s1
    80004ec2:	74a2                	ld	s1,40(sp)
}
    80004ec4:	70e2                	ld	ra,56(sp)
    80004ec6:	7442                	ld	s0,48(sp)
    80004ec8:	6121                	addi	sp,sp,64
    80004eca:	8082                	ret
    add_read_bytes((unsigned int)ret);
    80004ecc:	2501                	sext.w	a0,a0
    80004ece:	5bd000ef          	jal	80005c8a <add_read_bytes>
    80004ed2:	b7fd                	j	80004ec0 <sys_read+0x48>

0000000080004ed4 <sys_write>:
{
    80004ed4:	7179                	addi	sp,sp,-48
    80004ed6:	f406                	sd	ra,40(sp)
    80004ed8:	f022                	sd	s0,32(sp)
    80004eda:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004edc:	fd840593          	addi	a1,s0,-40
    80004ee0:	4505                	li	a0,1
    80004ee2:	b57fd0ef          	jal	80002a38 <argaddr>
  argint(2, &n);
    80004ee6:	fe440593          	addi	a1,s0,-28
    80004eea:	4509                	li	a0,2
    80004eec:	b31fd0ef          	jal	80002a1c <argint>
  if(argfd(0, 0, &f) < 0)
    80004ef0:	fe840613          	addi	a2,s0,-24
    80004ef4:	4581                	li	a1,0
    80004ef6:	4501                	li	a0,0
    80004ef8:	d65ff0ef          	jal	80004c5c <argfd>
    80004efc:	87aa                	mv	a5,a0
    return -1;
    80004efe:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004f00:	0007ca63          	bltz	a5,80004f14 <sys_write+0x40>
  return filewrite(f, p, n);
    80004f04:	fe442603          	lw	a2,-28(s0)
    80004f08:	fd843583          	ld	a1,-40(s0)
    80004f0c:	fe843503          	ld	a0,-24(s0)
    80004f10:	dbaff0ef          	jal	800044ca <filewrite>
}
    80004f14:	70a2                	ld	ra,40(sp)
    80004f16:	7402                	ld	s0,32(sp)
    80004f18:	6145                	addi	sp,sp,48
    80004f1a:	8082                	ret

0000000080004f1c <sys_close>:
{
    80004f1c:	1101                	addi	sp,sp,-32
    80004f1e:	ec06                	sd	ra,24(sp)
    80004f20:	e822                	sd	s0,16(sp)
    80004f22:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004f24:	fe040613          	addi	a2,s0,-32
    80004f28:	fec40593          	addi	a1,s0,-20
    80004f2c:	4501                	li	a0,0
    80004f2e:	d2fff0ef          	jal	80004c5c <argfd>
    return -1;
    80004f32:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004f34:	02054063          	bltz	a0,80004f54 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004f38:	9fbfc0ef          	jal	80001932 <myproc>
    80004f3c:	fec42783          	lw	a5,-20(s0)
    80004f40:	07e9                	addi	a5,a5,26
    80004f42:	078e                	slli	a5,a5,0x3
    80004f44:	953e                	add	a0,a0,a5
    80004f46:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004f4a:	fe043503          	ld	a0,-32(s0)
    80004f4e:	b9eff0ef          	jal	800042ec <fileclose>
  return 0;
    80004f52:	4781                	li	a5,0
}
    80004f54:	853e                	mv	a0,a5
    80004f56:	60e2                	ld	ra,24(sp)
    80004f58:	6442                	ld	s0,16(sp)
    80004f5a:	6105                	addi	sp,sp,32
    80004f5c:	8082                	ret

0000000080004f5e <sys_fstat>:
{
    80004f5e:	1101                	addi	sp,sp,-32
    80004f60:	ec06                	sd	ra,24(sp)
    80004f62:	e822                	sd	s0,16(sp)
    80004f64:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f66:	fe040593          	addi	a1,s0,-32
    80004f6a:	4505                	li	a0,1
    80004f6c:	acdfd0ef          	jal	80002a38 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004f70:	fe840613          	addi	a2,s0,-24
    80004f74:	4581                	li	a1,0
    80004f76:	4501                	li	a0,0
    80004f78:	ce5ff0ef          	jal	80004c5c <argfd>
    80004f7c:	87aa                	mv	a5,a0
    return -1;
    80004f7e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004f80:	0007c863          	bltz	a5,80004f90 <sys_fstat+0x32>
  return filestat(f, st);
    80004f84:	fe043583          	ld	a1,-32(s0)
    80004f88:	fe843503          	ld	a0,-24(s0)
    80004f8c:	c22ff0ef          	jal	800043ae <filestat>
}
    80004f90:	60e2                	ld	ra,24(sp)
    80004f92:	6442                	ld	s0,16(sp)
    80004f94:	6105                	addi	sp,sp,32
    80004f96:	8082                	ret

0000000080004f98 <sys_link>:
{
    80004f98:	7169                	addi	sp,sp,-304
    80004f9a:	f606                	sd	ra,296(sp)
    80004f9c:	f222                	sd	s0,288(sp)
    80004f9e:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004fa0:	08000613          	li	a2,128
    80004fa4:	ed040593          	addi	a1,s0,-304
    80004fa8:	4501                	li	a0,0
    80004faa:	aabfd0ef          	jal	80002a54 <argstr>
    return -1;
    80004fae:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004fb0:	0c054e63          	bltz	a0,8000508c <sys_link+0xf4>
    80004fb4:	08000613          	li	a2,128
    80004fb8:	f5040593          	addi	a1,s0,-176
    80004fbc:	4505                	li	a0,1
    80004fbe:	a97fd0ef          	jal	80002a54 <argstr>
    return -1;
    80004fc2:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004fc4:	0c054463          	bltz	a0,8000508c <sys_link+0xf4>
    80004fc8:	ee26                	sd	s1,280(sp)
  begin_op();
    80004fca:	f17fe0ef          	jal	80003ee0 <begin_op>
  if((ip = namei(old)) == 0){
    80004fce:	ed040513          	addi	a0,s0,-304
    80004fd2:	d3bfe0ef          	jal	80003d0c <namei>
    80004fd6:	84aa                	mv	s1,a0
    80004fd8:	c53d                	beqz	a0,80005046 <sys_link+0xae>
  ilock(ip);
    80004fda:	d1cfe0ef          	jal	800034f6 <ilock>
  if(ip->type == T_DIR){
    80004fde:	04449703          	lh	a4,68(s1)
    80004fe2:	4785                	li	a5,1
    80004fe4:	06f70663          	beq	a4,a5,80005050 <sys_link+0xb8>
    80004fe8:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fea:	04a4d783          	lhu	a5,74(s1)
    80004fee:	2785                	addiw	a5,a5,1
    80004ff0:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004ff4:	8526                	mv	a0,s1
    80004ff6:	c4cfe0ef          	jal	80003442 <iupdate>
  iunlock(ip);
    80004ffa:	8526                	mv	a0,s1
    80004ffc:	da8fe0ef          	jal	800035a4 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005000:	fd040593          	addi	a1,s0,-48
    80005004:	f5040513          	addi	a0,s0,-176
    80005008:	d1ffe0ef          	jal	80003d26 <nameiparent>
    8000500c:	892a                	mv	s2,a0
    8000500e:	cd21                	beqz	a0,80005066 <sys_link+0xce>
  ilock(dp);
    80005010:	ce6fe0ef          	jal	800034f6 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005014:	00092703          	lw	a4,0(s2)
    80005018:	409c                	lw	a5,0(s1)
    8000501a:	04f71363          	bne	a4,a5,80005060 <sys_link+0xc8>
    8000501e:	40d0                	lw	a2,4(s1)
    80005020:	fd040593          	addi	a1,s0,-48
    80005024:	854a                	mv	a0,s2
    80005026:	c4dfe0ef          	jal	80003c72 <dirlink>
    8000502a:	02054b63          	bltz	a0,80005060 <sys_link+0xc8>
  iunlockput(dp);
    8000502e:	854a                	mv	a0,s2
    80005030:	ed0fe0ef          	jal	80003700 <iunlockput>
  iput(ip);
    80005034:	8526                	mv	a0,s1
    80005036:	e42fe0ef          	jal	80003678 <iput>
  end_op();
    8000503a:	f11fe0ef          	jal	80003f4a <end_op>
  return 0;
    8000503e:	4781                	li	a5,0
    80005040:	64f2                	ld	s1,280(sp)
    80005042:	6952                	ld	s2,272(sp)
    80005044:	a0a1                	j	8000508c <sys_link+0xf4>
    end_op();
    80005046:	f05fe0ef          	jal	80003f4a <end_op>
    return -1;
    8000504a:	57fd                	li	a5,-1
    8000504c:	64f2                	ld	s1,280(sp)
    8000504e:	a83d                	j	8000508c <sys_link+0xf4>
    iunlockput(ip);
    80005050:	8526                	mv	a0,s1
    80005052:	eaefe0ef          	jal	80003700 <iunlockput>
    end_op();
    80005056:	ef5fe0ef          	jal	80003f4a <end_op>
    return -1;
    8000505a:	57fd                	li	a5,-1
    8000505c:	64f2                	ld	s1,280(sp)
    8000505e:	a03d                	j	8000508c <sys_link+0xf4>
    iunlockput(dp);
    80005060:	854a                	mv	a0,s2
    80005062:	e9efe0ef          	jal	80003700 <iunlockput>
  ilock(ip);
    80005066:	8526                	mv	a0,s1
    80005068:	c8efe0ef          	jal	800034f6 <ilock>
  ip->nlink--;
    8000506c:	04a4d783          	lhu	a5,74(s1)
    80005070:	37fd                	addiw	a5,a5,-1
    80005072:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005076:	8526                	mv	a0,s1
    80005078:	bcafe0ef          	jal	80003442 <iupdate>
  iunlockput(ip);
    8000507c:	8526                	mv	a0,s1
    8000507e:	e82fe0ef          	jal	80003700 <iunlockput>
  end_op();
    80005082:	ec9fe0ef          	jal	80003f4a <end_op>
  return -1;
    80005086:	57fd                	li	a5,-1
    80005088:	64f2                	ld	s1,280(sp)
    8000508a:	6952                	ld	s2,272(sp)
}
    8000508c:	853e                	mv	a0,a5
    8000508e:	70b2                	ld	ra,296(sp)
    80005090:	7412                	ld	s0,288(sp)
    80005092:	6155                	addi	sp,sp,304
    80005094:	8082                	ret

0000000080005096 <sys_unlink>:
{
    80005096:	7151                	addi	sp,sp,-240
    80005098:	f586                	sd	ra,232(sp)
    8000509a:	f1a2                	sd	s0,224(sp)
    8000509c:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000509e:	08000613          	li	a2,128
    800050a2:	f3040593          	addi	a1,s0,-208
    800050a6:	4501                	li	a0,0
    800050a8:	9adfd0ef          	jal	80002a54 <argstr>
    800050ac:	16054063          	bltz	a0,8000520c <sys_unlink+0x176>
    800050b0:	eda6                	sd	s1,216(sp)
  begin_op();
    800050b2:	e2ffe0ef          	jal	80003ee0 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    800050b6:	fb040593          	addi	a1,s0,-80
    800050ba:	f3040513          	addi	a0,s0,-208
    800050be:	c69fe0ef          	jal	80003d26 <nameiparent>
    800050c2:	84aa                	mv	s1,a0
    800050c4:	c945                	beqz	a0,80005174 <sys_unlink+0xde>
  ilock(dp);
    800050c6:	c30fe0ef          	jal	800034f6 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800050ca:	00002597          	auipc	a1,0x2
    800050ce:	5ee58593          	addi	a1,a1,1518 # 800076b8 <etext+0x6b8>
    800050d2:	fb040513          	addi	a0,s0,-80
    800050d6:	9bbfe0ef          	jal	80003a90 <namecmp>
    800050da:	10050e63          	beqz	a0,800051f6 <sys_unlink+0x160>
    800050de:	00002597          	auipc	a1,0x2
    800050e2:	5e258593          	addi	a1,a1,1506 # 800076c0 <etext+0x6c0>
    800050e6:	fb040513          	addi	a0,s0,-80
    800050ea:	9a7fe0ef          	jal	80003a90 <namecmp>
    800050ee:	10050463          	beqz	a0,800051f6 <sys_unlink+0x160>
    800050f2:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800050f4:	f2c40613          	addi	a2,s0,-212
    800050f8:	fb040593          	addi	a1,s0,-80
    800050fc:	8526                	mv	a0,s1
    800050fe:	9a9fe0ef          	jal	80003aa6 <dirlookup>
    80005102:	892a                	mv	s2,a0
    80005104:	0e050863          	beqz	a0,800051f4 <sys_unlink+0x15e>
  ilock(ip);
    80005108:	beefe0ef          	jal	800034f6 <ilock>
  if(ip->nlink < 1)
    8000510c:	04a91783          	lh	a5,74(s2)
    80005110:	06f05763          	blez	a5,8000517e <sys_unlink+0xe8>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80005114:	04491703          	lh	a4,68(s2)
    80005118:	4785                	li	a5,1
    8000511a:	06f70963          	beq	a4,a5,8000518c <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    8000511e:	4641                	li	a2,16
    80005120:	4581                	li	a1,0
    80005122:	fc040513          	addi	a0,s0,-64
    80005126:	b7dfb0ef          	jal	80000ca2 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000512a:	4741                	li	a4,16
    8000512c:	f2c42683          	lw	a3,-212(s0)
    80005130:	fc040613          	addi	a2,s0,-64
    80005134:	4581                	li	a1,0
    80005136:	8526                	mv	a0,s1
    80005138:	84bfe0ef          	jal	80003982 <writei>
    8000513c:	47c1                	li	a5,16
    8000513e:	08f51b63          	bne	a0,a5,800051d4 <sys_unlink+0x13e>
  if(ip->type == T_DIR){
    80005142:	04491703          	lh	a4,68(s2)
    80005146:	4785                	li	a5,1
    80005148:	08f70d63          	beq	a4,a5,800051e2 <sys_unlink+0x14c>
  iunlockput(dp);
    8000514c:	8526                	mv	a0,s1
    8000514e:	db2fe0ef          	jal	80003700 <iunlockput>
  ip->nlink--;
    80005152:	04a95783          	lhu	a5,74(s2)
    80005156:	37fd                	addiw	a5,a5,-1
    80005158:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000515c:	854a                	mv	a0,s2
    8000515e:	ae4fe0ef          	jal	80003442 <iupdate>
  iunlockput(ip);
    80005162:	854a                	mv	a0,s2
    80005164:	d9cfe0ef          	jal	80003700 <iunlockput>
  end_op();
    80005168:	de3fe0ef          	jal	80003f4a <end_op>
  return 0;
    8000516c:	4501                	li	a0,0
    8000516e:	64ee                	ld	s1,216(sp)
    80005170:	694e                	ld	s2,208(sp)
    80005172:	a849                	j	80005204 <sys_unlink+0x16e>
    end_op();
    80005174:	dd7fe0ef          	jal	80003f4a <end_op>
    return -1;
    80005178:	557d                	li	a0,-1
    8000517a:	64ee                	ld	s1,216(sp)
    8000517c:	a061                	j	80005204 <sys_unlink+0x16e>
    8000517e:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005180:	00002517          	auipc	a0,0x2
    80005184:	54850513          	addi	a0,a0,1352 # 800076c8 <etext+0x6c8>
    80005188:	e58fb0ef          	jal	800007e0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000518c:	04c92703          	lw	a4,76(s2)
    80005190:	02000793          	li	a5,32
    80005194:	f8e7f5e3          	bgeu	a5,a4,8000511e <sys_unlink+0x88>
    80005198:	e5ce                	sd	s3,200(sp)
    8000519a:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000519e:	4741                	li	a4,16
    800051a0:	86ce                	mv	a3,s3
    800051a2:	f1840613          	addi	a2,s0,-232
    800051a6:	4581                	li	a1,0
    800051a8:	854a                	mv	a0,s2
    800051aa:	edcfe0ef          	jal	80003886 <readi>
    800051ae:	47c1                	li	a5,16
    800051b0:	00f51c63          	bne	a0,a5,800051c8 <sys_unlink+0x132>
    if(de.inum != 0)
    800051b4:	f1845783          	lhu	a5,-232(s0)
    800051b8:	efa1                	bnez	a5,80005210 <sys_unlink+0x17a>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800051ba:	29c1                	addiw	s3,s3,16
    800051bc:	04c92783          	lw	a5,76(s2)
    800051c0:	fcf9efe3          	bltu	s3,a5,8000519e <sys_unlink+0x108>
    800051c4:	69ae                	ld	s3,200(sp)
    800051c6:	bfa1                	j	8000511e <sys_unlink+0x88>
      panic("isdirempty: readi");
    800051c8:	00002517          	auipc	a0,0x2
    800051cc:	51850513          	addi	a0,a0,1304 # 800076e0 <etext+0x6e0>
    800051d0:	e10fb0ef          	jal	800007e0 <panic>
    800051d4:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    800051d6:	00002517          	auipc	a0,0x2
    800051da:	52250513          	addi	a0,a0,1314 # 800076f8 <etext+0x6f8>
    800051de:	e02fb0ef          	jal	800007e0 <panic>
    dp->nlink--;
    800051e2:	04a4d783          	lhu	a5,74(s1)
    800051e6:	37fd                	addiw	a5,a5,-1
    800051e8:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051ec:	8526                	mv	a0,s1
    800051ee:	a54fe0ef          	jal	80003442 <iupdate>
    800051f2:	bfa9                	j	8000514c <sys_unlink+0xb6>
    800051f4:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051f6:	8526                	mv	a0,s1
    800051f8:	d08fe0ef          	jal	80003700 <iunlockput>
  end_op();
    800051fc:	d4ffe0ef          	jal	80003f4a <end_op>
  return -1;
    80005200:	557d                	li	a0,-1
    80005202:	64ee                	ld	s1,216(sp)
}
    80005204:	70ae                	ld	ra,232(sp)
    80005206:	740e                	ld	s0,224(sp)
    80005208:	616d                	addi	sp,sp,240
    8000520a:	8082                	ret
    return -1;
    8000520c:	557d                	li	a0,-1
    8000520e:	bfdd                	j	80005204 <sys_unlink+0x16e>
    iunlockput(ip);
    80005210:	854a                	mv	a0,s2
    80005212:	ceefe0ef          	jal	80003700 <iunlockput>
    goto bad;
    80005216:	694e                	ld	s2,208(sp)
    80005218:	69ae                	ld	s3,200(sp)
    8000521a:	bff1                	j	800051f6 <sys_unlink+0x160>

000000008000521c <sys_open>:

uint64
sys_open(void)
{
    8000521c:	7131                	addi	sp,sp,-192
    8000521e:	fd06                	sd	ra,184(sp)
    80005220:	f922                	sd	s0,176(sp)
    80005222:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005224:	f4c40593          	addi	a1,s0,-180
    80005228:	4505                	li	a0,1
    8000522a:	ff2fd0ef          	jal	80002a1c <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000522e:	08000613          	li	a2,128
    80005232:	f5040593          	addi	a1,s0,-176
    80005236:	4501                	li	a0,0
    80005238:	81dfd0ef          	jal	80002a54 <argstr>
    8000523c:	87aa                	mv	a5,a0
    return -1;
    8000523e:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005240:	0a07c263          	bltz	a5,800052e4 <sys_open+0xc8>
    80005244:	f526                	sd	s1,168(sp)

  begin_op();
    80005246:	c9bfe0ef          	jal	80003ee0 <begin_op>

  if(omode & O_CREATE){
    8000524a:	f4c42783          	lw	a5,-180(s0)
    8000524e:	2007f793          	andi	a5,a5,512
    80005252:	c3d5                	beqz	a5,800052f6 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80005254:	4681                	li	a3,0
    80005256:	4601                	li	a2,0
    80005258:	4589                	li	a1,2
    8000525a:	f5040513          	addi	a0,s0,-176
    8000525e:	a95ff0ef          	jal	80004cf2 <create>
    80005262:	84aa                	mv	s1,a0
    if(ip == 0){
    80005264:	c541                	beqz	a0,800052ec <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80005266:	04449703          	lh	a4,68(s1)
    8000526a:	478d                	li	a5,3
    8000526c:	00f71763          	bne	a4,a5,8000527a <sys_open+0x5e>
    80005270:	0464d703          	lhu	a4,70(s1)
    80005274:	47a5                	li	a5,9
    80005276:	0ae7ed63          	bltu	a5,a4,80005330 <sys_open+0x114>
    8000527a:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000527c:	fcdfe0ef          	jal	80004248 <filealloc>
    80005280:	892a                	mv	s2,a0
    80005282:	c179                	beqz	a0,80005348 <sys_open+0x12c>
    80005284:	ed4e                	sd	s3,152(sp)
    80005286:	a2fff0ef          	jal	80004cb4 <fdalloc>
    8000528a:	89aa                	mv	s3,a0
    8000528c:	0a054a63          	bltz	a0,80005340 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005290:	04449703          	lh	a4,68(s1)
    80005294:	478d                	li	a5,3
    80005296:	0cf70263          	beq	a4,a5,8000535a <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000529a:	4789                	li	a5,2
    8000529c:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800052a0:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800052a4:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800052a8:	f4c42783          	lw	a5,-180(s0)
    800052ac:	0017c713          	xori	a4,a5,1
    800052b0:	8b05                	andi	a4,a4,1
    800052b2:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800052b6:	0037f713          	andi	a4,a5,3
    800052ba:	00e03733          	snez	a4,a4
    800052be:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800052c2:	4007f793          	andi	a5,a5,1024
    800052c6:	c791                	beqz	a5,800052d2 <sys_open+0xb6>
    800052c8:	04449703          	lh	a4,68(s1)
    800052cc:	4789                	li	a5,2
    800052ce:	08f70d63          	beq	a4,a5,80005368 <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    800052d2:	8526                	mv	a0,s1
    800052d4:	ad0fe0ef          	jal	800035a4 <iunlock>
  end_op();
    800052d8:	c73fe0ef          	jal	80003f4a <end_op>

  return fd;
    800052dc:	854e                	mv	a0,s3
    800052de:	74aa                	ld	s1,168(sp)
    800052e0:	790a                	ld	s2,160(sp)
    800052e2:	69ea                	ld	s3,152(sp)
}
    800052e4:	70ea                	ld	ra,184(sp)
    800052e6:	744a                	ld	s0,176(sp)
    800052e8:	6129                	addi	sp,sp,192
    800052ea:	8082                	ret
      end_op();
    800052ec:	c5ffe0ef          	jal	80003f4a <end_op>
      return -1;
    800052f0:	557d                	li	a0,-1
    800052f2:	74aa                	ld	s1,168(sp)
    800052f4:	bfc5                	j	800052e4 <sys_open+0xc8>
    if((ip = namei(path)) == 0){
    800052f6:	f5040513          	addi	a0,s0,-176
    800052fa:	a13fe0ef          	jal	80003d0c <namei>
    800052fe:	84aa                	mv	s1,a0
    80005300:	c11d                	beqz	a0,80005326 <sys_open+0x10a>
    ilock(ip);
    80005302:	9f4fe0ef          	jal	800034f6 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80005306:	04449703          	lh	a4,68(s1)
    8000530a:	4785                	li	a5,1
    8000530c:	f4f71de3          	bne	a4,a5,80005266 <sys_open+0x4a>
    80005310:	f4c42783          	lw	a5,-180(s0)
    80005314:	d3bd                	beqz	a5,8000527a <sys_open+0x5e>
      iunlockput(ip);
    80005316:	8526                	mv	a0,s1
    80005318:	be8fe0ef          	jal	80003700 <iunlockput>
      end_op();
    8000531c:	c2ffe0ef          	jal	80003f4a <end_op>
      return -1;
    80005320:	557d                	li	a0,-1
    80005322:	74aa                	ld	s1,168(sp)
    80005324:	b7c1                	j	800052e4 <sys_open+0xc8>
      end_op();
    80005326:	c25fe0ef          	jal	80003f4a <end_op>
      return -1;
    8000532a:	557d                	li	a0,-1
    8000532c:	74aa                	ld	s1,168(sp)
    8000532e:	bf5d                	j	800052e4 <sys_open+0xc8>
    iunlockput(ip);
    80005330:	8526                	mv	a0,s1
    80005332:	bcefe0ef          	jal	80003700 <iunlockput>
    end_op();
    80005336:	c15fe0ef          	jal	80003f4a <end_op>
    return -1;
    8000533a:	557d                	li	a0,-1
    8000533c:	74aa                	ld	s1,168(sp)
    8000533e:	b75d                	j	800052e4 <sys_open+0xc8>
      fileclose(f);
    80005340:	854a                	mv	a0,s2
    80005342:	fabfe0ef          	jal	800042ec <fileclose>
    80005346:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005348:	8526                	mv	a0,s1
    8000534a:	bb6fe0ef          	jal	80003700 <iunlockput>
    end_op();
    8000534e:	bfdfe0ef          	jal	80003f4a <end_op>
    return -1;
    80005352:	557d                	li	a0,-1
    80005354:	74aa                	ld	s1,168(sp)
    80005356:	790a                	ld	s2,160(sp)
    80005358:	b771                	j	800052e4 <sys_open+0xc8>
    f->type = FD_DEVICE;
    8000535a:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    8000535e:	04649783          	lh	a5,70(s1)
    80005362:	02f91223          	sh	a5,36(s2)
    80005366:	bf3d                	j	800052a4 <sys_open+0x88>
    itrunc(ip);
    80005368:	8526                	mv	a0,s1
    8000536a:	a7afe0ef          	jal	800035e4 <itrunc>
    8000536e:	b795                	j	800052d2 <sys_open+0xb6>

0000000080005370 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005370:	7175                	addi	sp,sp,-144
    80005372:	e506                	sd	ra,136(sp)
    80005374:	e122                	sd	s0,128(sp)
    80005376:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005378:	b69fe0ef          	jal	80003ee0 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000537c:	08000613          	li	a2,128
    80005380:	f7040593          	addi	a1,s0,-144
    80005384:	4501                	li	a0,0
    80005386:	ecefd0ef          	jal	80002a54 <argstr>
    8000538a:	02054363          	bltz	a0,800053b0 <sys_mkdir+0x40>
    8000538e:	4681                	li	a3,0
    80005390:	4601                	li	a2,0
    80005392:	4585                	li	a1,1
    80005394:	f7040513          	addi	a0,s0,-144
    80005398:	95bff0ef          	jal	80004cf2 <create>
    8000539c:	c911                	beqz	a0,800053b0 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000539e:	b62fe0ef          	jal	80003700 <iunlockput>
  end_op();
    800053a2:	ba9fe0ef          	jal	80003f4a <end_op>
  return 0;
    800053a6:	4501                	li	a0,0
}
    800053a8:	60aa                	ld	ra,136(sp)
    800053aa:	640a                	ld	s0,128(sp)
    800053ac:	6149                	addi	sp,sp,144
    800053ae:	8082                	ret
    end_op();
    800053b0:	b9bfe0ef          	jal	80003f4a <end_op>
    return -1;
    800053b4:	557d                	li	a0,-1
    800053b6:	bfcd                	j	800053a8 <sys_mkdir+0x38>

00000000800053b8 <sys_mknod>:

uint64
sys_mknod(void)
{
    800053b8:	7135                	addi	sp,sp,-160
    800053ba:	ed06                	sd	ra,152(sp)
    800053bc:	e922                	sd	s0,144(sp)
    800053be:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800053c0:	b21fe0ef          	jal	80003ee0 <begin_op>
  argint(1, &major);
    800053c4:	f6c40593          	addi	a1,s0,-148
    800053c8:	4505                	li	a0,1
    800053ca:	e52fd0ef          	jal	80002a1c <argint>
  argint(2, &minor);
    800053ce:	f6840593          	addi	a1,s0,-152
    800053d2:	4509                	li	a0,2
    800053d4:	e48fd0ef          	jal	80002a1c <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053d8:	08000613          	li	a2,128
    800053dc:	f7040593          	addi	a1,s0,-144
    800053e0:	4501                	li	a0,0
    800053e2:	e72fd0ef          	jal	80002a54 <argstr>
    800053e6:	02054563          	bltz	a0,80005410 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800053ea:	f6841683          	lh	a3,-152(s0)
    800053ee:	f6c41603          	lh	a2,-148(s0)
    800053f2:	458d                	li	a1,3
    800053f4:	f7040513          	addi	a0,s0,-144
    800053f8:	8fbff0ef          	jal	80004cf2 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053fc:	c911                	beqz	a0,80005410 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053fe:	b02fe0ef          	jal	80003700 <iunlockput>
  end_op();
    80005402:	b49fe0ef          	jal	80003f4a <end_op>
  return 0;
    80005406:	4501                	li	a0,0
}
    80005408:	60ea                	ld	ra,152(sp)
    8000540a:	644a                	ld	s0,144(sp)
    8000540c:	610d                	addi	sp,sp,160
    8000540e:	8082                	ret
    end_op();
    80005410:	b3bfe0ef          	jal	80003f4a <end_op>
    return -1;
    80005414:	557d                	li	a0,-1
    80005416:	bfcd                	j	80005408 <sys_mknod+0x50>

0000000080005418 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005418:	7135                	addi	sp,sp,-160
    8000541a:	ed06                	sd	ra,152(sp)
    8000541c:	e922                	sd	s0,144(sp)
    8000541e:	e14a                	sd	s2,128(sp)
    80005420:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005422:	d10fc0ef          	jal	80001932 <myproc>
    80005426:	892a                	mv	s2,a0
  
  begin_op();
    80005428:	ab9fe0ef          	jal	80003ee0 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    8000542c:	08000613          	li	a2,128
    80005430:	f6040593          	addi	a1,s0,-160
    80005434:	4501                	li	a0,0
    80005436:	e1efd0ef          	jal	80002a54 <argstr>
    8000543a:	04054363          	bltz	a0,80005480 <sys_chdir+0x68>
    8000543e:	e526                	sd	s1,136(sp)
    80005440:	f6040513          	addi	a0,s0,-160
    80005444:	8c9fe0ef          	jal	80003d0c <namei>
    80005448:	84aa                	mv	s1,a0
    8000544a:	c915                	beqz	a0,8000547e <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000544c:	8aafe0ef          	jal	800034f6 <ilock>
  if(ip->type != T_DIR){
    80005450:	04449703          	lh	a4,68(s1)
    80005454:	4785                	li	a5,1
    80005456:	02f71963          	bne	a4,a5,80005488 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000545a:	8526                	mv	a0,s1
    8000545c:	948fe0ef          	jal	800035a4 <iunlock>
  iput(p->cwd);
    80005460:	15093503          	ld	a0,336(s2)
    80005464:	a14fe0ef          	jal	80003678 <iput>
  end_op();
    80005468:	ae3fe0ef          	jal	80003f4a <end_op>
  p->cwd = ip;
    8000546c:	14993823          	sd	s1,336(s2)
  return 0;
    80005470:	4501                	li	a0,0
    80005472:	64aa                	ld	s1,136(sp)
}
    80005474:	60ea                	ld	ra,152(sp)
    80005476:	644a                	ld	s0,144(sp)
    80005478:	690a                	ld	s2,128(sp)
    8000547a:	610d                	addi	sp,sp,160
    8000547c:	8082                	ret
    8000547e:	64aa                	ld	s1,136(sp)
    end_op();
    80005480:	acbfe0ef          	jal	80003f4a <end_op>
    return -1;
    80005484:	557d                	li	a0,-1
    80005486:	b7fd                	j	80005474 <sys_chdir+0x5c>
    iunlockput(ip);
    80005488:	8526                	mv	a0,s1
    8000548a:	a76fe0ef          	jal	80003700 <iunlockput>
    end_op();
    8000548e:	abdfe0ef          	jal	80003f4a <end_op>
    return -1;
    80005492:	557d                	li	a0,-1
    80005494:	64aa                	ld	s1,136(sp)
    80005496:	bff9                	j	80005474 <sys_chdir+0x5c>

0000000080005498 <sys_exec>:

uint64
sys_exec(void)
{
    80005498:	7121                	addi	sp,sp,-448
    8000549a:	ff06                	sd	ra,440(sp)
    8000549c:	fb22                	sd	s0,432(sp)
    8000549e:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800054a0:	e4840593          	addi	a1,s0,-440
    800054a4:	4505                	li	a0,1
    800054a6:	d92fd0ef          	jal	80002a38 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    800054aa:	08000613          	li	a2,128
    800054ae:	f5040593          	addi	a1,s0,-176
    800054b2:	4501                	li	a0,0
    800054b4:	da0fd0ef          	jal	80002a54 <argstr>
    800054b8:	87aa                	mv	a5,a0
    return -1;
    800054ba:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    800054bc:	0c07c463          	bltz	a5,80005584 <sys_exec+0xec>
    800054c0:	f726                	sd	s1,424(sp)
    800054c2:	f34a                	sd	s2,416(sp)
    800054c4:	ef4e                	sd	s3,408(sp)
    800054c6:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800054c8:	10000613          	li	a2,256
    800054cc:	4581                	li	a1,0
    800054ce:	e5040513          	addi	a0,s0,-432
    800054d2:	fd0fb0ef          	jal	80000ca2 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800054d6:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800054da:	89a6                	mv	s3,s1
    800054dc:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    800054de:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800054e2:	00391513          	slli	a0,s2,0x3
    800054e6:	e4040593          	addi	a1,s0,-448
    800054ea:	e4843783          	ld	a5,-440(s0)
    800054ee:	953e                	add	a0,a0,a5
    800054f0:	ca2fd0ef          	jal	80002992 <fetchaddr>
    800054f4:	02054663          	bltz	a0,80005520 <sys_exec+0x88>
      goto bad;
    }
    if(uarg == 0){
    800054f8:	e4043783          	ld	a5,-448(s0)
    800054fc:	c3a9                	beqz	a5,8000553e <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800054fe:	e00fb0ef          	jal	80000afe <kalloc>
    80005502:	85aa                	mv	a1,a0
    80005504:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005508:	cd01                	beqz	a0,80005520 <sys_exec+0x88>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000550a:	6605                	lui	a2,0x1
    8000550c:	e4043503          	ld	a0,-448(s0)
    80005510:	cccfd0ef          	jal	800029dc <fetchstr>
    80005514:	00054663          	bltz	a0,80005520 <sys_exec+0x88>
    if(i >= NELEM(argv)){
    80005518:	0905                	addi	s2,s2,1
    8000551a:	09a1                	addi	s3,s3,8
    8000551c:	fd4913e3          	bne	s2,s4,800054e2 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005520:	f5040913          	addi	s2,s0,-176
    80005524:	6088                	ld	a0,0(s1)
    80005526:	c931                	beqz	a0,8000557a <sys_exec+0xe2>
    kfree(argv[i]);
    80005528:	cf4fb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000552c:	04a1                	addi	s1,s1,8
    8000552e:	ff249be3          	bne	s1,s2,80005524 <sys_exec+0x8c>
  return -1;
    80005532:	557d                	li	a0,-1
    80005534:	74ba                	ld	s1,424(sp)
    80005536:	791a                	ld	s2,416(sp)
    80005538:	69fa                	ld	s3,408(sp)
    8000553a:	6a5a                	ld	s4,400(sp)
    8000553c:	a0a1                	j	80005584 <sys_exec+0xec>
      argv[i] = 0;
    8000553e:	0009079b          	sext.w	a5,s2
    80005542:	078e                	slli	a5,a5,0x3
    80005544:	fd078793          	addi	a5,a5,-48
    80005548:	97a2                	add	a5,a5,s0
    8000554a:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    8000554e:	e5040593          	addi	a1,s0,-432
    80005552:	f5040513          	addi	a0,s0,-176
    80005556:	b94ff0ef          	jal	800048ea <kexec>
    8000555a:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000555c:	f5040993          	addi	s3,s0,-176
    80005560:	6088                	ld	a0,0(s1)
    80005562:	c511                	beqz	a0,8000556e <sys_exec+0xd6>
    kfree(argv[i]);
    80005564:	cb8fb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005568:	04a1                	addi	s1,s1,8
    8000556a:	ff349be3          	bne	s1,s3,80005560 <sys_exec+0xc8>
  return ret;
    8000556e:	854a                	mv	a0,s2
    80005570:	74ba                	ld	s1,424(sp)
    80005572:	791a                	ld	s2,416(sp)
    80005574:	69fa                	ld	s3,408(sp)
    80005576:	6a5a                	ld	s4,400(sp)
    80005578:	a031                	j	80005584 <sys_exec+0xec>
  return -1;
    8000557a:	557d                	li	a0,-1
    8000557c:	74ba                	ld	s1,424(sp)
    8000557e:	791a                	ld	s2,416(sp)
    80005580:	69fa                	ld	s3,408(sp)
    80005582:	6a5a                	ld	s4,400(sp)
}
    80005584:	70fa                	ld	ra,440(sp)
    80005586:	745a                	ld	s0,432(sp)
    80005588:	6139                	addi	sp,sp,448
    8000558a:	8082                	ret

000000008000558c <sys_pipe>:

uint64
sys_pipe(void)
{
    8000558c:	7139                	addi	sp,sp,-64
    8000558e:	fc06                	sd	ra,56(sp)
    80005590:	f822                	sd	s0,48(sp)
    80005592:	f426                	sd	s1,40(sp)
    80005594:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005596:	b9cfc0ef          	jal	80001932 <myproc>
    8000559a:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000559c:	fd840593          	addi	a1,s0,-40
    800055a0:	4501                	li	a0,0
    800055a2:	c96fd0ef          	jal	80002a38 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    800055a6:	fc840593          	addi	a1,s0,-56
    800055aa:	fd040513          	addi	a0,s0,-48
    800055ae:	848ff0ef          	jal	800045f6 <pipealloc>
    return -1;
    800055b2:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800055b4:	0a054463          	bltz	a0,8000565c <sys_pipe+0xd0>
  fd0 = -1;
    800055b8:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800055bc:	fd043503          	ld	a0,-48(s0)
    800055c0:	ef4ff0ef          	jal	80004cb4 <fdalloc>
    800055c4:	fca42223          	sw	a0,-60(s0)
    800055c8:	08054163          	bltz	a0,8000564a <sys_pipe+0xbe>
    800055cc:	fc843503          	ld	a0,-56(s0)
    800055d0:	ee4ff0ef          	jal	80004cb4 <fdalloc>
    800055d4:	fca42023          	sw	a0,-64(s0)
    800055d8:	06054063          	bltz	a0,80005638 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800055dc:	4691                	li	a3,4
    800055de:	fc440613          	addi	a2,s0,-60
    800055e2:	fd843583          	ld	a1,-40(s0)
    800055e6:	68a8                	ld	a0,80(s1)
    800055e8:	ffbfb0ef          	jal	800015e2 <copyout>
    800055ec:	00054e63          	bltz	a0,80005608 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800055f0:	4691                	li	a3,4
    800055f2:	fc040613          	addi	a2,s0,-64
    800055f6:	fd843583          	ld	a1,-40(s0)
    800055fa:	0591                	addi	a1,a1,4
    800055fc:	68a8                	ld	a0,80(s1)
    800055fe:	fe5fb0ef          	jal	800015e2 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005602:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005604:	04055c63          	bgez	a0,8000565c <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80005608:	fc442783          	lw	a5,-60(s0)
    8000560c:	07e9                	addi	a5,a5,26
    8000560e:	078e                	slli	a5,a5,0x3
    80005610:	97a6                	add	a5,a5,s1
    80005612:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005616:	fc042783          	lw	a5,-64(s0)
    8000561a:	07e9                	addi	a5,a5,26
    8000561c:	078e                	slli	a5,a5,0x3
    8000561e:	94be                	add	s1,s1,a5
    80005620:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005624:	fd043503          	ld	a0,-48(s0)
    80005628:	cc5fe0ef          	jal	800042ec <fileclose>
    fileclose(wf);
    8000562c:	fc843503          	ld	a0,-56(s0)
    80005630:	cbdfe0ef          	jal	800042ec <fileclose>
    return -1;
    80005634:	57fd                	li	a5,-1
    80005636:	a01d                	j	8000565c <sys_pipe+0xd0>
    if(fd0 >= 0)
    80005638:	fc442783          	lw	a5,-60(s0)
    8000563c:	0007c763          	bltz	a5,8000564a <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    80005640:	07e9                	addi	a5,a5,26
    80005642:	078e                	slli	a5,a5,0x3
    80005644:	97a6                	add	a5,a5,s1
    80005646:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000564a:	fd043503          	ld	a0,-48(s0)
    8000564e:	c9ffe0ef          	jal	800042ec <fileclose>
    fileclose(wf);
    80005652:	fc843503          	ld	a0,-56(s0)
    80005656:	c97fe0ef          	jal	800042ec <fileclose>
    return -1;
    8000565a:	57fd                	li	a5,-1
}
    8000565c:	853e                	mv	a0,a5
    8000565e:	70e2                	ld	ra,56(sp)
    80005660:	7442                	ld	s0,48(sp)
    80005662:	74a2                	ld	s1,40(sp)
    80005664:	6121                	addi	sp,sp,64
    80005666:	8082                	ret
	...

0000000080005670 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005670:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005672:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005674:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005676:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005678:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000567a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000567c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000567e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005680:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005682:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005684:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005686:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005688:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000568a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000568c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000568e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005690:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005692:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005694:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005696:	a0cfd0ef          	jal	800028a2 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000569a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000569c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000569e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800056a0:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800056a2:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800056a4:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800056a6:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800056a8:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800056aa:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800056ac:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800056ae:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800056b0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800056b2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800056b4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800056b6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800056b8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800056ba:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800056bc:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800056be:	10200073          	sret
	...

00000000800056ce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056ce:	1141                	addi	sp,sp,-16
    800056d0:	e422                	sd	s0,8(sp)
    800056d2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800056d4:	0c0007b7          	lui	a5,0xc000
    800056d8:	4705                	li	a4,1
    800056da:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800056dc:	0c0007b7          	lui	a5,0xc000
    800056e0:	c3d8                	sw	a4,4(a5)
}
    800056e2:	6422                	ld	s0,8(sp)
    800056e4:	0141                	addi	sp,sp,16
    800056e6:	8082                	ret

00000000800056e8 <plicinithart>:

void
plicinithart(void)
{
    800056e8:	1141                	addi	sp,sp,-16
    800056ea:	e406                	sd	ra,8(sp)
    800056ec:	e022                	sd	s0,0(sp)
    800056ee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056f0:	a16fc0ef          	jal	80001906 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800056f4:	0085171b          	slliw	a4,a0,0x8
    800056f8:	0c0027b7          	lui	a5,0xc002
    800056fc:	97ba                	add	a5,a5,a4
    800056fe:	40200713          	li	a4,1026
    80005702:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005706:	00d5151b          	slliw	a0,a0,0xd
    8000570a:	0c2017b7          	lui	a5,0xc201
    8000570e:	97aa                	add	a5,a5,a0
    80005710:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005714:	60a2                	ld	ra,8(sp)
    80005716:	6402                	ld	s0,0(sp)
    80005718:	0141                	addi	sp,sp,16
    8000571a:	8082                	ret

000000008000571c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000571c:	1141                	addi	sp,sp,-16
    8000571e:	e406                	sd	ra,8(sp)
    80005720:	e022                	sd	s0,0(sp)
    80005722:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005724:	9e2fc0ef          	jal	80001906 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005728:	00d5151b          	slliw	a0,a0,0xd
    8000572c:	0c2017b7          	lui	a5,0xc201
    80005730:	97aa                	add	a5,a5,a0
  return irq;
}
    80005732:	43c8                	lw	a0,4(a5)
    80005734:	60a2                	ld	ra,8(sp)
    80005736:	6402                	ld	s0,0(sp)
    80005738:	0141                	addi	sp,sp,16
    8000573a:	8082                	ret

000000008000573c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000573c:	1101                	addi	sp,sp,-32
    8000573e:	ec06                	sd	ra,24(sp)
    80005740:	e822                	sd	s0,16(sp)
    80005742:	e426                	sd	s1,8(sp)
    80005744:	1000                	addi	s0,sp,32
    80005746:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005748:	9befc0ef          	jal	80001906 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000574c:	00d5151b          	slliw	a0,a0,0xd
    80005750:	0c2017b7          	lui	a5,0xc201
    80005754:	97aa                	add	a5,a5,a0
    80005756:	c3c4                	sw	s1,4(a5)
}
    80005758:	60e2                	ld	ra,24(sp)
    8000575a:	6442                	ld	s0,16(sp)
    8000575c:	64a2                	ld	s1,8(sp)
    8000575e:	6105                	addi	sp,sp,32
    80005760:	8082                	ret

0000000080005762 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005762:	1141                	addi	sp,sp,-16
    80005764:	e406                	sd	ra,8(sp)
    80005766:	e022                	sd	s0,0(sp)
    80005768:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000576a:	479d                	li	a5,7
    8000576c:	04a7ca63          	blt	a5,a0,800057c0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005770:	0001c797          	auipc	a5,0x1c
    80005774:	92878793          	addi	a5,a5,-1752 # 80021098 <disk>
    80005778:	97aa                	add	a5,a5,a0
    8000577a:	0187c783          	lbu	a5,24(a5)
    8000577e:	e7b9                	bnez	a5,800057cc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005780:	00451693          	slli	a3,a0,0x4
    80005784:	0001c797          	auipc	a5,0x1c
    80005788:	91478793          	addi	a5,a5,-1772 # 80021098 <disk>
    8000578c:	6398                	ld	a4,0(a5)
    8000578e:	9736                	add	a4,a4,a3
    80005790:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005794:	6398                	ld	a4,0(a5)
    80005796:	9736                	add	a4,a4,a3
    80005798:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000579c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800057a0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800057a4:	97aa                	add	a5,a5,a0
    800057a6:	4705                	li	a4,1
    800057a8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800057ac:	0001c517          	auipc	a0,0x1c
    800057b0:	90450513          	addi	a0,a0,-1788 # 800210b0 <disk+0x18>
    800057b4:	82ffc0ef          	jal	80001fe2 <wakeup>
}
    800057b8:	60a2                	ld	ra,8(sp)
    800057ba:	6402                	ld	s0,0(sp)
    800057bc:	0141                	addi	sp,sp,16
    800057be:	8082                	ret
    panic("free_desc 1");
    800057c0:	00002517          	auipc	a0,0x2
    800057c4:	f4850513          	addi	a0,a0,-184 # 80007708 <etext+0x708>
    800057c8:	818fb0ef          	jal	800007e0 <panic>
    panic("free_desc 2");
    800057cc:	00002517          	auipc	a0,0x2
    800057d0:	f4c50513          	addi	a0,a0,-180 # 80007718 <etext+0x718>
    800057d4:	80cfb0ef          	jal	800007e0 <panic>

00000000800057d8 <virtio_disk_init>:
{
    800057d8:	1101                	addi	sp,sp,-32
    800057da:	ec06                	sd	ra,24(sp)
    800057dc:	e822                	sd	s0,16(sp)
    800057de:	e426                	sd	s1,8(sp)
    800057e0:	e04a                	sd	s2,0(sp)
    800057e2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057e4:	00002597          	auipc	a1,0x2
    800057e8:	f4458593          	addi	a1,a1,-188 # 80007728 <etext+0x728>
    800057ec:	0001c517          	auipc	a0,0x1c
    800057f0:	9d450513          	addi	a0,a0,-1580 # 800211c0 <disk+0x128>
    800057f4:	b5afb0ef          	jal	80000b4e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057f8:	100017b7          	lui	a5,0x10001
    800057fc:	4398                	lw	a4,0(a5)
    800057fe:	2701                	sext.w	a4,a4
    80005800:	747277b7          	lui	a5,0x74727
    80005804:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005808:	18f71063          	bne	a4,a5,80005988 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000580c:	100017b7          	lui	a5,0x10001
    80005810:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005812:	439c                	lw	a5,0(a5)
    80005814:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005816:	4709                	li	a4,2
    80005818:	16e79863          	bne	a5,a4,80005988 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000581c:	100017b7          	lui	a5,0x10001
    80005820:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005822:	439c                	lw	a5,0(a5)
    80005824:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005826:	16e79163          	bne	a5,a4,80005988 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    8000582a:	100017b7          	lui	a5,0x10001
    8000582e:	47d8                	lw	a4,12(a5)
    80005830:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005832:	554d47b7          	lui	a5,0x554d4
    80005836:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000583a:	14f71763          	bne	a4,a5,80005988 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000583e:	100017b7          	lui	a5,0x10001
    80005842:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005846:	4705                	li	a4,1
    80005848:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000584a:	470d                	li	a4,3
    8000584c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000584e:	10001737          	lui	a4,0x10001
    80005852:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005854:	c7ffe737          	lui	a4,0xc7ffe
    80005858:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd587>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000585c:	8ef9                	and	a3,a3,a4
    8000585e:	10001737          	lui	a4,0x10001
    80005862:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005864:	472d                	li	a4,11
    80005866:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005868:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000586c:	439c                	lw	a5,0(a5)
    8000586e:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005872:	8ba1                	andi	a5,a5,8
    80005874:	12078063          	beqz	a5,80005994 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005878:	100017b7          	lui	a5,0x10001
    8000587c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005880:	100017b7          	lui	a5,0x10001
    80005884:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005888:	439c                	lw	a5,0(a5)
    8000588a:	2781                	sext.w	a5,a5
    8000588c:	10079a63          	bnez	a5,800059a0 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005890:	100017b7          	lui	a5,0x10001
    80005894:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005898:	439c                	lw	a5,0(a5)
    8000589a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000589c:	10078863          	beqz	a5,800059ac <virtio_disk_init+0x1d4>
  if(max < NUM)
    800058a0:	471d                	li	a4,7
    800058a2:	10f77b63          	bgeu	a4,a5,800059b8 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    800058a6:	a58fb0ef          	jal	80000afe <kalloc>
    800058aa:	0001b497          	auipc	s1,0x1b
    800058ae:	7ee48493          	addi	s1,s1,2030 # 80021098 <disk>
    800058b2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800058b4:	a4afb0ef          	jal	80000afe <kalloc>
    800058b8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800058ba:	a44fb0ef          	jal	80000afe <kalloc>
    800058be:	87aa                	mv	a5,a0
    800058c0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800058c2:	6088                	ld	a0,0(s1)
    800058c4:	10050063          	beqz	a0,800059c4 <virtio_disk_init+0x1ec>
    800058c8:	0001b717          	auipc	a4,0x1b
    800058cc:	7d873703          	ld	a4,2008(a4) # 800210a0 <disk+0x8>
    800058d0:	0e070a63          	beqz	a4,800059c4 <virtio_disk_init+0x1ec>
    800058d4:	0e078863          	beqz	a5,800059c4 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    800058d8:	6605                	lui	a2,0x1
    800058da:	4581                	li	a1,0
    800058dc:	bc6fb0ef          	jal	80000ca2 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058e0:	0001b497          	auipc	s1,0x1b
    800058e4:	7b848493          	addi	s1,s1,1976 # 80021098 <disk>
    800058e8:	6605                	lui	a2,0x1
    800058ea:	4581                	li	a1,0
    800058ec:	6488                	ld	a0,8(s1)
    800058ee:	bb4fb0ef          	jal	80000ca2 <memset>
  memset(disk.used, 0, PGSIZE);
    800058f2:	6605                	lui	a2,0x1
    800058f4:	4581                	li	a1,0
    800058f6:	6888                	ld	a0,16(s1)
    800058f8:	baafb0ef          	jal	80000ca2 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058fc:	100017b7          	lui	a5,0x10001
    80005900:	4721                	li	a4,8
    80005902:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005904:	4098                	lw	a4,0(s1)
    80005906:	100017b7          	lui	a5,0x10001
    8000590a:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    8000590e:	40d8                	lw	a4,4(s1)
    80005910:	100017b7          	lui	a5,0x10001
    80005914:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005918:	649c                	ld	a5,8(s1)
    8000591a:	0007869b          	sext.w	a3,a5
    8000591e:	10001737          	lui	a4,0x10001
    80005922:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005926:	9781                	srai	a5,a5,0x20
    80005928:	10001737          	lui	a4,0x10001
    8000592c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005930:	689c                	ld	a5,16(s1)
    80005932:	0007869b          	sext.w	a3,a5
    80005936:	10001737          	lui	a4,0x10001
    8000593a:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000593e:	9781                	srai	a5,a5,0x20
    80005940:	10001737          	lui	a4,0x10001
    80005944:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005948:	10001737          	lui	a4,0x10001
    8000594c:	4785                	li	a5,1
    8000594e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005950:	00f48c23          	sb	a5,24(s1)
    80005954:	00f48ca3          	sb	a5,25(s1)
    80005958:	00f48d23          	sb	a5,26(s1)
    8000595c:	00f48da3          	sb	a5,27(s1)
    80005960:	00f48e23          	sb	a5,28(s1)
    80005964:	00f48ea3          	sb	a5,29(s1)
    80005968:	00f48f23          	sb	a5,30(s1)
    8000596c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005970:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005974:	100017b7          	lui	a5,0x10001
    80005978:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000597c:	60e2                	ld	ra,24(sp)
    8000597e:	6442                	ld	s0,16(sp)
    80005980:	64a2                	ld	s1,8(sp)
    80005982:	6902                	ld	s2,0(sp)
    80005984:	6105                	addi	sp,sp,32
    80005986:	8082                	ret
    panic("could not find virtio disk");
    80005988:	00002517          	auipc	a0,0x2
    8000598c:	db050513          	addi	a0,a0,-592 # 80007738 <etext+0x738>
    80005990:	e51fa0ef          	jal	800007e0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005994:	00002517          	auipc	a0,0x2
    80005998:	dc450513          	addi	a0,a0,-572 # 80007758 <etext+0x758>
    8000599c:	e45fa0ef          	jal	800007e0 <panic>
    panic("virtio disk should not be ready");
    800059a0:	00002517          	auipc	a0,0x2
    800059a4:	dd850513          	addi	a0,a0,-552 # 80007778 <etext+0x778>
    800059a8:	e39fa0ef          	jal	800007e0 <panic>
    panic("virtio disk has no queue 0");
    800059ac:	00002517          	auipc	a0,0x2
    800059b0:	dec50513          	addi	a0,a0,-532 # 80007798 <etext+0x798>
    800059b4:	e2dfa0ef          	jal	800007e0 <panic>
    panic("virtio disk max queue too short");
    800059b8:	00002517          	auipc	a0,0x2
    800059bc:	e0050513          	addi	a0,a0,-512 # 800077b8 <etext+0x7b8>
    800059c0:	e21fa0ef          	jal	800007e0 <panic>
    panic("virtio disk kalloc");
    800059c4:	00002517          	auipc	a0,0x2
    800059c8:	e1450513          	addi	a0,a0,-492 # 800077d8 <etext+0x7d8>
    800059cc:	e15fa0ef          	jal	800007e0 <panic>

00000000800059d0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800059d0:	7159                	addi	sp,sp,-112
    800059d2:	f486                	sd	ra,104(sp)
    800059d4:	f0a2                	sd	s0,96(sp)
    800059d6:	eca6                	sd	s1,88(sp)
    800059d8:	e8ca                	sd	s2,80(sp)
    800059da:	e4ce                	sd	s3,72(sp)
    800059dc:	e0d2                	sd	s4,64(sp)
    800059de:	fc56                	sd	s5,56(sp)
    800059e0:	f85a                	sd	s6,48(sp)
    800059e2:	f45e                	sd	s7,40(sp)
    800059e4:	f062                	sd	s8,32(sp)
    800059e6:	ec66                	sd	s9,24(sp)
    800059e8:	1880                	addi	s0,sp,112
    800059ea:	8a2a                	mv	s4,a0
    800059ec:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800059ee:	00c52c83          	lw	s9,12(a0)
    800059f2:	001c9c9b          	slliw	s9,s9,0x1
    800059f6:	1c82                	slli	s9,s9,0x20
    800059f8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    800059fc:	0001b517          	auipc	a0,0x1b
    80005a00:	7c450513          	addi	a0,a0,1988 # 800211c0 <disk+0x128>
    80005a04:	9cafb0ef          	jal	80000bce <acquire>
  for(int i = 0; i < 3; i++){
    80005a08:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80005a0a:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005a0c:	0001bb17          	auipc	s6,0x1b
    80005a10:	68cb0b13          	addi	s6,s6,1676 # 80021098 <disk>
  for(int i = 0; i < 3; i++){
    80005a14:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a16:	0001bc17          	auipc	s8,0x1b
    80005a1a:	7aac0c13          	addi	s8,s8,1962 # 800211c0 <disk+0x128>
    80005a1e:	a8b9                	j	80005a7c <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80005a20:	00fb0733          	add	a4,s6,a5
    80005a24:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005a28:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005a2a:	0207c563          	bltz	a5,80005a54 <virtio_disk_rw+0x84>
  for(int i = 0; i < 3; i++){
    80005a2e:	2905                	addiw	s2,s2,1
    80005a30:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005a32:	05590963          	beq	s2,s5,80005a84 <virtio_disk_rw+0xb4>
    idx[i] = alloc_desc();
    80005a36:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005a38:	0001b717          	auipc	a4,0x1b
    80005a3c:	66070713          	addi	a4,a4,1632 # 80021098 <disk>
    80005a40:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005a42:	01874683          	lbu	a3,24(a4)
    80005a46:	fee9                	bnez	a3,80005a20 <virtio_disk_rw+0x50>
  for(int i = 0; i < NUM; i++){
    80005a48:	2785                	addiw	a5,a5,1
    80005a4a:	0705                	addi	a4,a4,1
    80005a4c:	fe979be3          	bne	a5,s1,80005a42 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005a50:	57fd                	li	a5,-1
    80005a52:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005a54:	01205d63          	blez	s2,80005a6e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a58:	f9042503          	lw	a0,-112(s0)
    80005a5c:	d07ff0ef          	jal	80005762 <free_desc>
      for(int j = 0; j < i; j++)
    80005a60:	4785                	li	a5,1
    80005a62:	0127d663          	bge	a5,s2,80005a6e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a66:	f9442503          	lw	a0,-108(s0)
    80005a6a:	cf9ff0ef          	jal	80005762 <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a6e:	85e2                	mv	a1,s8
    80005a70:	0001b517          	auipc	a0,0x1b
    80005a74:	64050513          	addi	a0,a0,1600 # 800210b0 <disk+0x18>
    80005a78:	d1efc0ef          	jal	80001f96 <sleep>
  for(int i = 0; i < 3; i++){
    80005a7c:	f9040613          	addi	a2,s0,-112
    80005a80:	894e                	mv	s2,s3
    80005a82:	bf55                	j	80005a36 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a84:	f9042503          	lw	a0,-112(s0)
    80005a88:	00451693          	slli	a3,a0,0x4

  if(write)
    80005a8c:	0001b797          	auipc	a5,0x1b
    80005a90:	60c78793          	addi	a5,a5,1548 # 80021098 <disk>
    80005a94:	00a50713          	addi	a4,a0,10
    80005a98:	0712                	slli	a4,a4,0x4
    80005a9a:	973e                	add	a4,a4,a5
    80005a9c:	01703633          	snez	a2,s7
    80005aa0:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005aa2:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005aa6:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005aaa:	6398                	ld	a4,0(a5)
    80005aac:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005aae:	0a868613          	addi	a2,a3,168
    80005ab2:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005ab4:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005ab6:	6390                	ld	a2,0(a5)
    80005ab8:	00d605b3          	add	a1,a2,a3
    80005abc:	4741                	li	a4,16
    80005abe:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005ac0:	4805                	li	a6,1
    80005ac2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005ac6:	f9442703          	lw	a4,-108(s0)
    80005aca:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005ace:	0712                	slli	a4,a4,0x4
    80005ad0:	963a                	add	a2,a2,a4
    80005ad2:	058a0593          	addi	a1,s4,88
    80005ad6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005ad8:	0007b883          	ld	a7,0(a5)
    80005adc:	9746                	add	a4,a4,a7
    80005ade:	40000613          	li	a2,1024
    80005ae2:	c710                	sw	a2,8(a4)
  if(write)
    80005ae4:	001bb613          	seqz	a2,s7
    80005ae8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005aec:	00166613          	ori	a2,a2,1
    80005af0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005af4:	f9842583          	lw	a1,-104(s0)
    80005af8:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005afc:	00250613          	addi	a2,a0,2
    80005b00:	0612                	slli	a2,a2,0x4
    80005b02:	963e                	add	a2,a2,a5
    80005b04:	577d                	li	a4,-1
    80005b06:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005b0a:	0592                	slli	a1,a1,0x4
    80005b0c:	98ae                	add	a7,a7,a1
    80005b0e:	03068713          	addi	a4,a3,48
    80005b12:	973e                	add	a4,a4,a5
    80005b14:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005b18:	6398                	ld	a4,0(a5)
    80005b1a:	972e                	add	a4,a4,a1
    80005b1c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005b20:	4689                	li	a3,2
    80005b22:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005b26:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005b2a:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005b2e:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005b32:	6794                	ld	a3,8(a5)
    80005b34:	0026d703          	lhu	a4,2(a3)
    80005b38:	8b1d                	andi	a4,a4,7
    80005b3a:	0706                	slli	a4,a4,0x1
    80005b3c:	96ba                	add	a3,a3,a4
    80005b3e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005b42:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b46:	6798                	ld	a4,8(a5)
    80005b48:	00275783          	lhu	a5,2(a4)
    80005b4c:	2785                	addiw	a5,a5,1
    80005b4e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005b52:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b56:	100017b7          	lui	a5,0x10001
    80005b5a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005b5e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005b62:	0001b917          	auipc	s2,0x1b
    80005b66:	65e90913          	addi	s2,s2,1630 # 800211c0 <disk+0x128>
  while(b->disk == 1) {
    80005b6a:	4485                	li	s1,1
    80005b6c:	01079a63          	bne	a5,a6,80005b80 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005b70:	85ca                	mv	a1,s2
    80005b72:	8552                	mv	a0,s4
    80005b74:	c22fc0ef          	jal	80001f96 <sleep>
  while(b->disk == 1) {
    80005b78:	004a2783          	lw	a5,4(s4)
    80005b7c:	fe978ae3          	beq	a5,s1,80005b70 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005b80:	f9042903          	lw	s2,-112(s0)
    80005b84:	00290713          	addi	a4,s2,2
    80005b88:	0712                	slli	a4,a4,0x4
    80005b8a:	0001b797          	auipc	a5,0x1b
    80005b8e:	50e78793          	addi	a5,a5,1294 # 80021098 <disk>
    80005b92:	97ba                	add	a5,a5,a4
    80005b94:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b98:	0001b997          	auipc	s3,0x1b
    80005b9c:	50098993          	addi	s3,s3,1280 # 80021098 <disk>
    80005ba0:	00491713          	slli	a4,s2,0x4
    80005ba4:	0009b783          	ld	a5,0(s3)
    80005ba8:	97ba                	add	a5,a5,a4
    80005baa:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005bae:	854a                	mv	a0,s2
    80005bb0:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005bb4:	bafff0ef          	jal	80005762 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005bb8:	8885                	andi	s1,s1,1
    80005bba:	f0fd                	bnez	s1,80005ba0 <virtio_disk_rw+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005bbc:	0001b517          	auipc	a0,0x1b
    80005bc0:	60450513          	addi	a0,a0,1540 # 800211c0 <disk+0x128>
    80005bc4:	8a2fb0ef          	jal	80000c66 <release>
}
    80005bc8:	70a6                	ld	ra,104(sp)
    80005bca:	7406                	ld	s0,96(sp)
    80005bcc:	64e6                	ld	s1,88(sp)
    80005bce:	6946                	ld	s2,80(sp)
    80005bd0:	69a6                	ld	s3,72(sp)
    80005bd2:	6a06                	ld	s4,64(sp)
    80005bd4:	7ae2                	ld	s5,56(sp)
    80005bd6:	7b42                	ld	s6,48(sp)
    80005bd8:	7ba2                	ld	s7,40(sp)
    80005bda:	7c02                	ld	s8,32(sp)
    80005bdc:	6ce2                	ld	s9,24(sp)
    80005bde:	6165                	addi	sp,sp,112
    80005be0:	8082                	ret

0000000080005be2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005be2:	1101                	addi	sp,sp,-32
    80005be4:	ec06                	sd	ra,24(sp)
    80005be6:	e822                	sd	s0,16(sp)
    80005be8:	e426                	sd	s1,8(sp)
    80005bea:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005bec:	0001b497          	auipc	s1,0x1b
    80005bf0:	4ac48493          	addi	s1,s1,1196 # 80021098 <disk>
    80005bf4:	0001b517          	auipc	a0,0x1b
    80005bf8:	5cc50513          	addi	a0,a0,1484 # 800211c0 <disk+0x128>
    80005bfc:	fd3fa0ef          	jal	80000bce <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005c00:	100017b7          	lui	a5,0x10001
    80005c04:	53b8                	lw	a4,96(a5)
    80005c06:	8b0d                	andi	a4,a4,3
    80005c08:	100017b7          	lui	a5,0x10001
    80005c0c:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    80005c0e:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005c12:	689c                	ld	a5,16(s1)
    80005c14:	0204d703          	lhu	a4,32(s1)
    80005c18:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005c1c:	04f70663          	beq	a4,a5,80005c68 <virtio_disk_intr+0x86>
    __sync_synchronize();
    80005c20:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005c24:	6898                	ld	a4,16(s1)
    80005c26:	0204d783          	lhu	a5,32(s1)
    80005c2a:	8b9d                	andi	a5,a5,7
    80005c2c:	078e                	slli	a5,a5,0x3
    80005c2e:	97ba                	add	a5,a5,a4
    80005c30:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005c32:	00278713          	addi	a4,a5,2
    80005c36:	0712                	slli	a4,a4,0x4
    80005c38:	9726                	add	a4,a4,s1
    80005c3a:	01074703          	lbu	a4,16(a4)
    80005c3e:	e321                	bnez	a4,80005c7e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c40:	0789                	addi	a5,a5,2
    80005c42:	0792                	slli	a5,a5,0x4
    80005c44:	97a6                	add	a5,a5,s1
    80005c46:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005c48:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c4c:	b96fc0ef          	jal	80001fe2 <wakeup>

    disk.used_idx += 1;
    80005c50:	0204d783          	lhu	a5,32(s1)
    80005c54:	2785                	addiw	a5,a5,1
    80005c56:	17c2                	slli	a5,a5,0x30
    80005c58:	93c1                	srli	a5,a5,0x30
    80005c5a:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005c5e:	6898                	ld	a4,16(s1)
    80005c60:	00275703          	lhu	a4,2(a4)
    80005c64:	faf71ee3          	bne	a4,a5,80005c20 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c68:	0001b517          	auipc	a0,0x1b
    80005c6c:	55850513          	addi	a0,a0,1368 # 800211c0 <disk+0x128>
    80005c70:	ff7fa0ef          	jal	80000c66 <release>
}
    80005c74:	60e2                	ld	ra,24(sp)
    80005c76:	6442                	ld	s0,16(sp)
    80005c78:	64a2                	ld	s1,8(sp)
    80005c7a:	6105                	addi	sp,sp,32
    80005c7c:	8082                	ret
      panic("virtio_disk_intr status");
    80005c7e:	00002517          	auipc	a0,0x2
    80005c82:	b7250513          	addi	a0,a0,-1166 # 800077f0 <etext+0x7f0>
    80005c86:	b5bfa0ef          	jal	800007e0 <panic>

0000000080005c8a <add_read_bytes>:

uint64 global_read_bytes = 0;

void
add_read_bytes(unsigned int n)
{
    80005c8a:	1141                	addi	sp,sp,-16
    80005c8c:	e422                	sd	s0,8(sp)
    80005c8e:	0800                	addi	s0,sp,16
  // natural wrap-around due to unsigned long long overflow
  global_read_bytes += (uint64)n;
    80005c90:	00002717          	auipc	a4,0x2
    80005c94:	e3070713          	addi	a4,a4,-464 # 80007ac0 <global_read_bytes>
    80005c98:	1502                	slli	a0,a0,0x20
    80005c9a:	9101                	srli	a0,a0,0x20
    80005c9c:	631c                	ld	a5,0(a4)
    80005c9e:	97aa                	add	a5,a5,a0
    80005ca0:	e31c                	sd	a5,0(a4)
}
    80005ca2:	6422                	ld	s0,8(sp)
    80005ca4:	0141                	addi	sp,sp,16
    80005ca6:	8082                	ret
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
