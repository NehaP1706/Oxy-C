kernel/readcount.o: kernel/readcount.c kernel/types.h kernel/readcount.h
