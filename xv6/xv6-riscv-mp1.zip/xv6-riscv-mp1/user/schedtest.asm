
user/_schedtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <randnum>:

#define MAXCHILD 16

// Simple linear congruential generator for pseudo-random numbers
static unsigned randstate = 1;
int randnum(int max) {
   0:	1141                	addi	sp,sp,-16
   2:	e422                	sd	s0,8(sp)
   4:	0800                	addi	s0,sp,16
  randstate = randstate * 1103515245 + 12345;
   6:	00001697          	auipc	a3,0x1
   a:	ffa68693          	addi	a3,a3,-6 # 1000 <randstate>
   e:	4298                	lw	a4,0(a3)
  10:	41c657b7          	lui	a5,0x41c65
  14:	e6d7879b          	addiw	a5,a5,-403 # 41c64e6d <base+0x41c63e4d>
  18:	02e787bb          	mulw	a5,a5,a4
  1c:	670d                	lui	a4,0x3
  1e:	0397071b          	addiw	a4,a4,57 # 3039 <base+0x2019>
  22:	9fb9                	addw	a5,a5,a4
  24:	c29c                	sw	a5,0(a3)
  return (randstate >> 16) % max;
  26:	0107d79b          	srliw	a5,a5,0x10
  2a:	02a7f53b          	remuw	a0,a5,a0
}
  2e:	2501                	sext.w	a0,a0
  30:	6422                	ld	s0,8(sp)
  32:	0141                	addi	sp,sp,16
  34:	8082                	ret

0000000000000036 <delay_ticks>:

// Delay for a number of ticks
void delay_ticks(int ticks) {
  36:	7139                	addi	sp,sp,-64
  38:	fc06                	sd	ra,56(sp)
  3a:	f822                	sd	s0,48(sp)
  3c:	f426                	sd	s1,40(sp)
  3e:	f04a                	sd	s2,32(sp)
  40:	ec4e                	sd	s3,24(sp)
  42:	e852                	sd	s4,16(sp)
  44:	0080                	addi	s0,sp,64
  46:	89aa                	mv	s3,a0
  int start = uptime();
  48:	4e0000ef          	jal	528 <uptime>
  4c:	892a                	mv	s2,a0
  while(uptime() - start < ticks) {
    volatile int x = 0;
    for(int i = 0; i < 2000000; i++) x += i;
  4e:	4a01                	li	s4,0
  50:	001e84b7          	lui	s1,0x1e8
  54:	48048493          	addi	s1,s1,1152 # 1e8480 <base+0x1e7460>
  while(uptime() - start < ticks) {
  58:	4d0000ef          	jal	528 <uptime>
  5c:	412507bb          	subw	a5,a0,s2
  60:	0137de63          	bge	a5,s3,7c <delay_ticks+0x46>
    volatile int x = 0;
  64:	fc042623          	sw	zero,-52(s0)
    for(int i = 0; i < 2000000; i++) x += i;
  68:	87d2                	mv	a5,s4
  6a:	fcc42703          	lw	a4,-52(s0)
  6e:	9f3d                	addw	a4,a4,a5
  70:	fce42623          	sw	a4,-52(s0)
  74:	2785                	addiw	a5,a5,1
  76:	fe979ae3          	bne	a5,s1,6a <delay_ticks+0x34>
  7a:	bff9                	j	58 <delay_ticks+0x22>
  }
}
  7c:	70e2                	ld	ra,56(sp)
  7e:	7442                	ld	s0,48(sp)
  80:	74a2                	ld	s1,40(sp)
  82:	7902                	ld	s2,32(sp)
  84:	69e2                	ld	s3,24(sp)
  86:	6a42                	ld	s4,16(sp)
  88:	6121                	addi	sp,sp,64
  8a:	8082                	ret

000000000000008c <main>:

int
main(int argc, char *argv[])
{
  8c:	711d                	addi	sp,sp,-96
  8e:	ec86                	sd	ra,88(sp)
  90:	e8a2                	sd	s0,80(sp)
  92:	1080                	addi	s0,sp,96
  if(argc < 3){
  94:	4789                	li	a5,2
  96:	02a7c363          	blt	a5,a0,bc <main+0x30>
  9a:	e4a6                	sd	s1,72(sp)
  9c:	e0ca                	sd	s2,64(sp)
  9e:	fc4e                	sd	s3,56(sp)
  a0:	f852                	sd	s4,48(sp)
  a2:	f456                	sd	s5,40(sp)
  a4:	f05a                	sd	s6,32(sp)
  a6:	ec5e                	sd	s7,24(sp)
  a8:	e862                	sd	s8,16(sp)
    printf("Usage: schedtest nchildren maxwork\n");
  aa:	00001517          	auipc	a0,0x1
  ae:	9e650513          	addi	a0,a0,-1562 # a90 <malloc+0x100>
  b2:	02b000ef          	jal	8dc <printf>
    exit(1);
  b6:	4505                	li	a0,1
  b8:	3d8000ef          	jal	490 <exit>
  bc:	e4a6                	sd	s1,72(sp)
  be:	e0ca                	sd	s2,64(sp)
  c0:	fc4e                	sd	s3,56(sp)
  c2:	f852                	sd	s4,48(sp)
  c4:	f456                	sd	s5,40(sp)
  c6:	f05a                	sd	s6,32(sp)
  c8:	ec5e                	sd	s7,24(sp)
  ca:	e862                	sd	s8,16(sp)
  cc:	84ae                	mv	s1,a1

  int sum_wait = 0;
  int sum_runtime = 0;
  int sum_turnaround = 0;

  int n = atoi(argv[1]);
  ce:	6588                	ld	a0,8(a1)
  d0:	29e000ef          	jal	36e <atoi>
  d4:	892a                	mv	s2,a0
  int maxwork = atoi(argv[2]);
  d6:	6888                	ld	a0,16(s1)
  d8:	296000ef          	jal	36e <atoi>
  dc:	8b2a                	mv	s6,a0
  if(n > MAXCHILD) n = MAXCHILD;
  de:	8a4a                	mv	s4,s2
  e0:	47c1                	li	a5,16
  e2:	0127d363          	bge	a5,s2,e8 <main+0x5c>
  e6:	4a41                	li	s4,16
  e8:	2a01                	sext.w	s4,s4

  int start_ticks = uptime();
  ea:	43e000ef          	jal	528 <uptime>
  ee:	8aaa                	mv	s5,a0

  // Spawn children
  for(int i = 0; i < n; i++){
  f0:	0d205463          	blez	s2,1b8 <main+0x12c>
  f4:	4981                	li	s3,0
    int delay = randnum(30);          // arrival offset in ticks
  f6:	4579                	li	a0,30
  f8:	f09ff0ef          	jal	0 <randnum>
  fc:	892a                	mv	s2,a0
    int work = randnum(maxwork) + 1;  // random work [1..maxwork]
  fe:	855a                	mv	a0,s6
 100:	f01ff0ef          	jal	0 <randnum>
 104:	84aa                	mv	s1,a0

    int pid = fork();
 106:	382000ef          	jal	488 <fork>
    if(pid == 0){
 10a:	c10d                	beqz	a0,12c <main+0xa0>
  for(int i = 0; i < n; i++){
 10c:	2985                	addiw	s3,s3,1
 10e:	ff49c4e3          	blt	s3,s4,f6 <main+0x6a>
      exit(0);   // don't fetch times here!
    }
  }

  // Parent: collect stats with waitx
  for(int i = 0; i < n; i++){
 112:	4481                	li	s1,0
  int sum_turnaround = 0;
 114:	4b01                	li	s6,0
  int sum_runtime = 0;
 116:	4981                	li	s3,0
  int sum_wait = 0;
 118:	4901                	li	s2,0

             sum_runtime += rtime;
             sum_wait += wtime;
             sum_turnaround += tatime;
    } else {
      printf("waitx failed\n");
 11a:	00001c17          	auipc	s8,0x1
 11e:	9cec0c13          	addi	s8,s8,-1586 # ae8 <malloc+0x158>
      printf("CHILD %d: wait=%d runtime=%d turnaround=%d\n",
 122:	00001b97          	auipc	s7,0x1
 126:	996b8b93          	addi	s7,s7,-1642 # ab8 <malloc+0x128>
 12a:	a0b1                	j	176 <main+0xea>
      delay_ticks(delay);
 12c:	854a                	mv	a0,s2
 12e:	f09ff0ef          	jal	36 <delay_ticks>
      for(volatile int j = 0; j < work * 10000000; j++);
 132:	fa042623          	sw	zero,-84(s0)
    int work = randnum(maxwork) + 1;  // random work [1..maxwork]
 136:	0014851b          	addiw	a0,s1,1
      for(volatile int j = 0; j < work * 10000000; j++);
 13a:	009897b7          	lui	a5,0x989
 13e:	6807879b          	addiw	a5,a5,1664 # 989680 <base+0x988660>
 142:	02f5053b          	mulw	a0,a0,a5
 146:	fac42783          	lw	a5,-84(s0)
 14a:	2781                	sext.w	a5,a5
 14c:	00a7dc63          	bge	a5,a0,164 <main+0xd8>
 150:	fac42783          	lw	a5,-84(s0)
 154:	2785                	addiw	a5,a5,1
 156:	faf42623          	sw	a5,-84(s0)
 15a:	fac42783          	lw	a5,-84(s0)
 15e:	2781                	sext.w	a5,a5
 160:	fea7c8e3          	blt	a5,a0,150 <main+0xc4>
      exit(0);   // don't fetch times here!
 164:	4501                	li	a0,0
 166:	32a000ef          	jal	490 <exit>
      printf("waitx failed\n");
 16a:	8562                	mv	a0,s8
 16c:	770000ef          	jal	8dc <printf>
  for(int i = 0; i < n; i++){
 170:	2485                	addiw	s1,s1,1
 172:	0544d663          	bge	s1,s4,1be <main+0x132>
    int pid = waitx(&wtime, &rtime, &tatime);
 176:	fac40613          	addi	a2,s0,-84
 17a:	fa840593          	addi	a1,s0,-88
 17e:	fa440513          	addi	a0,s0,-92
 182:	3be000ef          	jal	540 <waitx>
 186:	85aa                	mv	a1,a0
    if(pid > 0){
 188:	fea051e3          	blez	a0,16a <main+0xde>
      printf("CHILD %d: wait=%d runtime=%d turnaround=%d\n",
 18c:	fac42703          	lw	a4,-84(s0)
 190:	fa842683          	lw	a3,-88(s0)
 194:	fa442603          	lw	a2,-92(s0)
 198:	855e                	mv	a0,s7
 19a:	742000ef          	jal	8dc <printf>
             sum_runtime += rtime;
 19e:	fa842783          	lw	a5,-88(s0)
 1a2:	013789bb          	addw	s3,a5,s3
             sum_wait += wtime;
 1a6:	fa442783          	lw	a5,-92(s0)
 1aa:	0127893b          	addw	s2,a5,s2
             sum_turnaround += tatime;
 1ae:	fac42783          	lw	a5,-84(s0)
 1b2:	01678b3b          	addw	s6,a5,s6
 1b6:	bf6d                	j	170 <main+0xe4>
  int sum_turnaround = 0;
 1b8:	4b01                	li	s6,0
  int sum_runtime = 0;
 1ba:	4981                	li	s3,0
  int sum_wait = 0;
 1bc:	4901                	li	s2,0
    }
  }

  int end_ticks = uptime();
 1be:	36a000ef          	jal	528 <uptime>
  printf("Parent: all children finished in %d ticks\n", end_ticks - start_ticks);
 1c2:	415505bb          	subw	a1,a0,s5
 1c6:	00001517          	auipc	a0,0x1
 1ca:	93250513          	addi	a0,a0,-1742 # af8 <malloc+0x168>
 1ce:	70e000ef          	jal	8dc <printf>
  printf("=============================================STATISTICS===============================\n");
 1d2:	00001517          	auipc	a0,0x1
 1d6:	95650513          	addi	a0,a0,-1706 # b28 <malloc+0x198>
 1da:	702000ef          	jal	8dc <printf>
  printf("Average: wait=%d runtime=%d turnaround=%d\n",
 1de:	034b46bb          	divw	a3,s6,s4
 1e2:	0349c63b          	divw	a2,s3,s4
 1e6:	034945bb          	divw	a1,s2,s4
 1ea:	00001517          	auipc	a0,0x1
 1ee:	99650513          	addi	a0,a0,-1642 # b80 <malloc+0x1f0>
 1f2:	6ea000ef          	jal	8dc <printf>
         sum_wait / n, sum_runtime / n, sum_turnaround / n);
  exit(0);
 1f6:	4501                	li	a0,0
 1f8:	298000ef          	jal	490 <exit>

00000000000001fc <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 1fc:	1141                	addi	sp,sp,-16
 1fe:	e406                	sd	ra,8(sp)
 200:	e022                	sd	s0,0(sp)
 202:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 204:	e89ff0ef          	jal	8c <main>
  exit(r);
 208:	288000ef          	jal	490 <exit>

000000000000020c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 20c:	1141                	addi	sp,sp,-16
 20e:	e422                	sd	s0,8(sp)
 210:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 212:	87aa                	mv	a5,a0
 214:	0585                	addi	a1,a1,1
 216:	0785                	addi	a5,a5,1
 218:	fff5c703          	lbu	a4,-1(a1)
 21c:	fee78fa3          	sb	a4,-1(a5)
 220:	fb75                	bnez	a4,214 <strcpy+0x8>
    ;
  return os;
}
 222:	6422                	ld	s0,8(sp)
 224:	0141                	addi	sp,sp,16
 226:	8082                	ret

0000000000000228 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 228:	1141                	addi	sp,sp,-16
 22a:	e422                	sd	s0,8(sp)
 22c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 22e:	00054783          	lbu	a5,0(a0)
 232:	cb91                	beqz	a5,246 <strcmp+0x1e>
 234:	0005c703          	lbu	a4,0(a1)
 238:	00f71763          	bne	a4,a5,246 <strcmp+0x1e>
    p++, q++;
 23c:	0505                	addi	a0,a0,1
 23e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 240:	00054783          	lbu	a5,0(a0)
 244:	fbe5                	bnez	a5,234 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 246:	0005c503          	lbu	a0,0(a1)
}
 24a:	40a7853b          	subw	a0,a5,a0
 24e:	6422                	ld	s0,8(sp)
 250:	0141                	addi	sp,sp,16
 252:	8082                	ret

0000000000000254 <strlen>:

uint
strlen(const char *s)
{
 254:	1141                	addi	sp,sp,-16
 256:	e422                	sd	s0,8(sp)
 258:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 25a:	00054783          	lbu	a5,0(a0)
 25e:	cf91                	beqz	a5,27a <strlen+0x26>
 260:	0505                	addi	a0,a0,1
 262:	87aa                	mv	a5,a0
 264:	86be                	mv	a3,a5
 266:	0785                	addi	a5,a5,1
 268:	fff7c703          	lbu	a4,-1(a5)
 26c:	ff65                	bnez	a4,264 <strlen+0x10>
 26e:	40a6853b          	subw	a0,a3,a0
 272:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 274:	6422                	ld	s0,8(sp)
 276:	0141                	addi	sp,sp,16
 278:	8082                	ret
  for(n = 0; s[n]; n++)
 27a:	4501                	li	a0,0
 27c:	bfe5                	j	274 <strlen+0x20>

000000000000027e <memset>:

void*
memset(void *dst, int c, uint n)
{
 27e:	1141                	addi	sp,sp,-16
 280:	e422                	sd	s0,8(sp)
 282:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 284:	ca19                	beqz	a2,29a <memset+0x1c>
 286:	87aa                	mv	a5,a0
 288:	1602                	slli	a2,a2,0x20
 28a:	9201                	srli	a2,a2,0x20
 28c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 290:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 294:	0785                	addi	a5,a5,1
 296:	fee79de3          	bne	a5,a4,290 <memset+0x12>
  }
  return dst;
}
 29a:	6422                	ld	s0,8(sp)
 29c:	0141                	addi	sp,sp,16
 29e:	8082                	ret

00000000000002a0 <strchr>:

char*
strchr(const char *s, char c)
{
 2a0:	1141                	addi	sp,sp,-16
 2a2:	e422                	sd	s0,8(sp)
 2a4:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2a6:	00054783          	lbu	a5,0(a0)
 2aa:	cb99                	beqz	a5,2c0 <strchr+0x20>
    if(*s == c)
 2ac:	00f58763          	beq	a1,a5,2ba <strchr+0x1a>
  for(; *s; s++)
 2b0:	0505                	addi	a0,a0,1
 2b2:	00054783          	lbu	a5,0(a0)
 2b6:	fbfd                	bnez	a5,2ac <strchr+0xc>
      return (char*)s;
  return 0;
 2b8:	4501                	li	a0,0
}
 2ba:	6422                	ld	s0,8(sp)
 2bc:	0141                	addi	sp,sp,16
 2be:	8082                	ret
  return 0;
 2c0:	4501                	li	a0,0
 2c2:	bfe5                	j	2ba <strchr+0x1a>

00000000000002c4 <gets>:

char*
gets(char *buf, int max)
{
 2c4:	711d                	addi	sp,sp,-96
 2c6:	ec86                	sd	ra,88(sp)
 2c8:	e8a2                	sd	s0,80(sp)
 2ca:	e4a6                	sd	s1,72(sp)
 2cc:	e0ca                	sd	s2,64(sp)
 2ce:	fc4e                	sd	s3,56(sp)
 2d0:	f852                	sd	s4,48(sp)
 2d2:	f456                	sd	s5,40(sp)
 2d4:	f05a                	sd	s6,32(sp)
 2d6:	ec5e                	sd	s7,24(sp)
 2d8:	1080                	addi	s0,sp,96
 2da:	8baa                	mv	s7,a0
 2dc:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2de:	892a                	mv	s2,a0
 2e0:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 2e2:	4aa9                	li	s5,10
 2e4:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 2e6:	89a6                	mv	s3,s1
 2e8:	2485                	addiw	s1,s1,1
 2ea:	0344d663          	bge	s1,s4,316 <gets+0x52>
    cc = read(0, &c, 1);
 2ee:	4605                	li	a2,1
 2f0:	faf40593          	addi	a1,s0,-81
 2f4:	4501                	li	a0,0
 2f6:	1b2000ef          	jal	4a8 <read>
    if(cc < 1)
 2fa:	00a05e63          	blez	a0,316 <gets+0x52>
    buf[i++] = c;
 2fe:	faf44783          	lbu	a5,-81(s0)
 302:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 306:	01578763          	beq	a5,s5,314 <gets+0x50>
 30a:	0905                	addi	s2,s2,1
 30c:	fd679de3          	bne	a5,s6,2e6 <gets+0x22>
    buf[i++] = c;
 310:	89a6                	mv	s3,s1
 312:	a011                	j	316 <gets+0x52>
 314:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 316:	99de                	add	s3,s3,s7
 318:	00098023          	sb	zero,0(s3)
  return buf;
}
 31c:	855e                	mv	a0,s7
 31e:	60e6                	ld	ra,88(sp)
 320:	6446                	ld	s0,80(sp)
 322:	64a6                	ld	s1,72(sp)
 324:	6906                	ld	s2,64(sp)
 326:	79e2                	ld	s3,56(sp)
 328:	7a42                	ld	s4,48(sp)
 32a:	7aa2                	ld	s5,40(sp)
 32c:	7b02                	ld	s6,32(sp)
 32e:	6be2                	ld	s7,24(sp)
 330:	6125                	addi	sp,sp,96
 332:	8082                	ret

0000000000000334 <stat>:

int
stat(const char *n, struct stat *st)
{
 334:	1101                	addi	sp,sp,-32
 336:	ec06                	sd	ra,24(sp)
 338:	e822                	sd	s0,16(sp)
 33a:	e04a                	sd	s2,0(sp)
 33c:	1000                	addi	s0,sp,32
 33e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 340:	4581                	li	a1,0
 342:	18e000ef          	jal	4d0 <open>
  if(fd < 0)
 346:	02054263          	bltz	a0,36a <stat+0x36>
 34a:	e426                	sd	s1,8(sp)
 34c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 34e:	85ca                	mv	a1,s2
 350:	198000ef          	jal	4e8 <fstat>
 354:	892a                	mv	s2,a0
  close(fd);
 356:	8526                	mv	a0,s1
 358:	160000ef          	jal	4b8 <close>
  return r;
 35c:	64a2                	ld	s1,8(sp)
}
 35e:	854a                	mv	a0,s2
 360:	60e2                	ld	ra,24(sp)
 362:	6442                	ld	s0,16(sp)
 364:	6902                	ld	s2,0(sp)
 366:	6105                	addi	sp,sp,32
 368:	8082                	ret
    return -1;
 36a:	597d                	li	s2,-1
 36c:	bfcd                	j	35e <stat+0x2a>

000000000000036e <atoi>:

int
atoi(const char *s)
{
 36e:	1141                	addi	sp,sp,-16
 370:	e422                	sd	s0,8(sp)
 372:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 374:	00054683          	lbu	a3,0(a0)
 378:	fd06879b          	addiw	a5,a3,-48
 37c:	0ff7f793          	zext.b	a5,a5
 380:	4625                	li	a2,9
 382:	02f66863          	bltu	a2,a5,3b2 <atoi+0x44>
 386:	872a                	mv	a4,a0
  n = 0;
 388:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 38a:	0705                	addi	a4,a4,1
 38c:	0025179b          	slliw	a5,a0,0x2
 390:	9fa9                	addw	a5,a5,a0
 392:	0017979b          	slliw	a5,a5,0x1
 396:	9fb5                	addw	a5,a5,a3
 398:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 39c:	00074683          	lbu	a3,0(a4)
 3a0:	fd06879b          	addiw	a5,a3,-48
 3a4:	0ff7f793          	zext.b	a5,a5
 3a8:	fef671e3          	bgeu	a2,a5,38a <atoi+0x1c>
  return n;
}
 3ac:	6422                	ld	s0,8(sp)
 3ae:	0141                	addi	sp,sp,16
 3b0:	8082                	ret
  n = 0;
 3b2:	4501                	li	a0,0
 3b4:	bfe5                	j	3ac <atoi+0x3e>

00000000000003b6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3b6:	1141                	addi	sp,sp,-16
 3b8:	e422                	sd	s0,8(sp)
 3ba:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3bc:	02b57463          	bgeu	a0,a1,3e4 <memmove+0x2e>
    while(n-- > 0)
 3c0:	00c05f63          	blez	a2,3de <memmove+0x28>
 3c4:	1602                	slli	a2,a2,0x20
 3c6:	9201                	srli	a2,a2,0x20
 3c8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3cc:	872a                	mv	a4,a0
      *dst++ = *src++;
 3ce:	0585                	addi	a1,a1,1
 3d0:	0705                	addi	a4,a4,1
 3d2:	fff5c683          	lbu	a3,-1(a1)
 3d6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 3da:	fef71ae3          	bne	a4,a5,3ce <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3de:	6422                	ld	s0,8(sp)
 3e0:	0141                	addi	sp,sp,16
 3e2:	8082                	ret
    dst += n;
 3e4:	00c50733          	add	a4,a0,a2
    src += n;
 3e8:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 3ea:	fec05ae3          	blez	a2,3de <memmove+0x28>
 3ee:	fff6079b          	addiw	a5,a2,-1
 3f2:	1782                	slli	a5,a5,0x20
 3f4:	9381                	srli	a5,a5,0x20
 3f6:	fff7c793          	not	a5,a5
 3fa:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3fc:	15fd                	addi	a1,a1,-1
 3fe:	177d                	addi	a4,a4,-1
 400:	0005c683          	lbu	a3,0(a1)
 404:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 408:	fee79ae3          	bne	a5,a4,3fc <memmove+0x46>
 40c:	bfc9                	j	3de <memmove+0x28>

000000000000040e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 40e:	1141                	addi	sp,sp,-16
 410:	e422                	sd	s0,8(sp)
 412:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 414:	ca05                	beqz	a2,444 <memcmp+0x36>
 416:	fff6069b          	addiw	a3,a2,-1
 41a:	1682                	slli	a3,a3,0x20
 41c:	9281                	srli	a3,a3,0x20
 41e:	0685                	addi	a3,a3,1
 420:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 422:	00054783          	lbu	a5,0(a0)
 426:	0005c703          	lbu	a4,0(a1)
 42a:	00e79863          	bne	a5,a4,43a <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 42e:	0505                	addi	a0,a0,1
    p2++;
 430:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 432:	fed518e3          	bne	a0,a3,422 <memcmp+0x14>
  }
  return 0;
 436:	4501                	li	a0,0
 438:	a019                	j	43e <memcmp+0x30>
      return *p1 - *p2;
 43a:	40e7853b          	subw	a0,a5,a4
}
 43e:	6422                	ld	s0,8(sp)
 440:	0141                	addi	sp,sp,16
 442:	8082                	ret
  return 0;
 444:	4501                	li	a0,0
 446:	bfe5                	j	43e <memcmp+0x30>

0000000000000448 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 448:	1141                	addi	sp,sp,-16
 44a:	e406                	sd	ra,8(sp)
 44c:	e022                	sd	s0,0(sp)
 44e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 450:	f67ff0ef          	jal	3b6 <memmove>
}
 454:	60a2                	ld	ra,8(sp)
 456:	6402                	ld	s0,0(sp)
 458:	0141                	addi	sp,sp,16
 45a:	8082                	ret

000000000000045c <sbrk>:

char *
sbrk(int n) {
 45c:	1141                	addi	sp,sp,-16
 45e:	e406                	sd	ra,8(sp)
 460:	e022                	sd	s0,0(sp)
 462:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 464:	4585                	li	a1,1
 466:	0b2000ef          	jal	518 <sys_sbrk>
}
 46a:	60a2                	ld	ra,8(sp)
 46c:	6402                	ld	s0,0(sp)
 46e:	0141                	addi	sp,sp,16
 470:	8082                	ret

0000000000000472 <sbrklazy>:

char *
sbrklazy(int n) {
 472:	1141                	addi	sp,sp,-16
 474:	e406                	sd	ra,8(sp)
 476:	e022                	sd	s0,0(sp)
 478:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 47a:	4589                	li	a1,2
 47c:	09c000ef          	jal	518 <sys_sbrk>
}
 480:	60a2                	ld	ra,8(sp)
 482:	6402                	ld	s0,0(sp)
 484:	0141                	addi	sp,sp,16
 486:	8082                	ret

0000000000000488 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 488:	4885                	li	a7,1
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <exit>:
.global exit
exit:
 li a7, SYS_exit
 490:	4889                	li	a7,2
 ecall
 492:	00000073          	ecall
 ret
 496:	8082                	ret

0000000000000498 <wait>:
.global wait
wait:
 li a7, SYS_wait
 498:	488d                	li	a7,3
 ecall
 49a:	00000073          	ecall
 ret
 49e:	8082                	ret

00000000000004a0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4a0:	4891                	li	a7,4
 ecall
 4a2:	00000073          	ecall
 ret
 4a6:	8082                	ret

00000000000004a8 <read>:
.global read
read:
 li a7, SYS_read
 4a8:	4895                	li	a7,5
 ecall
 4aa:	00000073          	ecall
 ret
 4ae:	8082                	ret

00000000000004b0 <write>:
.global write
write:
 li a7, SYS_write
 4b0:	48c1                	li	a7,16
 ecall
 4b2:	00000073          	ecall
 ret
 4b6:	8082                	ret

00000000000004b8 <close>:
.global close
close:
 li a7, SYS_close
 4b8:	48d5                	li	a7,21
 ecall
 4ba:	00000073          	ecall
 ret
 4be:	8082                	ret

00000000000004c0 <kill>:
.global kill
kill:
 li a7, SYS_kill
 4c0:	4899                	li	a7,6
 ecall
 4c2:	00000073          	ecall
 ret
 4c6:	8082                	ret

00000000000004c8 <exec>:
.global exec
exec:
 li a7, SYS_exec
 4c8:	489d                	li	a7,7
 ecall
 4ca:	00000073          	ecall
 ret
 4ce:	8082                	ret

00000000000004d0 <open>:
.global open
open:
 li a7, SYS_open
 4d0:	48bd                	li	a7,15
 ecall
 4d2:	00000073          	ecall
 ret
 4d6:	8082                	ret

00000000000004d8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4d8:	48c5                	li	a7,17
 ecall
 4da:	00000073          	ecall
 ret
 4de:	8082                	ret

00000000000004e0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4e0:	48c9                	li	a7,18
 ecall
 4e2:	00000073          	ecall
 ret
 4e6:	8082                	ret

00000000000004e8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4e8:	48a1                	li	a7,8
 ecall
 4ea:	00000073          	ecall
 ret
 4ee:	8082                	ret

00000000000004f0 <link>:
.global link
link:
 li a7, SYS_link
 4f0:	48cd                	li	a7,19
 ecall
 4f2:	00000073          	ecall
 ret
 4f6:	8082                	ret

00000000000004f8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4f8:	48d1                	li	a7,20
 ecall
 4fa:	00000073          	ecall
 ret
 4fe:	8082                	ret

0000000000000500 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 500:	48a5                	li	a7,9
 ecall
 502:	00000073          	ecall
 ret
 506:	8082                	ret

0000000000000508 <dup>:
.global dup
dup:
 li a7, SYS_dup
 508:	48a9                	li	a7,10
 ecall
 50a:	00000073          	ecall
 ret
 50e:	8082                	ret

0000000000000510 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 510:	48ad                	li	a7,11
 ecall
 512:	00000073          	ecall
 ret
 516:	8082                	ret

0000000000000518 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 518:	48b1                	li	a7,12
 ecall
 51a:	00000073          	ecall
 ret
 51e:	8082                	ret

0000000000000520 <pause>:
.global pause
pause:
 li a7, SYS_pause
 520:	48b5                	li	a7,13
 ecall
 522:	00000073          	ecall
 ret
 526:	8082                	ret

0000000000000528 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 528:	48b9                	li	a7,14
 ecall
 52a:	00000073          	ecall
 ret
 52e:	8082                	ret

0000000000000530 <getreadcount>:
.global getreadcount
getreadcount:
 li a7, SYS_getreadcount
 530:	48d9                	li	a7,22
 ecall
 532:	00000073          	ecall
 ret
 536:	8082                	ret

0000000000000538 <getprocesstimes>:
.global getprocesstimes
getprocesstimes:
 li a7, SYS_getprocesstimes
 538:	48dd                	li	a7,23
 ecall
 53a:	00000073          	ecall
 ret
 53e:	8082                	ret

0000000000000540 <waitx>:
.global waitx
waitx:
 li a7, SYS_waitx
 540:	48e1                	li	a7,24
 ecall
 542:	00000073          	ecall
 ret
 546:	8082                	ret

0000000000000548 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 548:	1101                	addi	sp,sp,-32
 54a:	ec06                	sd	ra,24(sp)
 54c:	e822                	sd	s0,16(sp)
 54e:	1000                	addi	s0,sp,32
 550:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 554:	4605                	li	a2,1
 556:	fef40593          	addi	a1,s0,-17
 55a:	f57ff0ef          	jal	4b0 <write>
}
 55e:	60e2                	ld	ra,24(sp)
 560:	6442                	ld	s0,16(sp)
 562:	6105                	addi	sp,sp,32
 564:	8082                	ret

0000000000000566 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 566:	715d                	addi	sp,sp,-80
 568:	e486                	sd	ra,72(sp)
 56a:	e0a2                	sd	s0,64(sp)
 56c:	fc26                	sd	s1,56(sp)
 56e:	0880                	addi	s0,sp,80
 570:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 572:	c299                	beqz	a3,578 <printint+0x12>
 574:	0805c963          	bltz	a1,606 <printint+0xa0>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 578:	2581                	sext.w	a1,a1
  neg = 0;
 57a:	4881                	li	a7,0
 57c:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
 580:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 582:	2601                	sext.w	a2,a2
 584:	00000517          	auipc	a0,0x0
 588:	63450513          	addi	a0,a0,1588 # bb8 <digits>
 58c:	883a                	mv	a6,a4
 58e:	2705                	addiw	a4,a4,1
 590:	02c5f7bb          	remuw	a5,a1,a2
 594:	1782                	slli	a5,a5,0x20
 596:	9381                	srli	a5,a5,0x20
 598:	97aa                	add	a5,a5,a0
 59a:	0007c783          	lbu	a5,0(a5)
 59e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 5a2:	0005879b          	sext.w	a5,a1
 5a6:	02c5d5bb          	divuw	a1,a1,a2
 5aa:	0685                	addi	a3,a3,1
 5ac:	fec7f0e3          	bgeu	a5,a2,58c <printint+0x26>
  if(neg)
 5b0:	00088c63          	beqz	a7,5c8 <printint+0x62>
    buf[i++] = '-';
 5b4:	fd070793          	addi	a5,a4,-48
 5b8:	00878733          	add	a4,a5,s0
 5bc:	02d00793          	li	a5,45
 5c0:	fef70423          	sb	a5,-24(a4)
 5c4:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 5c8:	02e05a63          	blez	a4,5fc <printint+0x96>
 5cc:	f84a                	sd	s2,48(sp)
 5ce:	f44e                	sd	s3,40(sp)
 5d0:	fb840793          	addi	a5,s0,-72
 5d4:	00e78933          	add	s2,a5,a4
 5d8:	fff78993          	addi	s3,a5,-1
 5dc:	99ba                	add	s3,s3,a4
 5de:	377d                	addiw	a4,a4,-1
 5e0:	1702                	slli	a4,a4,0x20
 5e2:	9301                	srli	a4,a4,0x20
 5e4:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 5e8:	fff94583          	lbu	a1,-1(s2)
 5ec:	8526                	mv	a0,s1
 5ee:	f5bff0ef          	jal	548 <putc>
  while(--i >= 0)
 5f2:	197d                	addi	s2,s2,-1
 5f4:	ff391ae3          	bne	s2,s3,5e8 <printint+0x82>
 5f8:	7942                	ld	s2,48(sp)
 5fa:	79a2                	ld	s3,40(sp)
}
 5fc:	60a6                	ld	ra,72(sp)
 5fe:	6406                	ld	s0,64(sp)
 600:	74e2                	ld	s1,56(sp)
 602:	6161                	addi	sp,sp,80
 604:	8082                	ret
    x = -xx;
 606:	40b005bb          	negw	a1,a1
    neg = 1;
 60a:	4885                	li	a7,1
    x = -xx;
 60c:	bf85                	j	57c <printint+0x16>

000000000000060e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 60e:	711d                	addi	sp,sp,-96
 610:	ec86                	sd	ra,88(sp)
 612:	e8a2                	sd	s0,80(sp)
 614:	e0ca                	sd	s2,64(sp)
 616:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 618:	0005c903          	lbu	s2,0(a1)
 61c:	28090663          	beqz	s2,8a8 <vprintf+0x29a>
 620:	e4a6                	sd	s1,72(sp)
 622:	fc4e                	sd	s3,56(sp)
 624:	f852                	sd	s4,48(sp)
 626:	f456                	sd	s5,40(sp)
 628:	f05a                	sd	s6,32(sp)
 62a:	ec5e                	sd	s7,24(sp)
 62c:	e862                	sd	s8,16(sp)
 62e:	e466                	sd	s9,8(sp)
 630:	8b2a                	mv	s6,a0
 632:	8a2e                	mv	s4,a1
 634:	8bb2                	mv	s7,a2
  state = 0;
 636:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 638:	4481                	li	s1,0
 63a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 63c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 640:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 644:	06c00c93          	li	s9,108
 648:	a005                	j	668 <vprintf+0x5a>
        putc(fd, c0);
 64a:	85ca                	mv	a1,s2
 64c:	855a                	mv	a0,s6
 64e:	efbff0ef          	jal	548 <putc>
 652:	a019                	j	658 <vprintf+0x4a>
    } else if(state == '%'){
 654:	03598263          	beq	s3,s5,678 <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 658:	2485                	addiw	s1,s1,1
 65a:	8726                	mv	a4,s1
 65c:	009a07b3          	add	a5,s4,s1
 660:	0007c903          	lbu	s2,0(a5)
 664:	22090a63          	beqz	s2,898 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 668:	0009079b          	sext.w	a5,s2
    if(state == 0){
 66c:	fe0994e3          	bnez	s3,654 <vprintf+0x46>
      if(c0 == '%'){
 670:	fd579de3          	bne	a5,s5,64a <vprintf+0x3c>
        state = '%';
 674:	89be                	mv	s3,a5
 676:	b7cd                	j	658 <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 678:	00ea06b3          	add	a3,s4,a4
 67c:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 680:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 682:	c681                	beqz	a3,68a <vprintf+0x7c>
 684:	9752                	add	a4,a4,s4
 686:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 68a:	05878363          	beq	a5,s8,6d0 <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 68e:	05978d63          	beq	a5,s9,6e8 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 692:	07500713          	li	a4,117
 696:	0ee78763          	beq	a5,a4,784 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 69a:	07800713          	li	a4,120
 69e:	12e78963          	beq	a5,a4,7d0 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 6a2:	07000713          	li	a4,112
 6a6:	14e78e63          	beq	a5,a4,802 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 6aa:	06300713          	li	a4,99
 6ae:	18e78e63          	beq	a5,a4,84a <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 6b2:	07300713          	li	a4,115
 6b6:	1ae78463          	beq	a5,a4,85e <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 6ba:	02500713          	li	a4,37
 6be:	04e79563          	bne	a5,a4,708 <vprintf+0xfa>
        putc(fd, '%');
 6c2:	02500593          	li	a1,37
 6c6:	855a                	mv	a0,s6
 6c8:	e81ff0ef          	jal	548 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 6cc:	4981                	li	s3,0
 6ce:	b769                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 6d0:	008b8913          	addi	s2,s7,8
 6d4:	4685                	li	a3,1
 6d6:	4629                	li	a2,10
 6d8:	000ba583          	lw	a1,0(s7)
 6dc:	855a                	mv	a0,s6
 6de:	e89ff0ef          	jal	566 <printint>
 6e2:	8bca                	mv	s7,s2
      state = 0;
 6e4:	4981                	li	s3,0
 6e6:	bf8d                	j	658 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 6e8:	06400793          	li	a5,100
 6ec:	02f68963          	beq	a3,a5,71e <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6f0:	06c00793          	li	a5,108
 6f4:	04f68263          	beq	a3,a5,738 <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 6f8:	07500793          	li	a5,117
 6fc:	0af68063          	beq	a3,a5,79c <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 700:	07800793          	li	a5,120
 704:	0ef68263          	beq	a3,a5,7e8 <vprintf+0x1da>
        putc(fd, '%');
 708:	02500593          	li	a1,37
 70c:	855a                	mv	a0,s6
 70e:	e3bff0ef          	jal	548 <putc>
        putc(fd, c0);
 712:	85ca                	mv	a1,s2
 714:	855a                	mv	a0,s6
 716:	e33ff0ef          	jal	548 <putc>
      state = 0;
 71a:	4981                	li	s3,0
 71c:	bf35                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 71e:	008b8913          	addi	s2,s7,8
 722:	4685                	li	a3,1
 724:	4629                	li	a2,10
 726:	000bb583          	ld	a1,0(s7)
 72a:	855a                	mv	a0,s6
 72c:	e3bff0ef          	jal	566 <printint>
        i += 1;
 730:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 732:	8bca                	mv	s7,s2
      state = 0;
 734:	4981                	li	s3,0
        i += 1;
 736:	b70d                	j	658 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 738:	06400793          	li	a5,100
 73c:	02f60763          	beq	a2,a5,76a <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 740:	07500793          	li	a5,117
 744:	06f60963          	beq	a2,a5,7b6 <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 748:	07800793          	li	a5,120
 74c:	faf61ee3          	bne	a2,a5,708 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 750:	008b8913          	addi	s2,s7,8
 754:	4681                	li	a3,0
 756:	4641                	li	a2,16
 758:	000bb583          	ld	a1,0(s7)
 75c:	855a                	mv	a0,s6
 75e:	e09ff0ef          	jal	566 <printint>
        i += 2;
 762:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 764:	8bca                	mv	s7,s2
      state = 0;
 766:	4981                	li	s3,0
        i += 2;
 768:	bdc5                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 76a:	008b8913          	addi	s2,s7,8
 76e:	4685                	li	a3,1
 770:	4629                	li	a2,10
 772:	000bb583          	ld	a1,0(s7)
 776:	855a                	mv	a0,s6
 778:	defff0ef          	jal	566 <printint>
        i += 2;
 77c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 77e:	8bca                	mv	s7,s2
      state = 0;
 780:	4981                	li	s3,0
        i += 2;
 782:	bdd9                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 784:	008b8913          	addi	s2,s7,8
 788:	4681                	li	a3,0
 78a:	4629                	li	a2,10
 78c:	000be583          	lwu	a1,0(s7)
 790:	855a                	mv	a0,s6
 792:	dd5ff0ef          	jal	566 <printint>
 796:	8bca                	mv	s7,s2
      state = 0;
 798:	4981                	li	s3,0
 79a:	bd7d                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 79c:	008b8913          	addi	s2,s7,8
 7a0:	4681                	li	a3,0
 7a2:	4629                	li	a2,10
 7a4:	000bb583          	ld	a1,0(s7)
 7a8:	855a                	mv	a0,s6
 7aa:	dbdff0ef          	jal	566 <printint>
        i += 1;
 7ae:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b0:	8bca                	mv	s7,s2
      state = 0;
 7b2:	4981                	li	s3,0
        i += 1;
 7b4:	b555                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b6:	008b8913          	addi	s2,s7,8
 7ba:	4681                	li	a3,0
 7bc:	4629                	li	a2,10
 7be:	000bb583          	ld	a1,0(s7)
 7c2:	855a                	mv	a0,s6
 7c4:	da3ff0ef          	jal	566 <printint>
        i += 2;
 7c8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ca:	8bca                	mv	s7,s2
      state = 0;
 7cc:	4981                	li	s3,0
        i += 2;
 7ce:	b569                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 7d0:	008b8913          	addi	s2,s7,8
 7d4:	4681                	li	a3,0
 7d6:	4641                	li	a2,16
 7d8:	000be583          	lwu	a1,0(s7)
 7dc:	855a                	mv	a0,s6
 7de:	d89ff0ef          	jal	566 <printint>
 7e2:	8bca                	mv	s7,s2
      state = 0;
 7e4:	4981                	li	s3,0
 7e6:	bd8d                	j	658 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7e8:	008b8913          	addi	s2,s7,8
 7ec:	4681                	li	a3,0
 7ee:	4641                	li	a2,16
 7f0:	000bb583          	ld	a1,0(s7)
 7f4:	855a                	mv	a0,s6
 7f6:	d71ff0ef          	jal	566 <printint>
        i += 1;
 7fa:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7fc:	8bca                	mv	s7,s2
      state = 0;
 7fe:	4981                	li	s3,0
        i += 1;
 800:	bda1                	j	658 <vprintf+0x4a>
 802:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 804:	008b8d13          	addi	s10,s7,8
 808:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 80c:	03000593          	li	a1,48
 810:	855a                	mv	a0,s6
 812:	d37ff0ef          	jal	548 <putc>
  putc(fd, 'x');
 816:	07800593          	li	a1,120
 81a:	855a                	mv	a0,s6
 81c:	d2dff0ef          	jal	548 <putc>
 820:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 822:	00000b97          	auipc	s7,0x0
 826:	396b8b93          	addi	s7,s7,918 # bb8 <digits>
 82a:	03c9d793          	srli	a5,s3,0x3c
 82e:	97de                	add	a5,a5,s7
 830:	0007c583          	lbu	a1,0(a5)
 834:	855a                	mv	a0,s6
 836:	d13ff0ef          	jal	548 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 83a:	0992                	slli	s3,s3,0x4
 83c:	397d                	addiw	s2,s2,-1
 83e:	fe0916e3          	bnez	s2,82a <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 842:	8bea                	mv	s7,s10
      state = 0;
 844:	4981                	li	s3,0
 846:	6d02                	ld	s10,0(sp)
 848:	bd01                	j	658 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 84a:	008b8913          	addi	s2,s7,8
 84e:	000bc583          	lbu	a1,0(s7)
 852:	855a                	mv	a0,s6
 854:	cf5ff0ef          	jal	548 <putc>
 858:	8bca                	mv	s7,s2
      state = 0;
 85a:	4981                	li	s3,0
 85c:	bbf5                	j	658 <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 85e:	008b8993          	addi	s3,s7,8
 862:	000bb903          	ld	s2,0(s7)
 866:	00090f63          	beqz	s2,884 <vprintf+0x276>
        for(; *s; s++)
 86a:	00094583          	lbu	a1,0(s2)
 86e:	c195                	beqz	a1,892 <vprintf+0x284>
          putc(fd, *s);
 870:	855a                	mv	a0,s6
 872:	cd7ff0ef          	jal	548 <putc>
        for(; *s; s++)
 876:	0905                	addi	s2,s2,1
 878:	00094583          	lbu	a1,0(s2)
 87c:	f9f5                	bnez	a1,870 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 87e:	8bce                	mv	s7,s3
      state = 0;
 880:	4981                	li	s3,0
 882:	bbd9                	j	658 <vprintf+0x4a>
          s = "(null)";
 884:	00000917          	auipc	s2,0x0
 888:	32c90913          	addi	s2,s2,812 # bb0 <malloc+0x220>
        for(; *s; s++)
 88c:	02800593          	li	a1,40
 890:	b7c5                	j	870 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 892:	8bce                	mv	s7,s3
      state = 0;
 894:	4981                	li	s3,0
 896:	b3c9                	j	658 <vprintf+0x4a>
 898:	64a6                	ld	s1,72(sp)
 89a:	79e2                	ld	s3,56(sp)
 89c:	7a42                	ld	s4,48(sp)
 89e:	7aa2                	ld	s5,40(sp)
 8a0:	7b02                	ld	s6,32(sp)
 8a2:	6be2                	ld	s7,24(sp)
 8a4:	6c42                	ld	s8,16(sp)
 8a6:	6ca2                	ld	s9,8(sp)
    }
  }
}
 8a8:	60e6                	ld	ra,88(sp)
 8aa:	6446                	ld	s0,80(sp)
 8ac:	6906                	ld	s2,64(sp)
 8ae:	6125                	addi	sp,sp,96
 8b0:	8082                	ret

00000000000008b2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8b2:	715d                	addi	sp,sp,-80
 8b4:	ec06                	sd	ra,24(sp)
 8b6:	e822                	sd	s0,16(sp)
 8b8:	1000                	addi	s0,sp,32
 8ba:	e010                	sd	a2,0(s0)
 8bc:	e414                	sd	a3,8(s0)
 8be:	e818                	sd	a4,16(s0)
 8c0:	ec1c                	sd	a5,24(s0)
 8c2:	03043023          	sd	a6,32(s0)
 8c6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8ca:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8ce:	8622                	mv	a2,s0
 8d0:	d3fff0ef          	jal	60e <vprintf>
}
 8d4:	60e2                	ld	ra,24(sp)
 8d6:	6442                	ld	s0,16(sp)
 8d8:	6161                	addi	sp,sp,80
 8da:	8082                	ret

00000000000008dc <printf>:

void
printf(const char *fmt, ...)
{
 8dc:	711d                	addi	sp,sp,-96
 8de:	ec06                	sd	ra,24(sp)
 8e0:	e822                	sd	s0,16(sp)
 8e2:	1000                	addi	s0,sp,32
 8e4:	e40c                	sd	a1,8(s0)
 8e6:	e810                	sd	a2,16(s0)
 8e8:	ec14                	sd	a3,24(s0)
 8ea:	f018                	sd	a4,32(s0)
 8ec:	f41c                	sd	a5,40(s0)
 8ee:	03043823          	sd	a6,48(s0)
 8f2:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8f6:	00840613          	addi	a2,s0,8
 8fa:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8fe:	85aa                	mv	a1,a0
 900:	4505                	li	a0,1
 902:	d0dff0ef          	jal	60e <vprintf>
}
 906:	60e2                	ld	ra,24(sp)
 908:	6442                	ld	s0,16(sp)
 90a:	6125                	addi	sp,sp,96
 90c:	8082                	ret

000000000000090e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 90e:	1141                	addi	sp,sp,-16
 910:	e422                	sd	s0,8(sp)
 912:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 914:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 918:	00000797          	auipc	a5,0x0
 91c:	6f87b783          	ld	a5,1784(a5) # 1010 <freep>
 920:	a02d                	j	94a <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 922:	4618                	lw	a4,8(a2)
 924:	9f2d                	addw	a4,a4,a1
 926:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 92a:	6398                	ld	a4,0(a5)
 92c:	6310                	ld	a2,0(a4)
 92e:	a83d                	j	96c <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 930:	ff852703          	lw	a4,-8(a0)
 934:	9f31                	addw	a4,a4,a2
 936:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 938:	ff053683          	ld	a3,-16(a0)
 93c:	a091                	j	980 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 93e:	6398                	ld	a4,0(a5)
 940:	00e7e463          	bltu	a5,a4,948 <free+0x3a>
 944:	00e6ea63          	bltu	a3,a4,958 <free+0x4a>
{
 948:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 94a:	fed7fae3          	bgeu	a5,a3,93e <free+0x30>
 94e:	6398                	ld	a4,0(a5)
 950:	00e6e463          	bltu	a3,a4,958 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 954:	fee7eae3          	bltu	a5,a4,948 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 958:	ff852583          	lw	a1,-8(a0)
 95c:	6390                	ld	a2,0(a5)
 95e:	02059813          	slli	a6,a1,0x20
 962:	01c85713          	srli	a4,a6,0x1c
 966:	9736                	add	a4,a4,a3
 968:	fae60de3          	beq	a2,a4,922 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 96c:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 970:	4790                	lw	a2,8(a5)
 972:	02061593          	slli	a1,a2,0x20
 976:	01c5d713          	srli	a4,a1,0x1c
 97a:	973e                	add	a4,a4,a5
 97c:	fae68ae3          	beq	a3,a4,930 <free+0x22>
    p->s.ptr = bp->s.ptr;
 980:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 982:	00000717          	auipc	a4,0x0
 986:	68f73723          	sd	a5,1678(a4) # 1010 <freep>
}
 98a:	6422                	ld	s0,8(sp)
 98c:	0141                	addi	sp,sp,16
 98e:	8082                	ret

0000000000000990 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 990:	7139                	addi	sp,sp,-64
 992:	fc06                	sd	ra,56(sp)
 994:	f822                	sd	s0,48(sp)
 996:	f426                	sd	s1,40(sp)
 998:	ec4e                	sd	s3,24(sp)
 99a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 99c:	02051493          	slli	s1,a0,0x20
 9a0:	9081                	srli	s1,s1,0x20
 9a2:	04bd                	addi	s1,s1,15
 9a4:	8091                	srli	s1,s1,0x4
 9a6:	0014899b          	addiw	s3,s1,1
 9aa:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 9ac:	00000517          	auipc	a0,0x0
 9b0:	66453503          	ld	a0,1636(a0) # 1010 <freep>
 9b4:	c915                	beqz	a0,9e8 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9b6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9b8:	4798                	lw	a4,8(a5)
 9ba:	08977a63          	bgeu	a4,s1,a4e <malloc+0xbe>
 9be:	f04a                	sd	s2,32(sp)
 9c0:	e852                	sd	s4,16(sp)
 9c2:	e456                	sd	s5,8(sp)
 9c4:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 9c6:	8a4e                	mv	s4,s3
 9c8:	0009871b          	sext.w	a4,s3
 9cc:	6685                	lui	a3,0x1
 9ce:	00d77363          	bgeu	a4,a3,9d4 <malloc+0x44>
 9d2:	6a05                	lui	s4,0x1
 9d4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9d8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9dc:	00000917          	auipc	s2,0x0
 9e0:	63490913          	addi	s2,s2,1588 # 1010 <freep>
  if(p == SBRK_ERROR)
 9e4:	5afd                	li	s5,-1
 9e6:	a081                	j	a26 <malloc+0x96>
 9e8:	f04a                	sd	s2,32(sp)
 9ea:	e852                	sd	s4,16(sp)
 9ec:	e456                	sd	s5,8(sp)
 9ee:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9f0:	00000797          	auipc	a5,0x0
 9f4:	63078793          	addi	a5,a5,1584 # 1020 <base>
 9f8:	00000717          	auipc	a4,0x0
 9fc:	60f73c23          	sd	a5,1560(a4) # 1010 <freep>
 a00:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a02:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a06:	b7c1                	j	9c6 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 a08:	6398                	ld	a4,0(a5)
 a0a:	e118                	sd	a4,0(a0)
 a0c:	a8a9                	j	a66 <malloc+0xd6>
  hp->s.size = nu;
 a0e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a12:	0541                	addi	a0,a0,16
 a14:	efbff0ef          	jal	90e <free>
  return freep;
 a18:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 a1c:	c12d                	beqz	a0,a7e <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a1e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a20:	4798                	lw	a4,8(a5)
 a22:	02977263          	bgeu	a4,s1,a46 <malloc+0xb6>
    if(p == freep)
 a26:	00093703          	ld	a4,0(s2)
 a2a:	853e                	mv	a0,a5
 a2c:	fef719e3          	bne	a4,a5,a1e <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 a30:	8552                	mv	a0,s4
 a32:	a2bff0ef          	jal	45c <sbrk>
  if(p == SBRK_ERROR)
 a36:	fd551ce3          	bne	a0,s5,a0e <malloc+0x7e>
        return 0;
 a3a:	4501                	li	a0,0
 a3c:	7902                	ld	s2,32(sp)
 a3e:	6a42                	ld	s4,16(sp)
 a40:	6aa2                	ld	s5,8(sp)
 a42:	6b02                	ld	s6,0(sp)
 a44:	a03d                	j	a72 <malloc+0xe2>
 a46:	7902                	ld	s2,32(sp)
 a48:	6a42                	ld	s4,16(sp)
 a4a:	6aa2                	ld	s5,8(sp)
 a4c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a4e:	fae48de3          	beq	s1,a4,a08 <malloc+0x78>
        p->s.size -= nunits;
 a52:	4137073b          	subw	a4,a4,s3
 a56:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a58:	02071693          	slli	a3,a4,0x20
 a5c:	01c6d713          	srli	a4,a3,0x1c
 a60:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a62:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a66:	00000717          	auipc	a4,0x0
 a6a:	5aa73523          	sd	a0,1450(a4) # 1010 <freep>
      return (void*)(p + 1);
 a6e:	01078513          	addi	a0,a5,16
  }
}
 a72:	70e2                	ld	ra,56(sp)
 a74:	7442                	ld	s0,48(sp)
 a76:	74a2                	ld	s1,40(sp)
 a78:	69e2                	ld	s3,24(sp)
 a7a:	6121                	addi	sp,sp,64
 a7c:	8082                	ret
 a7e:	7902                	ld	s2,32(sp)
 a80:	6a42                	ld	s4,16(sp)
 a82:	6aa2                	ld	s5,8(sp)
 a84:	6b02                	ld	s6,0(sp)
 a86:	b7f5                	j	a72 <malloc+0xe2>
